"""
Weather connector placeholder.

Use official/verified weather archives where available, such as BOM data exports.
"""

def fetch_match_weather(*args, **kwargs):
    raise NotImplementedError("Connect an approved weather source or import CSV.")
