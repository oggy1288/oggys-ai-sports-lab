"""
Official NRL data connector placeholder.

Use this file when an approved data source or API endpoint is available.
Until then, import verified CSV files through Phase 1.4 Source Connectors.
"""

def fetch_fixtures_results(*args, **kwargs):
    raise NotImplementedError("Connect an approved fixtures/results source or import CSV.")

def fetch_player_stats(*args, **kwargs):
    raise NotImplementedError("Connect an approved player stats source or import CSV.")

def fetch_try_events(*args, **kwargs):
    raise NotImplementedError("Connect an approved try events source or import CSV.")
