"""
Odds feed connector placeholder.

Direct bookmaker scraping is intentionally not implemented. Use official APIs,
licensed odds feeds, or CSV exports.
"""

def fetch_odds_feed(*args, **kwargs):
    raise NotImplementedError("Connect a licensed odds feed or import CSV.")
