# OASL Connectors

This folder is for future source-specific connectors.

Current Phase 1.4 connectors are CSV-first and API-ready.

Direct scraping of bookmaker websites is intentionally not included. Use:
- official APIs
- licensed data feeds
- exported CSV files
- manually verified datasets
