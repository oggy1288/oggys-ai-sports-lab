import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import init_db, table_counts, read_table
from src.auth import require_password

st.set_page_config(page_title="NRL Predictor Pro V6.1", layout="wide")
inject_mobile_css()

if not require_password():
    st.stop()


init_db()

st.title("NRL Predictor Pro — V6.1")
st.caption("Streamlit app with SQLite database storage")

counts = table_counts()

col1, col2, col3, col4 = st.columns(4)
col1.metric("Players Loaded", int(counts.loc[counts["table"] == "player_stats", "rows"].sum()))
col2.metric("Fixtures Loaded", int(counts.loc[counts["table"] == "fixtures", "rows"].sum()))
col3.metric("Odds Rows", int(counts.loc[counts["table"] == "odds", "rows"].sum()))
col4.metric("Predictions", int(counts.loc[counts["table"] == "predictions", "rows"].sum()))

st.subheader("Latest Predictions")
predictions = read_table("predictions")
if predictions.empty:
    st.info("No predictions saved yet. Go to Upload Data, load CSVs, then run the predictor.")
else:
    st.dataframe(predictions.sort_values("model_score", ascending=False), use_container_width=True)

st.subheader("Database Status")
st.dataframe(counts, use_container_width=True)
