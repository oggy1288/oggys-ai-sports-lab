# Oggy's AI Sports Lab Pro V6.10 — Format & QA Update

This is a polish and quality-control build based on V6.9.

## Included app modules

- Streamlit mobile-friendly app
- SQLite database
- Manual data entry
- Upload CSV flow
- Try scorer prediction engine
- Player Integrity Checker
- Player ID & Name Matching
- Milestone Game Modifier
- Origin Impact Engine
- Narrative Context Engine
- Middle Forward Try Scorer Engine
- Mobile Dashboard
- Format & QA page
- Deploy-ready Streamlit configuration

## Key prediction logic now included

### Weekly Team List Logic
Players only appear in weekly try-scorer predictions by default if they are named in that week's team list.

### Player Integrity Logic
Flags:
- players missing from player_stats
- spelling/name mismatches
- duplicate players
- players not selected this week
- missing odds
- missing injury/team-news status

### Context Logic
Adds small capped modifiers for:
- milestone games, including 400th game
- State of Origin selection/rest/back-up/fatigue
- former club, debut, final home game, retirement and rivalry narratives
- middle-forward try chances through crash balls, short balls and dummy-half sneaks

## How to run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Phone-friendly workflow

1. Open app
2. Add or upload weekly team lists
3. Run Player ID & Name Matching
4. Run Player Integrity Checker
5. Add milestone / Origin / narrative / middle-forward context
6. Run predictor
7. Open Mobile Dashboard

## Notes

This is still a prototype. The next major improvement should be **V7.0 Weekly Setup Wizard**, which guides you step by step through a complete round update.


## V7.0 Update — Weekly Setup Wizard

Added:
- Step-by-step weekly setup flow
- Round setup
- Fixture editor
- Team list editor
- Player stats / odds / injuries editor
- Context editor
- Built-in name matching
- Built-in integrity checker
- Setup progress tracker
- Links to prediction and mobile dashboard pages

This makes the app much easier to run each week from a phone.


## V7.1 Update — Live Odds Aggregator

Added:
- Multi-bookmaker odds import
- Sportsbet / Ladbrokes / TAB / Neds / PointsBet / Bet365 / Unibet / Bet Right support structure
- Best-price board
- Model fair odds vs market odds comparison
- Market edge %
- EV %
- Value flags
- CSV import template
- API-ready bookmaker connector placeholders

Note: direct bookmaker website scraping is not included. Use official APIs, licensed odds feeds, or CSV imports.


## V7.2 Update — Matchup Sequence Engine

Added:
- Player last 5 try sequence
- Team last 5 tries scored sequence
- Team last 5 tries conceded sequence
- Player vs opponent try sequence
- Emoji sequence display like 2️⃣ 0️⃣ 2️⃣ 0️⃣ 2️⃣
- Quick matchup strength rating
- Sequence intelligence merged into predictions and mobile dashboard

This gives a fast way to see whether a player is strong against the team they are facing.


## V7.3 Update — Why AI Likes This

Added:
- Why AI Likes This page
- Plain-English player explanations
- Positive reason list
- Risk checks
- Traffic-light factor scores
- Confidence bars
- Overall AI verdict
- Downloadable why report

This gives the app the “Why?” button concept Nathan liked in the mock-up.


## V8.1.1 Update — Historical Try Intelligence Database

Added:
- player try history table
- try minute tracking
- first try flag
- try number tracking
- player timing profile
- team scoring timeline
- team conceded timeline
- timing labels: Early Threat / Late Finisher / Second Half Specialist
- seed probabilities for First Try, 2+ Tries and 3+ Tries

This is the foundation for proper try-market predictions based on historical scoring minutes.


## V8.1 Update — Try Markets Intelligence Engine

Added:
- Anytime Try market board
- First Try Scorer predictions
- 2+ Tries predictions
- 3+ Tries predictions
- fair odds for each market
- best odds comparison where available
- edge % and EV %
- player try markets card
- downloadable try market predictions

This expands Oggy's AI Sports Lab beyond Anytime Try Scorer into major try-scoring markets.


## V8.2 Update — Team DNA Engine

Added:
- Team Attack DNA
- Team Defence DNA
- channel-based try analysis
- Left Edge / Middle / Right Edge / Kick-Other profiles
- channel matchup comparison
- Team DNA boost in predictions
- Team DNA explanation in Why AI Likes This

This shows when a team's strongest attacking channel lines up with the opponent's weakest defensive channel.


## Phase 1 Update — Historical Data Warehouse

Added:
- OASL historical warehouse schema
- master data dictionary
- warehouse SQLite database
- import templates
- data quality checker
- sample match, try event and player stat files
- new Phase 1 Historical Data Warehouse page

This becomes the source of truth for future AI engines.


## Phase 1.2 Update — Data Validation & Dataset Versioning

Added:
- dataset_versions table
- import_log table
- relationship_quality_report table
- primary key duplicate checks
- blank ID checks
- relationship checks
- data health score
- improved CSV import centre
- Phase 1.2 validation page

This makes the warehouse safer before it powers live AI predictions.


## Phase 1.3 Update — Source Adapter Framework

Added:
- fixtures/results adapter
- player stats adapter
- try events adapter
- weather adapter
- odds adapter
- adapter preview page
- adapter import page
- sample adapter CSV files

This lets raw CSV files be converted into clean warehouse tables.


## Phase 1.4 Update — Source Connectors & Import Planner

Added:
- source registry
- import planner
- field coverage report
- connector health report
- CSV-first source import workflow
- API-ready connector placeholders
- source manifest sample

This prepares the warehouse for real historical backfilling.


## Phase 1.5 Update — Historical Season Backfill Tracker

Added:
- season-by-season backfill plan
- completeness report
- missing data report
- season import checklist
- readiness labels
- recommended historical backfill order

This helps load 2010–current NRL history safely and clearly.


## Phase 2 Update — AI Core Working Build

Added working modules for:
- Master Feature Library
- Player DNA
- Team DNA 2.0
- Match-up Intelligence
- Match Simulation
- Try Market Simulation
- Ensemble AI
- Self-Learning summary
- Real-Time Intelligence events

Open the new Phase 2 page and run the full pipeline after loading warehouse data.


## Phase 3.1 Update — One-Click Setup & Demo Mode

Added:
- Setup Wizard
- demo data loader
- one-click Phase 2 pipeline runner
- setup status checks
- demo prediction results
- app health page

This makes the app much easier to test before importing real data.
