import pandas as pd
import numpy as np

def safe_num(v, default=0):
    try:
        if pd.isna(v): return default
        return float(v)
    except Exception:
        return default

def clamp(v, low=0, high=100):
    return max(low, min(high, v))

def build_player_dna(master_features, opponent_features=None):
    if master_features is None or master_features.empty:
        return pd.DataFrame(columns=[
            "player_id","player_name","team_id","position","try_scoring_dna","explosiveness_dna",
            "finishing_dna","physical_dna","momentum_dna","confidence_dna","overall_player_dna",
            "dna_summary"
        ])
    rows=[]
    for _, r in master_features.iterrows():
        try_scoring = clamp(safe_num(r.get("try_form_rating"))*0.55 + safe_num(r.get("tries_season_avg"))*45)
        explosiveness = clamp(safe_num(r.get("tackle_breaks_avg"))*9 + safe_num(r.get("line_breaks_avg"))*22 + safe_num(r.get("run_metres_avg"))/180*35)
        finishing = clamp(safe_num(r.get("tries_l5"))/5*75 + safe_num(r.get("line_breaks_avg"))*15)
        physical = clamp(safe_num(r.get("minutes_avg"))/80*45 + safe_num(r.get("run_metres_avg"))/180*45 + 10)
        momentum = clamp(safe_num(r.get("form_score"))*0.7 + safe_num(r.get("momentum_score"),50)*0.3)
        confidence = clamp(safe_num(r.get("feature_confidence"),50))
        overall = try_scoring*0.30 + explosiveness*0.15 + finishing*0.20 + physical*0.10 + momentum*0.15 + confidence*0.10
        label = "Elite Try Threat" if overall >= 85 else ("Strong Player Profile" if overall >= 72 else ("Value Watch" if overall >= 60 else "Needs More Evidence"))
        rows.append({
            "player_id": r.get("player_id",""),
            "player_name": r.get("player_name",""),
            "team_id": r.get("team_id",""),
            "position": r.get("position",""),
            "try_scoring_dna": round(try_scoring,1),
            "explosiveness_dna": round(explosiveness,1),
            "finishing_dna": round(finishing,1),
            "physical_dna": round(physical,1),
            "momentum_dna": round(momentum,1),
            "confidence_dna": round(confidence,1),
            "overall_player_dna": round(overall,1),
            "dna_summary": label,
        })
    return pd.DataFrame(rows).sort_values("overall_player_dna", ascending=False)
