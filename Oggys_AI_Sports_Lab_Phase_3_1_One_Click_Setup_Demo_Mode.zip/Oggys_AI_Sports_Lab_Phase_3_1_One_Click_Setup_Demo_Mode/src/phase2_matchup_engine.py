import pandas as pd
import numpy as np

def safe_num(v, default=50):
    try:
        if pd.isna(v): return default
        return float(v)
    except Exception:
        return default

def build_matchup_intelligence(matches, team_dna, player_dna):
    if matches is None or matches.empty or team_dna is None or team_dna.empty:
        return pd.DataFrame(columns=["match_id","home_team","away_team","home_matchup_score","away_matchup_score","predicted_winner","winner_probability","biggest_mismatch","matchup_summary"])
    rows=[]
    for _,m in matches.iterrows():
        home=m.get("home_team",""); away=m.get("away_team","")
        h=team_dna[team_dna["team"]==home]
        a=team_dna[team_dna["team"]==away]
        if h.empty or a.empty:
            hs=50; as_=50; mismatch="Insufficient Team DNA"
        else:
            h=h.iloc[0]; a=a.iloc[0]
            edge_adv = max(safe_num(h.get("left_edge_attack_pct")), safe_num(h.get("right_edge_attack_pct"))) - max(safe_num(a.get("left_edge_attack_pct")), safe_num(a.get("right_edge_attack_pct")))
            hs=safe_num(h.get("overall_team_dna")) + edge_adv*0.08 + 3
            as_=safe_num(a.get("overall_team_dna")) - edge_adv*0.08
            mismatch = f"{home} {h.get('primary_attack_channel','')} vs {away} defence" if hs>=as_ else f"{away} {a.get('primary_attack_channel','')} vs {home} defence"
        diff=hs-as_
        prob=1/(1+np.exp(-diff/12))
        winner=home if prob>=0.5 else away
        winprob=prob if winner==home else 1-prob
        rows.append({
            "match_id":m.get("match_id",""),"home_team":home,"away_team":away,
            "home_matchup_score":round(hs,1),"away_matchup_score":round(as_,1),
            "predicted_winner":winner,"winner_probability":round(winprob,3),
            "biggest_mismatch":mismatch,
            "matchup_summary":f"{winner} holds the matchup edge. Biggest area: {mismatch}.",
        })
    return pd.DataFrame(rows).sort_values("winner_probability", ascending=False)
