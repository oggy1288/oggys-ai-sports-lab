"""
Bookmaker connector placeholders.

Important:
This file is intentionally API-ready rather than scraper-based.
Bookmaker websites may block scraping or prohibit it in their terms.
Use official APIs, licensed odds feeds, or manual CSV imports.
"""

import pandas as pd

def fetch_sportsbet_odds(api_key=None):
    raise NotImplementedError("Connect an approved Sportsbet/odds provider API or use CSV import.")

def fetch_ladbrokes_odds(api_key=None):
    raise NotImplementedError("Connect an approved Ladbrokes/odds provider API or use CSV import.")

def fetch_tab_odds(api_key=None):
    raise NotImplementedError("Connect an approved TAB/odds provider API or use CSV import.")

def fetch_generic_provider_odds(provider_name, api_key=None):
    raise NotImplementedError("Connect a licensed odds feed provider API here.")

def load_manual_odds_csv(path):
    return pd.read_csv(path)
