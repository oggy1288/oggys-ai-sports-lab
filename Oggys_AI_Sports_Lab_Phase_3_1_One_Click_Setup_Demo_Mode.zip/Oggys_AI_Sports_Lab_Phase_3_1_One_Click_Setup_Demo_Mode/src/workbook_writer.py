from pathlib import Path
import pandas as pd
from openpyxl import load_workbook
from openpyxl.styles import Font, PatternFill

def write_dataframe(ws, df):
    ws.append(list(df.columns))
    for row in df.itertuples(index=False):
        ws.append(list(row))
    fill = PatternFill("solid", fgColor="1F4E78")
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = fill
    for col in ws.columns:
        max_len = max(len(str(c.value)) if c.value is not None else 0 for c in col)
        ws.column_dimensions[col[0].column_letter].width = min(max(max_len + 2, 12), 34)

def write_outputs_to_workbook(input_workbook, output_workbook, outputs):
    wb = load_workbook(input_workbook)
    for sheet_name, df in outputs.items():
        if sheet_name in wb.sheetnames:
            del wb[sheet_name]
        ws = wb.create_sheet(sheet_name)
        write_dataframe(ws, df)
    output_workbook = Path(output_workbook)
    output_workbook.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_workbook)