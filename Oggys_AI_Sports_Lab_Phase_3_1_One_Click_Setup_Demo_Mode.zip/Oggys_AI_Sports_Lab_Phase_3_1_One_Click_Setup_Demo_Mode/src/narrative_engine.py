import pandas as pd

NARRATIVE_BOOSTS = {
    "NRL Debut": 2,
    "Club Debut": 1,
    "Home Debut": 1,
    "Playing Former Club": 2,
    "Captain First Game": 2,
    "Final Home Game": 3,
    "Retirement Game": 4,
    "Rivalry Game": 1,
    "Finals Intensity": 2,
    "Grand Final": 3,
    "First Game Back From Injury": -2,
    "Returning From Suspension": 1,
    "New Contract Signed": 1,
    "Contract Year Motivation": 1,
    "Dropped Last Week / Recalled": 1,
    "Birthday Game": 0.5,
    "Indigenous Round": 0.5,
    "ANZAC Round": 0.5,
    "Magic Round": 0.5,
    "No Major Narrative": 0,
}

MAX_NARRATIVE_BOOST = 6

def calculate_narrative_boost(row):
    boost = 0
    notes = []

    for col, value in row.items():
        if str(col).startswith("context_") and bool(value):
            label = str(col).replace("context_", "").replace("_", " ").title()
            mapped = None
            for key in NARRATIVE_BOOSTS:
                if key.lower() == label.lower():
                    mapped = key
                    break
            if mapped:
                boost += NARRATIVE_BOOSTS[mapped]
                notes.append(mapped)

    manual_context = str(row.get("context_type", "")).strip()
    if manual_context in NARRATIVE_BOOSTS:
        boost += NARRATIVE_BOOSTS[manual_context]
        notes.append(manual_context)

    boost = max(min(boost, MAX_NARRATIVE_BOOST), -4)
    return boost, ", ".join(sorted(set(notes)))

def apply_narrative_context(players_df, narrative_df):
    if players_df is None or players_df.empty:
        return players_df

    df = players_df.copy()

    if narrative_df is None or narrative_df.empty or "player" not in narrative_df.columns:
        df["narrative_boost"] = 0
        df["narrative_flags"] = ""
        df["narrative_note"] = ""
        return df

    narrative = narrative_df.copy()
    rows = []

    for _, row in narrative.iterrows():
        boost, flags = calculate_narrative_boost(row)
        rows.append({
            "player": row.get("player", ""),
            "team": row.get("team", ""),
            "narrative_boost": boost,
            "narrative_flags": flags,
            "narrative_note": row.get("narrative_note", ""),
        })

    context = pd.DataFrame(rows)
    if context.empty:
        df["narrative_boost"] = 0
        df["narrative_flags"] = ""
        df["narrative_note"] = ""
        return df

    context = context.groupby("player", as_index=False).agg({
        "team": "first",
        "narrative_boost": "sum",
        "narrative_flags": lambda x: ", ".join([v for v in x if str(v).strip()]),
        "narrative_note": lambda x: " | ".join([v for v in x if str(v).strip()]),
    })
    context["narrative_boost"] = context["narrative_boost"].clip(-4, MAX_NARRATIVE_BOOST)

    df = df.merge(context[["player", "narrative_boost", "narrative_flags", "narrative_note"]], on="player", how="left")
    df["narrative_boost"] = pd.to_numeric(df["narrative_boost"], errors="coerce").fillna(0)
    df["narrative_flags"] = df["narrative_flags"].fillna("")
    df["narrative_note"] = df["narrative_note"].fillna("")
    return df