import pandas as pd

DIGIT_EMOJI = {
    0: "0️⃣",
    1: "1️⃣",
    2: "2️⃣",
    3: "3️⃣",
    4: "4️⃣",
    5: "5️⃣",
    6: "6️⃣",
    7: "7️⃣",
    8: "8️⃣",
    9: "9️⃣",
}

def number_to_emoji(value):
    try:
        n = int(value)
    except Exception:
        n = 0
    if n <= 9:
        return DIGIT_EMOJI.get(n, str(n))
    return "🔟+" if n >= 10 else "0️⃣"

def sequence_to_emoji(values):
    if values is None:
        return ""
    return " ".join(number_to_emoji(v) for v in values)

def score_sequence(values):
    vals = [int(v or 0) for v in values]
    total = sum(vals)
    scored_games = sum(1 for v in vals if v > 0)
    multi_games = sum(1 for v in vals if v >= 2)
    avg = total / len(vals) if vals else 0
    return {
        "last5_total": total,
        "last5_scored_games": scored_games,
        "last5_multi_games": multi_games,
        "last5_avg": round(avg, 2),
        "last5_strike_rate": round(scored_games / len(vals), 3) if vals else 0,
    }

def rating_from_strike_rate(rate):
    try:
        rate = float(rate)
    except Exception:
        rate = 0
    if rate >= 0.80:
        return "🟢🟢🟢🟢🟢 Elite"
    if rate >= 0.65:
        return "🟢🟢🟢🟢⚪ Very Strong"
    if rate >= 0.50:
        return "🟢🟢🟢⚪⚪ Good"
    if rate >= 0.30:
        return "🟡🟡⚪⚪⚪ Average"
    return "🔴⚪⚪⚪⚪ Poor"

def build_player_sequence_report(player_history, fixtures=None):
    if player_history is None or player_history.empty:
        return pd.DataFrame(columns=[
            "player", "team", "opponent", "last5_sequence", "last5_total",
            "last5_avg", "last5_scored_games", "last5_multi_games",
            "last5_rating"
        ])

    df = player_history.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    required = ["player", "team", "opponent", "round", "tries"]
    for col in required:
        if col not in df.columns:
            df[col] = ""

    df["tries"] = pd.to_numeric(df["tries"], errors="coerce").fillna(0).astype(int)
    df["round_sort"] = pd.to_numeric(df["round"].astype(str).str.replace("R", "", regex=False), errors="coerce").fillna(0)

    rows = []
    for (player, team), group in df.sort_values("round_sort", ascending=False).groupby(["player", "team"], dropna=False):
        last5 = group.head(5)
        vals = last5["tries"].tolist()
        stats = score_sequence(vals)
        rows.append({
            "player": player,
            "team": team,
            "opponent": last5.iloc[0].get("opponent", "") if not last5.empty else "",
            "last5_sequence": sequence_to_emoji(vals),
            **stats,
            "last5_rating": rating_from_strike_rate(stats["last5_strike_rate"]),
        })

    return pd.DataFrame(rows).sort_values(["last5_total", "last5_scored_games"], ascending=False)

def build_team_sequence_report(team_history):
    if team_history is None or team_history.empty:
        return pd.DataFrame(columns=[
            "team", "opponent", "team_last5_scored_sequence", "team_last5_conceded_sequence",
            "team_avg_scored", "team_avg_conceded", "team_attack_rating", "team_defence_leak_rating"
        ])

    df = team_history.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    required = ["team", "opponent", "round", "tries_scored", "tries_conceded"]
    for col in required:
        if col not in df.columns:
            df[col] = ""

    df["tries_scored"] = pd.to_numeric(df["tries_scored"], errors="coerce").fillna(0).astype(int)
    df["tries_conceded"] = pd.to_numeric(df["tries_conceded"], errors="coerce").fillna(0).astype(int)
    df["round_sort"] = pd.to_numeric(df["round"].astype(str).str.replace("R", "", regex=False), errors="coerce").fillna(0)

    rows = []
    for team, group in df.sort_values("round_sort", ascending=False).groupby("team", dropna=False):
        last5 = group.head(5)
        scored_vals = last5["tries_scored"].tolist()
        conceded_vals = last5["tries_conceded"].tolist()
        scored_stats = score_sequence(scored_vals)
        conceded_stats = score_sequence(conceded_vals)
        rows.append({
            "team": team,
            "opponent": last5.iloc[0].get("opponent", "") if not last5.empty else "",
            "team_last5_scored_sequence": sequence_to_emoji(scored_vals),
            "team_last5_conceded_sequence": sequence_to_emoji(conceded_vals),
            "team_avg_scored": scored_stats["last5_avg"],
            "team_avg_conceded": conceded_stats["last5_avg"],
            "team_attack_rating": rating_from_strike_rate(scored_stats["last5_strike_rate"]),
            "team_defence_leak_rating": rating_from_strike_rate(conceded_stats["last5_strike_rate"]),
        })

    return pd.DataFrame(rows).sort_values("team_avg_scored", ascending=False)

def build_opponent_matchup_sequence(player_vs_opponent_history):
    if player_vs_opponent_history is None or player_vs_opponent_history.empty:
        return pd.DataFrame(columns=[
            "player", "team", "opponent", "vs_opponent_sequence",
            "vs_opponent_total", "vs_opponent_avg", "vs_opponent_scored_games",
            "vs_opponent_rating"
        ])

    df = player_vs_opponent_history.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    required = ["player", "team", "opponent", "round", "tries"]
    for col in required:
        if col not in df.columns:
            df[col] = ""

    df["tries"] = pd.to_numeric(df["tries"], errors="coerce").fillna(0).astype(int)
    df["round_sort"] = pd.to_numeric(df["round"].astype(str).str.replace("R", "", regex=False), errors="coerce").fillna(0)

    rows = []
    for (player, team, opponent), group in df.sort_values("round_sort", ascending=False).groupby(["player", "team", "opponent"], dropna=False):
        last5 = group.head(5)
        vals = last5["tries"].tolist()
        stats = score_sequence(vals)
        rows.append({
            "player": player,
            "team": team,
            "opponent": opponent,
            "vs_opponent_sequence": sequence_to_emoji(vals),
            "vs_opponent_total": stats["last5_total"],
            "vs_opponent_avg": stats["last5_avg"],
            "vs_opponent_scored_games": stats["last5_scored_games"],
            "vs_opponent_multi_games": stats["last5_multi_games"],
            "vs_opponent_rating": rating_from_strike_rate(stats["last5_strike_rate"]),
        })

    return pd.DataFrame(rows).sort_values(["vs_opponent_total", "vs_opponent_scored_games"], ascending=False)

def merge_sequence_into_predictions(predictions, player_sequence, opponent_sequence):
    if predictions is None or predictions.empty:
        return predictions

    out = predictions.copy()

    if player_sequence is not None and not player_sequence.empty:
        keep = [c for c in [
            "player", "team", "last5_sequence", "last5_total", "last5_avg",
            "last5_scored_games", "last5_rating"
        ] if c in player_sequence.columns]
        out = out.merge(player_sequence[keep], on=["player", "team"], how="left")

    if opponent_sequence is not None and not opponent_sequence.empty:
        keep = [c for c in [
            "player", "team", "opponent", "vs_opponent_sequence", "vs_opponent_total",
            "vs_opponent_avg", "vs_opponent_scored_games", "vs_opponent_rating"
        ] if c in opponent_sequence.columns]
        out = out.merge(opponent_sequence[keep], on=["player", "team"], how="left")

    return out
