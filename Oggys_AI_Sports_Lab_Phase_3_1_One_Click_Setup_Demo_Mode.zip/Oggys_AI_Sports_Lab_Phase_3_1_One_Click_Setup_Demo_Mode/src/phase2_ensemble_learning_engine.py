import pandas as pd
import numpy as np
from datetime import datetime

def safe_num(v, default=0):
    try:
        if pd.isna(v): return default
        return float(v)
    except Exception:
        return default

def build_ensemble_predictions(matchups, simulations):
    if matchups is None or matchups.empty:
        return pd.DataFrame(columns=["match_id","predicted_winner","final_win_probability","agreement_score","confidence_label"])
    sim = simulations.copy() if simulations is not None else pd.DataFrame()
    rows=[]
    for _,m in matchups.iterrows():
        mid=m.get("match_id","")
        s=sim[sim["match_id"]==mid] if not sim.empty and "match_id" in sim.columns else pd.DataFrame()
        matchup_prob=safe_num(m.get("winner_probability"),0.5)
        matchup_winner=m.get("predicted_winner","")
        if not s.empty:
            sr=s.iloc[0]
            sim_winner=sr.get("predicted_winner","")
            sim_prob=max(safe_num(sr.get("home_win_prob")), safe_num(sr.get("away_win_prob")))
        else:
            sim_winner=matchup_winner
            sim_prob=matchup_prob
        agree = 1 if sim_winner == matchup_winner else 0
        final_prob = matchup_prob*0.55 + sim_prob*0.45
        confidence = (final_prob*70 + agree*30)
        label = "High" if confidence>=80 else ("Medium" if confidence>=65 else "Low")
        rows.append({
            "match_id":mid,"predicted_winner":matchup_winner if final_prob>=0.5 else sim_winner,
            "matchup_model_prob":round(matchup_prob,3),"simulation_model_prob":round(sim_prob,3),
            "final_win_probability":round(final_prob,3),"agreement_score":round(confidence,1),
            "confidence_label":label,"ensemble_summary":f"Matchup and simulation {'agree' if agree else 'do not fully agree'}."
        })
    return pd.DataFrame(rows).sort_values("final_win_probability", ascending=False)

def grade_predictions(ensemble, actual_matches):
    if ensemble is None or ensemble.empty or actual_matches is None or actual_matches.empty:
        return pd.DataFrame(columns=["match_id","predicted_winner","actual_winner","correct","probability"])
    rows=[]
    for _,p in ensemble.iterrows():
        mid=p.get("match_id","")
        a=actual_matches[actual_matches["match_id"]==mid]
        if a.empty: 
            continue
        ar=a.iloc[0]
        actual=ar.get("winner","")
        pred=p.get("predicted_winner","")
        rows.append({"match_id":mid,"predicted_winner":pred,"actual_winner":actual,"correct":1 if pred==actual else 0,"probability":p.get("final_win_probability",0)})
    return pd.DataFrame(rows)

def learning_summary(graded):
    if graded is None or graded.empty:
        return pd.DataFrame([{"metric":"winner_accuracy","value":0,"notes":"No graded predictions yet."}])
    acc=graded["correct"].mean()
    return pd.DataFrame([
        {"metric":"winner_accuracy","value":round(float(acc),3),"notes":f"{int(graded['correct'].sum())}/{len(graded)} correct"},
        {"metric":"predictions_graded","value":len(graded),"notes":"Stored for model governance"},
    ])
