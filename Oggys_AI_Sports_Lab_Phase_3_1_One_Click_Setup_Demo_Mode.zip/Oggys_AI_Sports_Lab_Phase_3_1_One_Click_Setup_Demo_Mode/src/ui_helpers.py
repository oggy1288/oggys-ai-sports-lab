import streamlit as st

def inject_mobile_css():
    st.markdown(
        """
        <style>
        .block-container {
            padding-top: 1.1rem;
            padding-left: 0.9rem;
            padding-right: 0.9rem;
            max-width: 1200px;
        }
        div[data-testid="stMetric"] {
            background: rgba(255,255,255,0.04);
            border: 1px solid rgba(255,255,255,0.08);
            padding: 12px;
            border-radius: 16px;
        }
        div[data-testid="stDataFrame"] {
            border-radius: 14px;
            overflow: hidden;
        }
        .nrl-card {
            padding: 14px;
            border-radius: 16px;
            border: 1px solid rgba(255,255,255,0.14);
            margin-bottom: 10px;
            background: rgba(255,255,255,0.035);
        }
        .nrl-small {
            opacity: 0.82;
            font-size: 0.92rem;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

def mobile_header(title: str, subtitle: str = ""):
    inject_mobile_css()
    st.markdown(
        f"""
        <div style="
            padding: 16px;
            border-radius: 18px;
            background: linear-gradient(135deg, #0f172a, #1e3a8a);
            color: white;
            margin-bottom: 16px;">
            <h1 style="margin:0; font-size: 28px;">{title}</h1>
            <p style="margin:6px 0 0 0; opacity:0.9;">{subtitle}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )

def tip(text: str):
    st.info(text)

def section(title: str, caption: str = ""):
    st.subheader(title)
    if caption:
        st.caption(caption)
