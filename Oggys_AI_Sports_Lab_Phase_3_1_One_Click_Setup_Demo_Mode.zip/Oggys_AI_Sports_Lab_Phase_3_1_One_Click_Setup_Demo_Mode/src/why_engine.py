import pandas as pd
import numpy as np

def traffic_light(value, good=75, ok=55, reverse=False):
    try:
        value = float(value)
    except Exception:
        value = 0

    if reverse:
        if value <= 35:
            return "🟢"
        if value <= 60:
            return "🟡"
        return "🔴"

    if value >= good:
        return "🟢"
    if value >= ok:
        return "🟡"
    return "🔴"

def bar(score, width=10):
    try:
        score = float(score)
    except Exception:
        score = 0
    filled = int(round(max(min(score, 100), 0) / 100 * width))
    return "█" * filled + "░" * (width - filled)

def safe_float(value, default=0):
    try:
        if pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default

def factor_scores(row):
    model_score = safe_float(row.get("model_score", 0))
    last5_avg = safe_float(row.get("last5_avg", 0))
    vs_avg = safe_float(row.get("vs_opponent_avg", 0))
    edge_pct = safe_float(row.get("market_edge_pct", row.get("edge_pct", 0))) * 100
    middle_boost = safe_float(row.get("middle_forward_boost", 0))
    origin_boost = safe_float(row.get("origin_boost", 0))
    milestone_boost = safe_float(row.get("milestone_boost", 0))
    narrative_boost = safe_float(row.get("narrative_boost", 0))

    form_score = min(last5_avg / 1.2 * 100, 100) if last5_avg else min(model_score, 75)
    history_score = min(vs_avg / 1.0 * 100, 100) if vs_avg else 50
    value_score = min(max(edge_pct, 0) / 25 * 100, 100) if edge_pct else 40
    context_score = min((middle_boost + max(origin_boost, 0) + milestone_boost + narrative_boost) / 12 * 100, 100)
    risk_score = 100

    status = str(row.get("status", "")).lower()
    if "out" in status:
        risk_score = 0
    elif "question" in status or "limited" in status:
        risk_score = 45

    return {
        "Overall": round(model_score, 1),
        "Recent Form": round(form_score, 1),
        "Vs Opponent": round(history_score, 1),
        "Market Value": round(value_score, 1),
        "Context Boost": round(context_score, 1),
        "Risk": round(risk_score, 1),
    }

def build_reasons(row):
    reasons = []
    risks = []

    player = row.get("player", "This player")
    opponent = row.get("opponent", "this opponent")

    last5_seq = row.get("last5_sequence", "")
    last5_avg = safe_float(row.get("last5_avg", 0))
    last5_scored = safe_float(row.get("last5_scored_games", 0))

    if last5_seq:
        reasons.append(f"Last 5 form: {last5_seq} — averaging {last5_avg:.2f} tries per game.")
    if last5_scored >= 3:
        reasons.append(f"Has scored in {int(last5_scored)} of the last 5 games.")
    elif last5_scored <= 1 and last5_seq:
        risks.append("Recent scoring strike rate is low.")

    vs_seq = row.get("vs_opponent_sequence", "")
    vs_avg = safe_float(row.get("vs_opponent_avg", 0))
    vs_scored = safe_float(row.get("vs_opponent_scored_games", 0))

    if vs_seq:
        reasons.append(f"Record vs {opponent}: {vs_seq} — averaging {vs_avg:.2f} tries.")
    if vs_scored >= 3:
        reasons.append(f"Strong history against {opponent}.")
    elif vs_seq and vs_scored <= 1:
        risks.append(f"Limited recent try-scoring history against {opponent}.")

    edge_pct = safe_float(row.get("market_edge_pct", row.get("edge_pct", 0))) * 100
    best_odds = row.get("best_odds", row.get("bookmaker_odds", ""))
    fair_odds = row.get("fair_odds", "")

    if edge_pct >= 15:
        reasons.append(f"Market value looks strong: fair odds {fair_odds}, best odds {best_odds}, edge about +{edge_pct:.1f}%.")
    elif edge_pct > 0:
        reasons.append(f"Market price is slightly above model fair odds, giving a small edge.")
    elif best_odds not in ["", None] and not pd.isna(best_odds):
        risks.append("Market odds do not currently show strong value.")

    milestone = row.get("milestone_flag", "")
    if milestone:
        reasons.append(f"Milestone factor detected: {milestone}.")

    origin = row.get("origin_status", "")
    origin_boost = safe_float(row.get("origin_boost", 0))
    if origin and origin != "Not In Origin Frame":
        if origin_boost > 0:
            reasons.append(f"Origin context positive: {origin}.")
        elif origin_boost < 0:
            risks.append(f"Origin fatigue/rest risk: {origin}.")

    narrative = row.get("narrative_flags", "")
    if narrative:
        reasons.append(f"Narrative context: {narrative}.")

    team_dna_summary = row.get("team_dna_summary", "")
    if team_dna_summary:
        reasons.append(f"Team DNA matchup: {team_dna_summary}")

    middle_flag = row.get("middle_forward_flag", "")
    if middle_flag:
        reasons.append(f"Middle-forward try path detected: {row.get('middle_forward_note', middle_flag)}.")

    avg_try_minute = row.get("avg_try_minute", "")
    if avg_try_minute not in ["", None] and not pd.isna(avg_try_minute):
        reasons.append(f"Historical try timing: average try minute around {avg_try_minute}.")

    timing_label = row.get("timing_label", "")
    if timing_label:
        reasons.append(f"Timing profile: {timing_label}.")

    if not reasons:
        reasons.append(f"{player} rates well on the core model inputs.")

    return reasons, risks

def verdict(row):
    score = safe_float(row.get("model_score", 0))
    if score >= 90:
        return "Elite matchup with high scoring potential. One of the top try scorer picks of the round."
    if score >= 80:
        return "Strong matchup. Worth serious attention if the price is right."
    if score >= 70:
        return "Good value watch. Needs price support or positive late team news."
    if score >= 60:
        return "Speculative option. Do not overrate unless market price is generous."
    return "Low-confidence option. Avoid unless new information changes the setup."

def build_why_report(predictions):
    if predictions is None or predictions.empty:
        return pd.DataFrame(columns=[
            "player", "team", "ai_summary", "reasons", "risks", "overall_verdict"
        ])

    rows = []
    for _, row in predictions.iterrows():
        reasons, risks = build_reasons(row)
        scores = factor_scores(row)
        player = row.get("player", "")
        team = row.get("team", "")
        score = safe_float(row.get("model_score", 0))

        summary = f"{player} rates {score:.1f}/100 in the Oggy's AI Sports Lab model."
        if reasons:
            summary += " Main positives: " + "; ".join(reasons[:3])

        rows.append({
            "player": player,
            "team": team,
            "model_score": score,
            "ai_summary": summary,
            "reasons": " | ".join(reasons),
            "risks": " | ".join(risks) if risks else "No major risk flags from current inputs.",
            "overall_verdict": verdict(row),
            "recent_form_score": scores["Recent Form"],
            "vs_opponent_score": scores["Vs Opponent"],
            "market_value_score": scores["Market Value"],
            "context_score": scores["Context Boost"],
            "risk_score": scores["Risk"],
            "overall_score": scores["Overall"],
        })

    return pd.DataFrame(rows).sort_values("model_score", ascending=False)
