import pandas as pd

MILESTONE_GAMES = [50, 100, 150, 200, 250, 300, 350, 400]

def detect_milestone(row):
    current_games = pd.to_numeric(row.get("career_games", 0), errors="coerce")
    if pd.isna(current_games):
        current_games = 0
    next_game_no = int(current_games) + 1
    if next_game_no in MILESTONE_GAMES:
        return next_game_no
    return 0

def milestone_boost(milestone_game):
    try:
        milestone_game = int(milestone_game)
    except Exception:
        return 0
    if milestone_game >= 400:
        return 6
    if milestone_game >= 300:
        return 5
    if milestone_game >= 200:
        return 4
    if milestone_game >= 100:
        return 3
    if milestone_game >= 50:
        return 2
    return 0

def apply_milestone_modifier(players_df):
    if players_df is None or players_df.empty:
        return players_df

    df = players_df.copy()

    if "career_games" not in df.columns:
        df["career_games"] = 0

    df["milestone_game"] = df.apply(detect_milestone, axis=1)
    df["milestone_boost"] = df["milestone_game"].apply(milestone_boost)
    df["milestone_flag"] = df["milestone_game"].apply(
        lambda x: f"{int(x)}th game" if int(x or 0) > 0 else ""
    )
    df["milestone_note"] = df["milestone_game"].apply(
        lambda x: "Team lift / emotional occasion modifier applied" if int(x or 0) > 0 else ""
    )
    return df