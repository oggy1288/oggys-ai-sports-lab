import pandas as pd
import numpy as np

def safe_num(v, default=0):
    try:
        if pd.isna(v): return default
        return float(v)
    except Exception:
        return default

def simulate_matches(matchups, sims=2500, seed=42):
    rng=np.random.default_rng(seed)
    if matchups is None or matchups.empty:
        return pd.DataFrame(columns=["match_id","home_team","away_team","home_win_prob","away_win_prob","avg_home_score","avg_away_score","predicted_score","sim_confidence"])
    rows=[]
    for _,r in matchups.iterrows():
        home=r.get("home_team",""); away=r.get("away_team","")
        hs=safe_num(r.get("home_matchup_score"),50); as_=safe_num(r.get("away_matchup_score"),50)
        home_mu=max(8, 20 + (hs-as_)*0.25 + hs/100*10)
        away_mu=max(8, 20 + (as_-hs)*0.25 + as_/100*10)
        home_scores=rng.poisson(home_mu, sims)
        away_scores=rng.poisson(away_mu, sims)
        home_w=(home_scores>away_scores).mean()
        away_w=(away_scores>home_scores).mean()
        draw=(home_scores==away_scores).mean()
        rows.append({
            "match_id":r.get("match_id",""),"home_team":home,"away_team":away,
            "home_win_prob":round(float(home_w),3),"away_win_prob":round(float(away_w),3),"draw_prob":round(float(draw),3),
            "avg_home_score":round(float(home_scores.mean()),1),"avg_away_score":round(float(away_scores.mean()),1),
            "predicted_score":f"{home} {round(home_scores.mean()):.0f} - {away} {round(away_scores.mean()):.0f}",
            "predicted_winner":home if home_w>=away_w else away,
            "sim_confidence":round(float(max(home_w,away_w))*100,1),
        })
    return pd.DataFrame(rows).sort_values("sim_confidence", ascending=False)

def simulate_try_markets(player_dna, team_dna):
    if player_dna is None or player_dna.empty:
        return pd.DataFrame(columns=["player_id","player_name","team_id","anytime_prob","first_try_prob","two_plus_prob","three_plus_prob"])
    rows=[]
    for _,p in player_dna.iterrows():
        base=safe_num(p.get("overall_player_dna"))/100
        trydna=safe_num(p.get("try_scoring_dna"))/100
        momentum=safe_num(p.get("momentum_dna"))/100
        anytime=min(0.85, max(0.02, base*0.42 + trydna*0.28 + momentum*0.18))
        first=min(0.35, max(0.005, anytime*0.25))
        two=min(0.45, max(0.005, anytime*0.40))
        three=min(0.18, max(0.002, anytime*0.12))
        rows.append({
            "player_id":p.get("player_id",""),"player_name":p.get("player_name",""),"team_id":p.get("team_id",""),"position":p.get("position",""),
            "anytime_prob":round(anytime,3),"first_try_prob":round(first,3),"two_plus_prob":round(two,3),"three_plus_prob":round(three,3),
            "anytime_fair_odds":round(1/anytime,2),"first_try_fair_odds":round(1/first,2),"two_plus_fair_odds":round(1/two,2),"three_plus_fair_odds":round(1/three,2),
        })
    return pd.DataFrame(rows).sort_values("anytime_prob", ascending=False)
