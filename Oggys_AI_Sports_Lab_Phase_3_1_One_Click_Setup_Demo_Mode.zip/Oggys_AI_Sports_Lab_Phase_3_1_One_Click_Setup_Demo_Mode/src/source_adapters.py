import pandas as pd
from datetime import datetime
import uuid

from src.warehouse_engine import (
    WAREHOUSE_SCHEMA,
    replace_warehouse_table,
    append_warehouse_table,
    read_warehouse_table,
    validate_warehouse_table,
    log_import,
)

ADAPTER_CONFIG = {
    "fixtures_results": {
        "target_table": "matches",
        "required_input": ["season", "round", "home_team", "away_team"],
        "field_map": {
            "date": "match_date",
            "kick_off": "kickoff_time",
            "kickoff": "kickoff_time",
            "home": "home_team",
            "away": "away_team",
            "home_points": "home_score",
            "away_points": "away_score",
            "stadium": "venue",
        },
    },
    "player_stats": {
        "target_table": "player_match_stats",
        "required_input": ["match_id", "player_name", "team_id"],
        "field_map": {
            "player": "player_name",
            "team": "team_id",
            "mins": "minutes_played",
            "minutes": "minutes_played",
            "lb": "line_breaks",
            "lba": "line_break_assists",
            "tb": "tackle_breaks",
            "metres": "run_metres",
            "post_contact": "post_contact_metres",
            "mt": "missed_tackles",
        },
    },
    "try_events": {
        "target_table": "try_events",
        "required_input": ["match_id", "minute", "scorer_name"],
        "field_map": {
            "player": "scorer_name",
            "scorer": "scorer_name",
            "team": "scoring_team",
            "try_minute": "minute",
            "edge": "channel",
            "assist": "assister_name",
        },
    },
    "weather": {
        "target_table": "weather_history",
        "required_input": ["match_id"],
        "field_map": {
            "temp": "temperature_c",
            "temperature": "temperature_c",
            "rain": "rainfall_mm",
            "wind": "wind_speed_kmh",
            "humidity": "humidity_pct",
            "condition": "weather_summary",
        },
    },
    "odds": {
        "target_table": "odds_history",
        "required_input": ["match_id", "bookmaker", "market", "selection", "decimal_odds"],
        "field_map": {
            "odds": "decimal_odds",
            "price": "decimal_odds",
            "player": "selection",
            "book": "bookmaker",
            "time": "timestamp",
        },
    },
}

def clean_columns(df):
    out = df.copy()
    out.columns = [str(c).strip().lower().replace(" ", "_") for c in out.columns]
    return out

def build_match_id(row):
    existing = str(row.get("match_id", "")).strip()
    if existing:
        return existing
    season = str(row.get("season", "")).strip()
    rnd = str(row.get("round", "")).strip()
    home = str(row.get("home_team", "")).strip().upper().replace(" ", "")[:3]
    away = str(row.get("away_team", "")).strip().upper().replace(" ", "")[:3]
    if season and rnd and home and away:
        return f"{season}-{rnd}-{home}-{away}"
    return ""

def build_simple_id(prefix, *parts):
    joined = "-".join([str(p).strip().replace(" ", "_") for p in parts if str(p).strip()])
    if joined:
        return f"{prefix}-{joined}"
    return f"{prefix}-{uuid.uuid4()}"

def normalise_channel(value):
    value = str(value).strip().lower()
    if "left" in value:
        return "Left Edge"
    if "right" in value:
        return "Right Edge"
    if "middle" in value or "forward" in value or "ruck" in value:
        return "Middle"
    if "kick" in value:
        return "Kick / Other"
    return value.title() if value else ""

def apply_adapter(adapter_name, raw_df):
    if adapter_name not in ADAPTER_CONFIG:
        raise ValueError(f"Unknown adapter: {adapter_name}")

    cfg = ADAPTER_CONFIG[adapter_name]
    target_table = cfg["target_table"]
    expected_cols = list(WAREHOUSE_SCHEMA[target_table].keys())

    df = clean_columns(raw_df)
    df = df.rename(columns={k: v for k, v in cfg["field_map"].items() if k in df.columns})

    for col in expected_cols:
        if col not in df.columns:
            df[col] = ""

    if target_table == "matches":
        df["match_id"] = df.apply(build_match_id, axis=1)
        if "home_score" in df.columns and "away_score" in df.columns:
            home = pd.to_numeric(df["home_score"], errors="coerce")
            away = pd.to_numeric(df["away_score"], errors="coerce")
            df["margin"] = (home - away).abs()
            df["total_points"] = home.fillna(0) + away.fillna(0)
            df["winner"] = df.apply(
                lambda r: r["home_team"] if pd.to_numeric(r.get("home_score"), errors="coerce") > pd.to_numeric(r.get("away_score"), errors="coerce")
                else (r["away_team"] if pd.to_numeric(r.get("away_score"), errors="coerce") > pd.to_numeric(r.get("home_score"), errors="coerce") else "Draw"),
                axis=1,
            )

    elif target_table == "try_events":
        df["try_id"] = df.apply(lambda r: str(r.get("try_id", "")).strip() or build_simple_id("TRY", r.get("match_id", ""), r.get("minute", ""), r.get("scorer_name", "")), axis=1)
        df["channel"] = df["channel"].apply(normalise_channel)
        df["first_try"] = df["first_try"].replace({True: "YES", False: "NO", "true": "YES", "false": "NO", "1": "YES", "0": "NO"})

    elif target_table == "weather_history":
        df["weather_id"] = df.apply(lambda r: str(r.get("weather_id", "")).strip() or build_simple_id("W", r.get("match_id", "")), axis=1)

    elif target_table == "odds_history":
        df["odds_id"] = df.apply(lambda r: str(r.get("odds_id", "")).strip() or build_simple_id("ODDS", r.get("match_id", ""), r.get("bookmaker", ""), r.get("market", ""), r.get("selection", ""), r.get("timestamp", "")), axis=1)

    elif target_table == "player_match_stats":
        if "player_id" not in df.columns or (df["player_id"].astype(str).str.strip() == "").all():
            df["player_id"] = df.apply(lambda r: build_simple_id("P", r.get("player_name", "")), axis=1)

    return df[expected_cols]

def import_with_adapter(adapter_name, raw_df, dataset_version_id="working", source_file="", mode="replace"):
    clean = apply_adapter(adapter_name, raw_df)
    target_table = ADAPTER_CONFIG[adapter_name]["target_table"]
    issues = validate_warehouse_table(target_table, clean)
    high_issues = issues[issues["severity"].astype(str).str.upper() == "HIGH"] if "severity" in issues.columns else pd.DataFrame()

    if mode == "append":
        append_warehouse_table(target_table, clean)
    else:
        replace_warehouse_table(target_table, clean)

    log_import(
        dataset_version_id=dataset_version_id,
        table_name=target_table,
        source_file=source_file,
        rows_imported=len(clean),
        rows_rejected=0,
        status="SUCCESS_WITH_WARNINGS" if len(high_issues) else "SUCCESS",
        notes=f"Imported with {adapter_name} adapter. High issues: {len(high_issues)}",
    )
    return clean, issues

def adapter_template(adapter_name):
    if adapter_name not in ADAPTER_CONFIG:
        return pd.DataFrame()
    target = ADAPTER_CONFIG[adapter_name]["target_table"]
    return pd.DataFrame(columns=list(WAREHOUSE_SCHEMA[target].keys()))

def adapter_summary():
    rows = []
    for name, cfg in ADAPTER_CONFIG.items():
        rows.append({
            "adapter": name,
            "target_table": cfg["target_table"],
            "required_input": ", ".join(cfg["required_input"]),
            "status": "CSV Ready",
        })
    return pd.DataFrame(rows)
