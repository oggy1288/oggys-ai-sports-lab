import pandas as pd
import numpy as np
from math import exp

def safe_num(value, default=0.0):
    try:
        if pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default

def sigmoid(x):
    try:
        return 1 / (1 + exp(-x))
    except Exception:
        return 0.5

def _latest_rows(df, season_col="season", round_col="round"):
    if df is None or df.empty:
        return df
    out = df.copy()
    if season_col in out.columns:
        out["_season_sort"] = pd.to_numeric(out[season_col], errors="coerce").fillna(0)
    else:
        out["_season_sort"] = 0
    if round_col in out.columns:
        out["_round_sort"] = pd.to_numeric(out[round_col].astype(str).str.extract(r"(\d+)")[0], errors="coerce").fillna(0)
    else:
        out["_round_sort"] = 0
    return out.sort_values(["_season_sort", "_round_sort"])

def rolling_player_features(player_stats, try_events=None):
    if player_stats is None or player_stats.empty:
        return pd.DataFrame(columns=[
            "player_id","player_name","team_id","position","games_sample","tries_l5","tries_l10",
            "tries_season_avg","tries_career_avg","minutes_avg","run_metres_avg","tackle_breaks_avg",
            "line_breaks_avg","form_score","try_form_rating"
        ])
    df = _latest_rows(player_stats)
    for c in ["tries","minutes_played","run_metres","tackle_breaks","line_breaks","try_assists","tackles","missed_tackles","errors"]:
        if c not in df.columns:
            df[c] = 0
        df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)

    rows = []
    group_cols = ["player_id","player_name"]
    for keys, g in df.groupby(group_cols, dropna=False):
        g = g.sort_values(["_season_sort","_round_sort"])
        last5 = g.tail(5)
        last10 = g.tail(10)
        games = len(g)
        tries_l5 = last5["tries"].sum()
        tries_l10 = last10["tries"].sum()
        career_avg = g["tries"].mean() if games else 0
        season = g["_season_sort"].max() if "_season_sort" in g.columns else 0
        season_g = g[g["_season_sort"] == season] if "_season_sort" in g.columns else g
        season_avg = season_g["tries"].mean() if len(season_g) else career_avg
        minutes_avg = last5["minutes_played"].mean() if len(last5) else 0
        run_avg = last5["run_metres"].mean() if len(last5) else 0
        tb_avg = last5["tackle_breaks"].mean() if len(last5) else 0
        lb_avg = last5["line_breaks"].mean() if len(last5) else 0

        form_score = min(100, (tries_l5 / 5 * 55) + (tb_avg * 4) + (lb_avg * 12) + min(minutes_avg,80)/80*15)
        rows.append({
            "player_id": keys[0],
            "player_name": keys[1],
            "team_id": g["team_id"].iloc[-1] if "team_id" in g.columns else "",
            "position": g["position"].iloc[-1] if "position" in g.columns else "",
            "games_sample": games,
            "tries_l5": round(tries_l5, 2),
            "tries_l10": round(tries_l10, 2),
            "tries_season_avg": round(season_avg, 3),
            "tries_career_avg": round(career_avg, 3),
            "minutes_avg": round(minutes_avg, 1),
            "run_metres_avg": round(run_avg, 1),
            "tackle_breaks_avg": round(tb_avg, 2),
            "line_breaks_avg": round(lb_avg, 2),
            "form_score": round(form_score, 1),
            "try_form_rating": round(min(100, (tries_l5/5)*100), 1),
        })
    return pd.DataFrame(rows).sort_values("form_score", ascending=False)

def player_opponent_features(try_events):
    if try_events is None or try_events.empty:
        return pd.DataFrame(columns=["player_id","player_name","opponent","vs_tries","vs_games_scored","vs_avg","vs_sequence","vs_rating"])
    df = _latest_rows(try_events)
    if "scorer_player_id" not in df.columns:
        df["scorer_player_id"] = ""
    if "scorer_name" not in df.columns:
        df["scorer_name"] = ""
    rows=[]
    for (pid,name,opp), g in df.groupby(["scorer_player_id","scorer_name","opponent"], dropna=False):
        g = g.sort_values(["_season_sort","_round_sort"])
        # try_events are only tries, so sequence is tries in last 5 scoring matches against opponent
        per_match = g.groupby("match_id").size().reset_index(name="tries") if "match_id" in g.columns else pd.DataFrame({"tries":[len(g)]})
        vals = per_match["tries"].tail(5).tolist()
        seq = " ".join([f"{int(v)}️⃣" if int(v) <= 9 else "🔟+" for v in vals])
        total = int(per_match["tries"].sum())
        games_scored = len(per_match)
        avg = total / games_scored if games_scored else 0
        rating = min(100, avg*65 + min(games_scored, 5)*7)
        rows.append({"player_id":pid,"player_name":name,"opponent":opp,"vs_tries":total,"vs_games_scored":games_scored,"vs_avg":round(avg,2),"vs_sequence":seq,"vs_rating":round(rating,1)})
    return pd.DataFrame(rows).sort_values(["vs_rating","vs_tries"], ascending=False)

def team_form_features(matches):
    if matches is None or matches.empty:
        return pd.DataFrame(columns=["team","games_sample","points_for_l5","points_against_l5","attack_form","defence_form","momentum_score","win_rate_l5"])
    df = _latest_rows(matches)
    rows_raw=[]
    for _, r in df.iterrows():
        for side in ["home","away"]:
            team = r.get(f"{side}_team","")
            opp_side = "away" if side=="home" else "home"
            pf = safe_num(r.get(f"{side}_score",0))
            pa = safe_num(r.get(f"{opp_side}_score",0))
            rows_raw.append({"team":team,"season":r.get("season",""),"round":r.get("round",""),"points_for":pf,"points_against":pa,"win":1 if pf>pa else 0})
    long = _latest_rows(pd.DataFrame(rows_raw))
    rows=[]
    for team,g in long.groupby("team", dropna=False):
        g = g.sort_values(["_season_sort","_round_sort"])
        l5 = g.tail(5)
        pf = l5["points_for"].mean() if len(l5) else 0
        pa = l5["points_against"].mean() if len(l5) else 0
        win_rate = l5["win"].mean() if len(l5) else 0
        attack = min(100, pf/36*100)
        defence = max(0, 100 - pa/36*100)
        momentum = attack*0.40 + defence*0.35 + win_rate*100*0.25
        rows.append({"team":team,"games_sample":len(g),"points_for_l5":round(pf,1),"points_against_l5":round(pa,1),"attack_form":round(attack,1),"defence_form":round(defence,1),"momentum_score":round(momentum,1),"win_rate_l5":round(win_rate,2)})
    return pd.DataFrame(rows).sort_values("momentum_score", ascending=False)

def build_master_feature_table(player_stats, try_events, matches):
    player_form = rolling_player_features(player_stats, try_events)
    team_form = team_form_features(matches)
    if player_form.empty:
        return player_form

    out = player_form.merge(team_form, left_on="team_id", right_on="team", how="left", suffixes=("_player", "_team"))

    player_games_col = "games_sample_player" if "games_sample_player" in out.columns else "games_sample"
    team_games_col = "games_sample_team" if "games_sample_team" in out.columns else None

    player_games = pd.to_numeric(out[player_games_col], errors="coerce").fillna(0) if player_games_col in out.columns else 0
    team_games = pd.to_numeric(out[team_games_col], errors="coerce").fillna(0) if team_games_col in out.columns else 0

    out["feature_confidence"] = (
        np.minimum(player_games / 20, 1) * 60
        + np.minimum(team_games / 20, 1) * 20
        + 20
    ).clip(0, 100).round(1)

    out["overall_feature_score"] = (
        pd.to_numeric(out["form_score"], errors="coerce").fillna(0) * 0.45
        + pd.to_numeric(out["try_form_rating"], errors="coerce").fillna(0) * 0.25
        + pd.to_numeric(out["attack_form"], errors="coerce").fillna(50) * 0.15
        + pd.to_numeric(out["momentum_score"], errors="coerce").fillna(50) * 0.15
    ).round(1)

    # Keep a simple unsuffixed games_sample column for downstream engines.
    if "games_sample" not in out.columns:
        out["games_sample"] = player_games

    return out.sort_values("overall_feature_score", ascending=False)
