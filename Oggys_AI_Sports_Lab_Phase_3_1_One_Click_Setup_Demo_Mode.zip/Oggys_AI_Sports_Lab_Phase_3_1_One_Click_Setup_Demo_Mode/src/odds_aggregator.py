import pandas as pd
import numpy as np

SUPPORTED_BOOKMAKERS = [
    "Sportsbet",
    "Ladbrokes",
    "TAB",
    "Neds",
    "PointsBet",
    "Bet365",
    "Unibet",
    "Bet Right",
    "Other",
]

REQUIRED_ODDS_COLUMNS = [
    "fixture_id",
    "round",
    "player",
    "team",
    "market",
    "bookmaker",
    "odds",
    "timestamp",
]

def normalise_odds_table(df):
    if df is None or df.empty:
        return pd.DataFrame(columns=REQUIRED_ODDS_COLUMNS)

    out = df.copy()
    out.columns = [str(c).strip().lower() for c in out.columns]

    rename_map = {
        "price": "odds",
        "decimal_odds": "odds",
        "book": "bookmaker",
        "sportsbook": "bookmaker",
        "name": "player",
        "selection": "player",
    }
    out = out.rename(columns={k: v for k, v in rename_map.items() if k in out.columns})

    for col in REQUIRED_ODDS_COLUMNS:
        if col not in out.columns:
            out[col] = ""

    out["odds"] = pd.to_numeric(out["odds"], errors="coerce")
    out = out[out["odds"].notna()]
    out = out[out["odds"] >= 1.01]
    out["market"] = out["market"].replace("", "Anytime Try")
    out["bookmaker"] = out["bookmaker"].replace("", "Other")
    return out[REQUIRED_ODDS_COLUMNS]

def aggregate_best_odds(odds_df):
    odds = normalise_odds_table(odds_df)

    if odds.empty:
        return pd.DataFrame(columns=[
            "player", "team", "market", "best_odds", "best_bookmaker",
            "bookmaker_count", "average_odds", "lowest_odds"
        ])

    rows = []
    group_cols = ["player", "team", "market"]
    for keys, group in odds.groupby(group_cols, dropna=False):
        group = group.sort_values("odds", ascending=False)
        best = group.iloc[0]
        rows.append({
            "player": keys[0],
            "team": keys[1],
            "market": keys[2],
            "best_odds": round(float(best["odds"]), 2),
            "best_bookmaker": best["bookmaker"],
            "bookmaker_count": int(group["bookmaker"].nunique()),
            "average_odds": round(float(group["odds"].mean()), 2),
            "lowest_odds": round(float(group["odds"].min()), 2),
        })
    return pd.DataFrame(rows).sort_values(["market", "best_odds"], ascending=[True, False])

def compare_model_to_market(predictions_df, best_odds_df):
    if predictions_df is None or predictions_df.empty:
        return pd.DataFrame()

    pred = predictions_df.copy()
    odds = best_odds_df.copy() if best_odds_df is not None else pd.DataFrame()

    if odds.empty:
        pred["best_odds"] = np.nan
        pred["best_bookmaker"] = ""
        pred["market_edge_pct"] = 0
        pred["ev_pct"] = 0
        pred["odds_value_flag"] = "No Odds"
        return pred

    merge_cols = ["player"]
    if "team" in pred.columns and "team" in odds.columns:
        merge_cols = ["player", "team"]

    merged = pred.merge(
        odds[[c for c in ["player", "team", "market", "best_odds", "best_bookmaker", "bookmaker_count", "average_odds"] if c in odds.columns]],
        on=merge_cols,
        how="left"
    )

    if "fair_odds" in merged.columns:
        merged["fair_odds"] = pd.to_numeric(merged["fair_odds"], errors="coerce")
    else:
        merged["fair_odds"] = np.nan

    merged["best_odds"] = pd.to_numeric(merged["best_odds"], errors="coerce")
    merged["market_edge_pct"] = ((merged["best_odds"] / merged["fair_odds"]) - 1).replace([np.inf, -np.inf], np.nan).fillna(0)

    if "model_probability" in merged.columns:
        merged["model_probability"] = pd.to_numeric(merged["model_probability"], errors="coerce").fillna(0)
        merged["ev_pct"] = ((merged["model_probability"] * merged["best_odds"]) - 1).fillna(0)
    else:
        merged["ev_pct"] = merged["market_edge_pct"]

    def flag(row):
        edge = row.get("market_edge_pct", 0)
        score = row.get("model_score", 0)
        try:
            score = float(score)
        except Exception:
            score = 0
        if pd.isna(row.get("best_odds", np.nan)):
            return "No Odds"
        if edge >= 0.15 and score >= 85:
            return "Elite Price"
        if edge >= 0.08 and score >= 75:
            return "Strong Value"
        if edge >= 0.03 and score >= 70:
            return "Small Edge"
        if edge > 0:
            return "Tiny Edge"
        return "No Value"

    merged["odds_value_flag"] = merged.apply(flag, axis=1)
    return merged.sort_values(["market_edge_pct", "model_score"], ascending=[False, False])

def build_odds_import_template():
    return pd.DataFrame([
        {
            "fixture_id": "R18-G1",
            "round": "18",
            "player": "Player A",
            "team": "Broncos",
            "market": "Anytime Try",
            "bookmaker": "Sportsbet",
            "odds": 2.20,
            "timestamp": "2026-07-01 18:00",
        },
        {
            "fixture_id": "R18-G1",
            "round": "18",
            "player": "Player A",
            "team": "Broncos",
            "market": "Anytime Try",
            "bookmaker": "Ladbrokes",
            "odds": 2.35,
            "timestamp": "2026-07-01 18:00",
        },
    ])
