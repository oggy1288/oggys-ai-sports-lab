from src.name_matching import build_alias_table, resolve_names_against_master
import pandas as pd

def _norm_name(series):
    return (
        series.astype(str)
        .str.strip()
        .str.lower()
        .str.replace(r"[^a-z0-9 ]", "", regex=True)
        .str.replace(r"\s+", " ", regex=True)
    )

def build_player_integrity_report(player_stats, team_lists, odds, injuries):
    issues = []

    player_stats = player_stats.copy() if player_stats is not None else pd.DataFrame()
    team_lists = team_lists.copy() if team_lists is not None else pd.DataFrame()
    odds = odds.copy() if odds is not None else pd.DataFrame()
    injuries = injuries.copy() if injuries is not None else pd.DataFrame()

    if player_stats.empty:
        issues.append({
            "severity": "HIGH",
            "area": "Player Database",
            "issue": "No player_stats data loaded",
            "player": "",
            "team": "",
            "fix": "Upload or manually add player stats before running predictions."
        })
        return pd.DataFrame(issues)

    if team_lists.empty:
        issues.append({
            "severity": "HIGH",
            "area": "Weekly Team Lists",
            "issue": "No team_lists data loaded",
            "player": "",
            "team": "",
            "fix": "Upload or manually add this week's team lists. Only players in weekly games should show by default."
        })
        return pd.DataFrame(issues)

    if "player" not in player_stats.columns or "player" not in team_lists.columns:
        issues.append({
            "severity": "HIGH",
            "area": "Required Columns",
            "issue": "player_stats and team_lists both need a player column",
            "player": "",
            "team": "",
            "fix": "Add a player column to both tables."
        })
        return pd.DataFrame(issues)

    player_stats["_name_key"] = _norm_name(player_stats["player"])
    team_lists["_name_key"] = _norm_name(team_lists["player"])

    db_keys = set(player_stats["_name_key"].dropna())
    weekly_keys = set(team_lists["_name_key"].dropna())

    alias_table = build_alias_table(player_stats)
    resolved_weekly = resolve_names_against_master(team_lists, alias_table)
    if "match_type" in resolved_weekly.columns:
        missing_from_db = resolved_weekly[resolved_weekly["match_type"] == "No Match"]
    else:
        missing_from_db = team_lists[~team_lists["_name_key"].isin(db_keys)]
    for _, row in missing_from_db.iterrows():
        issues.append({
            "severity": "HIGH",
            "area": "Missing Player",
            "issue": "Player is named in this week's team list but is missing from player_stats",
            "player": row.get("player", ""),
            "team": row.get("team", ""),
            "fix": "Add this player to player_stats or fix the spelling/name format."
        })

    not_in_week = player_stats[~player_stats["_name_key"].isin(weekly_keys)]
    for _, row in not_in_week.head(200).iterrows():
        issues.append({
            "severity": "INFO",
            "area": "Not Selected This Week",
            "issue": "Player exists in player_stats but is not in this week's team list",
            "player": row.get("player", ""),
            "team": row.get("team", ""),
            "fix": "No action needed unless they should be selected this week."
        })

    duplicates = player_stats[player_stats.duplicated("_name_key", keep=False)].sort_values("_name_key")
    for _, row in duplicates.iterrows():
        issues.append({
            "severity": "MEDIUM",
            "area": "Duplicate Player",
            "issue": "Duplicate player name found in player_stats",
            "player": row.get("player", ""),
            "team": row.get("team", ""),
            "fix": "Merge duplicate records or add a unique player ID later."
        })

    required_player_cols = ["team", "position", "tries", "games", "last5_tries", "avg_minutes"]
    for col in required_player_cols:
        if col not in player_stats.columns:
            issues.append({
                "severity": "HIGH",
                "area": "Missing Column",
                "issue": f"player_stats missing required column: {col}",
                "player": "",
                "team": "",
                "fix": f"Add column {col}."
            })
        else:
            blanks = player_stats[player_stats[col].isna() | (player_stats[col].astype(str).str.strip() == "")]
            for _, row in blanks.head(100).iterrows():
                issues.append({
                    "severity": "MEDIUM",
                    "area": "Blank Player Data",
                    "issue": f"Blank value in player_stats column: {col}",
                    "player": row.get("player", ""),
                    "team": row.get("team", ""),
                    "fix": f"Fill in {col} for this player."
                })

    if not odds.empty and "player" in odds.columns:
        odds["_name_key"] = _norm_name(odds["player"])
        odds_keys = set(odds["_name_key"].dropna())
        selected_without_odds = team_lists[~team_lists["_name_key"].isin(odds_keys)]
        for _, row in selected_without_odds.head(150).iterrows():
            issues.append({
                "severity": "MEDIUM",
                "area": "Missing Odds",
                "issue": "Selected player has no odds row",
                "player": row.get("player", ""),
                "team": row.get("team", ""),
                "fix": "Add odds if you want value betting calculations for this player."
            })
    else:
        issues.append({
            "severity": "MEDIUM",
            "area": "Odds",
            "issue": "No odds data loaded",
            "player": "",
            "team": "",
            "fix": "Add odds to calculate bookie edge and bet recommendations."
        })

    if not injuries.empty and "player" in injuries.columns:
        injuries["_name_key"] = _norm_name(injuries["player"])
        injury_keys = set(injuries["_name_key"].dropna())
        selected_without_injury_status = team_lists[~team_lists["_name_key"].isin(injury_keys)]
        for _, row in selected_without_injury_status.head(100).iterrows():
            issues.append({
                "severity": "LOW",
                "area": "Missing Injury Status",
                "issue": "Selected player has no injury/team-news status",
                "player": row.get("player", ""),
                "team": row.get("team", ""),
                "fix": "Optional: add Healthy/Questionable/Out status."
            })

    if not issues:
        issues.append({
            "severity": "PASS",
            "area": "Integrity",
            "issue": "No major player integrity issues found",
            "player": "",
            "team": "",
            "fix": "Ready to run predictions."
        })

    return pd.DataFrame(issues)

def filter_predictions_to_week(predictions, team_lists):
    if predictions is None or predictions.empty or team_lists is None or team_lists.empty:
        return predictions
    if "player" not in predictions.columns or "player" not in team_lists.columns:
        return predictions

    pred = predictions.copy()
    teams = team_lists.copy()
    pred["_name_key"] = _norm_name(pred["player"])
    teams["_name_key"] = _norm_name(teams["player"])
    filtered = pred[pred["_name_key"].isin(set(teams["_name_key"]))].drop(columns=["_name_key"])
    return filtered