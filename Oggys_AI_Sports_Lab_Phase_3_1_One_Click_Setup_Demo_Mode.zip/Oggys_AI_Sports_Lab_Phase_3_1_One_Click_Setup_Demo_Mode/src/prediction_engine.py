import pandas as pd
import numpy as np

def confidence_band(score):
    if score >= 90: return "Elite"
    if score >= 80: return "Strong"
    if score >= 70: return "Value"
    if score >= 60: return "Watch"
    return "Avoid"

def recommendation(edge, score):
    if edge >= 0.15 and score >= 85: return "Elite Bet"
    if edge >= 0.08 and score >= 75: return "Strong Bet"
    if edge >= 0.03 and score >= 70: return "Small Value"
    return "No Bet"

def build_predictions(tables):
    players = tables.get("player_stats", pd.DataFrame()).copy()
    odds = tables.get("odds", pd.DataFrame()).copy()
    injuries = tables.get("injuries", pd.DataFrame()).copy()
    if players.empty:
        return pd.DataFrame(columns=["player","team","position","model_score","model_probability","fair_odds","bookmaker_odds","edge_pct","confidence_band","bet_recommendation"])
    for col in ["tries", "games", "last5_tries", "avg_minutes"]:
        players[col] = pd.to_numeric(players.get(col, 0), errors="coerce").fillna(0)
    players["try_rate"] = np.where(players["games"] > 0, players["tries"] / players["games"], 0)
    players["last5_rate"] = players["last5_tries"] / 5
    players["minutes_factor"] = (players["avg_minutes"] / 80).clip(0, 1.15)
    role_boost = players.get("goal_line_role", "").astype(str).str.lower().map({"high": 1.12, "medium": 1.0, "low": 0.88}).fillna(1.0)
    players["model_score"] = (players["try_rate"].clip(0,1)*40 + players["last5_rate"].clip(0,1)*30 + players["minutes_factor"]*20 + role_boost*10).clip(0,100)
    if not injuries.empty and "player" in injuries.columns:
        players = players.merge(injuries[["player", "status", "minutes_adjustment"]], on="player", how="left")
        players["minutes_adjustment"] = pd.to_numeric(players["minutes_adjustment"], errors="coerce").fillna(0)
        players.loc[players["status"].astype(str).str.lower().eq("out"), "model_score"] = 0
        players["model_score"] = (players["model_score"] + players["minutes_adjustment"]).clip(0,100)
    players["model_probability"] = (players["model_score"] / 100 * 0.72).clip(0.01, 0.85)
    players["fair_odds"] = (1 / players["model_probability"]).round(2)
    if not odds.empty and "player" in odds.columns:
        odds_any = odds[odds.get("market", "").astype(str).str.lower().str.contains("anytime", na=False)].copy()
        odds_any["odds"] = pd.to_numeric(odds_any["odds"], errors="coerce")
        odds_any = odds_any.sort_values("odds", ascending=False).drop_duplicates("player")
        players = players.merge(odds_any[["player", "odds"]], on="player", how="left").rename(columns={"odds":"bookmaker_odds"})
    else:
        players["bookmaker_odds"] = np.nan
    players["edge_pct"] = ((players["bookmaker_odds"] / players["fair_odds"]) - 1).fillna(0).round(4)
    players["confidence_band"] = players["model_score"].apply(confidence_band)
    players["bet_recommendation"] = players.apply(lambda r: recommendation(r["edge_pct"], r["model_score"]), axis=1)
    return players[["player","team","position","model_score","model_probability","fair_odds","bookmaker_odds","edge_pct","confidence_band","bet_recommendation"]].sort_values("model_score", ascending=False)