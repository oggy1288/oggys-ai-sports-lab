import pandas as pd
import numpy as np

def safe_num(v, default=0):
    try:
        if pd.isna(v): return default
        return float(v)
    except Exception:
        return default

def channel_norm(x):
    s=str(x).lower()
    if "left" in s: return "Left Edge"
    if "right" in s: return "Right Edge"
    if "middle" in s or "ruck" in s: return "Middle"
    if "kick" in s: return "Kick / Other"
    return "Kick / Other"

def build_team_dna_2(matches, try_events, player_stats):
    teams=set()
    for df,col in [(matches,"home_team"),(matches,"away_team"),(try_events,"scoring_team"),(player_stats,"team_id")]:
        if df is not None and not df.empty and col in df.columns:
            teams.update([x for x in df[col].dropna().astype(str).unique() if x])
    rows=[]
    tf = pd.DataFrame()
    if matches is not None and not matches.empty:
        raw=[]
        for _,r in matches.iterrows():
            for side in ["home","away"]:
                opp = "away" if side=="home" else "home"
                pf=safe_num(r.get(f"{side}_score",0)); pa=safe_num(r.get(f"{opp}_score",0))
                raw.append({"team":r.get(f"{side}_team",""),"points_for":pf,"points_against":pa,"win":1 if pf>pa else 0})
        tf=pd.DataFrame(raw)
    te = try_events.copy() if try_events is not None else pd.DataFrame()
    if not te.empty and "channel" in te.columns:
        te["channel_clean"]=te["channel"].apply(channel_norm)
    for team in teams:
        tg = tf[tf["team"]==team] if not tf.empty else pd.DataFrame()
        attack = min(100, (tg["points_for"].tail(5).mean() if len(tg) else 18)/36*100)
        defence = max(0, 100 - (tg["points_against"].tail(5).mean() if len(tg) else 24)/36*100)
        momentum = (tg["win"].tail(5).mean()*100 if len(tg) else 50)
        tt = te[te["scoring_team"]==team] if not te.empty and "scoring_team" in te.columns else pd.DataFrame()
        counts = tt["channel_clean"].value_counts(normalize=True).to_dict() if not tt.empty and "channel_clean" in tt.columns else {}
        left=counts.get("Left Edge",0)*100; mid=counts.get("Middle",0)*100; right=counts.get("Right Edge",0)*100; kick=counts.get("Kick / Other",0)*100
        primary = max({"Left Edge":left,"Middle":mid,"Right Edge":right,"Kick / Other":kick}, key={"Left Edge":left,"Middle":mid,"Right Edge":right,"Kick / Other":kick}.get)
        overall=attack*0.35+defence*0.30+momentum*0.20+max(left,mid,right,kick)*0.15
        rows.append({
            "team":team,"attack_dna":round(attack,1),"defence_dna":round(defence,1),"momentum_dna":round(momentum,1),
            "left_edge_attack_pct":round(left,1),"middle_attack_pct":round(mid,1),"right_edge_attack_pct":round(right,1),"kick_other_pct":round(kick,1),
            "primary_attack_channel":primary,"overall_team_dna":round(overall,1),
            "team_identity":"Territory/Pressure" if defence>attack else "Attacking/Expansion"
        })
    return pd.DataFrame(rows).sort_values("overall_team_dna", ascending=False)
