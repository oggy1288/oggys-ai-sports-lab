import pandas as pd
import numpy as np

WINDOWS = {
    "0_20": (0, 20),
    "20_40": (21, 40),
    "40_60": (41, 60),
    "60_80": (61, 80),
}

def safe_num(value, default=0):
    try:
        if pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default

def minute_window(minute):
    m = safe_num(minute, 0)
    if m <= 20:
        return "0_20"
    if m <= 40:
        return "20_40"
    if m <= 60:
        return "40_60"
    return "60_80"

def bar_pct(value, width=10):
    try:
        value = float(value)
    except Exception:
        value = 0
    value = max(min(value, 1), 0)
    filled = int(round(value * width))
    return "█" * filled + "░" * (width - filled)

def normalise_try_history(df):
    columns = [
        "player", "team", "opponent", "round", "date", "venue",
        "minute", "try_number", "is_first_try", "result",
        "channel", "position"
    ]
    if df is None or df.empty:
        return pd.DataFrame(columns=columns)

    out = df.copy()
    out.columns = [str(c).strip().lower() for c in out.columns]
    rename = {
        "try_minute": "minute",
        "mins": "minute",
        "match_minute": "minute",
        "first_try": "is_first_try",
        "try_no": "try_number",
        "edge": "channel",
    }
    out = out.rename(columns={k: v for k, v in rename.items() if k in out.columns})

    for col in columns:
        if col not in out.columns:
            out[col] = ""

    out["minute"] = pd.to_numeric(out["minute"], errors="coerce").fillna(0)
    out["try_number"] = pd.to_numeric(out["try_number"], errors="coerce").fillna(1)
    out["is_first_try"] = out["is_first_try"].astype(str).str.lower().isin(["true", "yes", "1", "y", "first"])
    out["minute_window"] = out["minute"].apply(minute_window)
    return out[columns + ["minute_window"]]

def build_player_try_timing_profile(try_history, games_played_df=None):
    hist = normalise_try_history(try_history)
    if hist.empty:
        return pd.DataFrame(columns=[
            "player", "team", "tries", "avg_try_minute", "avg_first_try_minute",
            "first_try_count", "first_try_rate", "two_plus_count", "three_plus_count",
            "pct_0_20", "pct_20_40", "pct_40_60", "pct_60_80",
            "timing_profile", "timing_label"
        ])

    rows = []
    for (player, team), group in hist.groupby(["player", "team"], dropna=False):
        tries = len(group)
        avg_min = group["minute"].mean() if tries else 0
        first_tries = group[group["is_first_try"] == True]
        avg_first = first_tries["minute"].mean() if not first_tries.empty else 0

        # Multi-try counts are per match by round/opponent/date.
        match_cols = ["round", "opponent", "date"]
        per_match = group.groupby(match_cols, dropna=False).size().reset_index(name="tries_in_match")
        two_plus = int((per_match["tries_in_match"] >= 2).sum())
        three_plus = int((per_match["tries_in_match"] >= 3).sum())

        counts = group["minute_window"].value_counts().to_dict()
        pct = {w: counts.get(w, 0) / tries if tries else 0 for w in WINDOWS}

        if pct["0_20"] >= 0.40:
            label = "Early Threat"
        elif pct["60_80"] >= 0.40:
            label = "Late Finisher"
        elif (pct["40_60"] + pct["60_80"]) >= 0.60:
            label = "Second Half Specialist"
        else:
            label = "Balanced Scorer"

        rows.append({
            "player": player,
            "team": team,
            "tries": tries,
            "avg_try_minute": round(avg_min, 1),
            "avg_first_try_minute": round(avg_first, 1) if avg_first else "",
            "first_try_count": int(first_tries.shape[0]),
            "first_try_rate": round(int(first_tries.shape[0]) / tries, 3) if tries else 0,
            "two_plus_count": two_plus,
            "three_plus_count": three_plus,
            "pct_0_20": round(pct["0_20"], 3),
            "pct_20_40": round(pct["20_40"], 3),
            "pct_40_60": round(pct["40_60"], 3),
            "pct_60_80": round(pct["60_80"], 3),
            "timing_profile": f"0-20 {bar_pct(pct['0_20'])} | 20-40 {bar_pct(pct['20_40'])} | 40-60 {bar_pct(pct['40_60'])} | 60-80 {bar_pct(pct['60_80'])}",
            "timing_label": label,
        })

    return pd.DataFrame(rows).sort_values(["tries", "first_try_count"], ascending=False)

def build_team_try_timeline(try_history):
    hist = normalise_try_history(try_history)
    if hist.empty:
        return pd.DataFrame(columns=[
            "team", "tries", "pct_0_20", "pct_20_40", "pct_40_60", "pct_60_80",
            "team_timing_profile", "team_timing_label"
        ])

    rows = []
    for team, group in hist.groupby("team", dropna=False):
        tries = len(group)
        counts = group["minute_window"].value_counts().to_dict()
        pct = {w: counts.get(w, 0) / tries if tries else 0 for w in WINDOWS}

        if pct["0_20"] >= 0.35:
            label = "Fast Starter"
        elif pct["60_80"] >= 0.35:
            label = "Late Pressure Team"
        else:
            label = "Balanced Attack"

        rows.append({
            "team": team,
            "tries": tries,
            "pct_0_20": round(pct["0_20"], 3),
            "pct_20_40": round(pct["20_40"], 3),
            "pct_40_60": round(pct["40_60"], 3),
            "pct_60_80": round(pct["60_80"], 3),
            "team_timing_profile": f"0-20 {bar_pct(pct['0_20'])} | 20-40 {bar_pct(pct['20_40'])} | 40-60 {bar_pct(pct['40_60'])} | 60-80 {bar_pct(pct['60_80'])}",
            "team_timing_label": label,
        })

    return pd.DataFrame(rows).sort_values("tries", ascending=False)

def build_team_conceded_timeline(try_history):
    hist = normalise_try_history(try_history)
    if hist.empty:
        return pd.DataFrame(columns=[
            "team", "tries_conceded", "concede_pct_0_20", "concede_pct_20_40",
            "concede_pct_40_60", "concede_pct_60_80", "concede_timing_profile",
            "concede_timing_label"
        ])

    # Opponent is the team conceding the try.
    rows = []
    for team, group in hist.groupby("opponent", dropna=False):
        tries = len(group)
        counts = group["minute_window"].value_counts().to_dict()
        pct = {w: counts.get(w, 0) / tries if tries else 0 for w in WINDOWS}

        if pct["0_20"] >= 0.35:
            label = "Vulnerable Early"
        elif pct["60_80"] >= 0.35:
            label = "Leaks Late"
        else:
            label = "Balanced Concession"

        rows.append({
            "team": team,
            "tries_conceded": tries,
            "concede_pct_0_20": round(pct["0_20"], 3),
            "concede_pct_20_40": round(pct["20_40"], 3),
            "concede_pct_40_60": round(pct["40_60"], 3),
            "concede_pct_60_80": round(pct["60_80"], 3),
            "concede_timing_profile": f"0-20 {bar_pct(pct['0_20'])} | 20-40 {bar_pct(pct['20_40'])} | 40-60 {bar_pct(pct['40_60'])} | 60-80 {bar_pct(pct['60_80'])}",
            "concede_timing_label": label,
        })

    return pd.DataFrame(rows).sort_values("tries_conceded", ascending=False)

def build_try_market_seed(predictions, player_timing, team_timeline, conceded_timeline):
    if predictions is None or predictions.empty:
        return pd.DataFrame()

    out = predictions.copy()
    if player_timing is not None and not player_timing.empty:
        keep = [c for c in [
            "player", "team", "avg_try_minute", "avg_first_try_minute", "first_try_count",
            "first_try_rate", "two_plus_count", "three_plus_count",
            "pct_0_20", "pct_60_80", "timing_profile", "timing_label"
        ] if c in player_timing.columns]
        out = out.merge(player_timing[keep], on=["player", "team"], how="left")

    if team_timeline is not None and not team_timeline.empty:
        keep = [c for c in ["team", "team_timing_profile", "team_timing_label", "pct_0_20"] if c in team_timeline.columns]
        team_copy = team_timeline[keep].rename(columns={"pct_0_20": "team_pct_0_20"})
        out = out.merge(team_copy, on="team", how="left")

    if conceded_timeline is not None and not conceded_timeline.empty and "opponent" in out.columns:
        con = conceded_timeline.rename(columns={
            "team": "opponent",
            "concede_pct_0_20": "opponent_concede_pct_0_20",
            "concede_pct_60_80": "opponent_concede_pct_60_80",
        })
        keep = [c for c in [
            "opponent", "opponent_concede_pct_0_20", "opponent_concede_pct_60_80",
            "concede_timing_profile", "concede_timing_label"
        ] if c in con.columns]
        out = out.merge(con[keep], on="opponent", how="left")

    # Seed probabilities for future V8.1 full market model.
    base_prob = pd.to_numeric(out.get("model_probability", 0), errors="coerce").fillna(0)
    first_rate = pd.to_numeric(out.get("first_try_rate", 0), errors="coerce").fillna(0)
    early_player = pd.to_numeric(out.get("pct_0_20", 0), errors="coerce").fillna(0)
    early_team = pd.to_numeric(out.get("team_pct_0_20", 0), errors="coerce").fillna(0)
    early_opp = pd.to_numeric(out.get("opponent_concede_pct_0_20", 0), errors="coerce").fillna(0)

    out["first_try_seed_prob"] = (base_prob * 0.22 + first_rate * 0.22 + early_player * 0.18 + early_team * 0.18 + early_opp * 0.20).clip(0.01, 0.35).round(3)
    out["first_try_seed_fair_odds"] = (1 / out["first_try_seed_prob"]).round(2)

    two_plus_count = pd.to_numeric(out.get("two_plus_count", 0), errors="coerce").fillna(0)
    three_plus_count = pd.to_numeric(out.get("three_plus_count", 0), errors="coerce").fillna(0)
    out["two_plus_seed_prob"] = (base_prob * 0.38 + (two_plus_count / 10).clip(0, 0.40)).clip(0.01, 0.45).round(3)
    out["three_plus_seed_prob"] = (base_prob * 0.12 + (three_plus_count / 20).clip(0, 0.15)).clip(0.005, 0.18).round(3)
    out["two_plus_seed_fair_odds"] = (1 / out["two_plus_seed_prob"]).round(2)
    out["three_plus_seed_fair_odds"] = (1 / out["three_plus_seed_prob"]).round(2)

    return out
