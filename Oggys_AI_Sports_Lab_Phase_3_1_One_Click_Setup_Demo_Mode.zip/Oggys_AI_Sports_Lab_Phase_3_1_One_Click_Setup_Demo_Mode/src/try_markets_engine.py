import pandas as pd
import numpy as np

TRY_MARKETS = ["Anytime Try", "First Try", "2+ Tries", "3+ Tries"]

def safe_num(value, default=0):
    try:
        if pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default

def fair_odds(prob):
    prob = safe_num(prob, 0)
    if prob <= 0:
        return ""
    return round(1 / prob, 2)

def market_flag(edge, prob, market):
    edge = safe_num(edge, 0)
    prob = safe_num(prob, 0)

    if edge >= 0.25:
        return "💎 Elite Value"
    if edge >= 0.15:
        return "⭐ Strong Value"
    if edge >= 0.08:
        return "✅ Good Value"
    if edge >= 0.03:
        return "🟡 Small Edge"
    if prob > 0:
        return "No Value"
    return "No Data"

def build_try_market_predictions(predictions, timing_seed, best_odds):
    if predictions is None or predictions.empty:
        return pd.DataFrame(columns=[
            "player", "team", "position", "market", "probability",
            "fair_odds", "best_odds", "best_bookmaker", "edge_pct",
            "ev_pct", "market_flag", "source"
        ])

    pred = predictions.copy()
    timing = timing_seed.copy() if timing_seed is not None else pd.DataFrame()
    odds = best_odds.copy() if best_odds is not None else pd.DataFrame()

    if not timing.empty:
        keep = [c for c in [
            "player", "team", "first_try_seed_prob", "first_try_seed_fair_odds",
            "two_plus_seed_prob", "two_plus_seed_fair_odds",
            "three_plus_seed_prob", "three_plus_seed_fair_odds",
            "avg_try_minute", "avg_first_try_minute", "timing_profile", "timing_label"
        ] if c in timing.columns]
        pred = pred.merge(timing[keep].drop_duplicates(["player", "team"]), on=["player", "team"], how="left")

    rows = []
    for _, r in pred.iterrows():
        anytime_prob = safe_num(r.get("model_probability", 0))
        first_prob = safe_num(r.get("first_try_seed_prob", 0))
        two_prob = safe_num(r.get("two_plus_seed_prob", 0))
        three_prob = safe_num(r.get("three_plus_seed_prob", 0))

        # Fallback probabilities if timing seed has not been generated yet.
        if first_prob <= 0:
            first_prob = max(min(anytime_prob * 0.28, 0.30), 0.01)
        if two_prob <= 0:
            two_prob = max(min(anytime_prob * 0.42, 0.45), 0.01)
        if three_prob <= 0:
            three_prob = max(min(anytime_prob * 0.11, 0.16), 0.005)

        market_probs = {
            "Anytime Try": anytime_prob,
            "First Try": first_prob,
            "2+ Tries": two_prob,
            "3+ Tries": three_prob,
        }

        for market, prob in market_probs.items():
            rows.append({
                "player_id": r.get("player_id", ""),
                "player": r.get("player", ""),
                "team": r.get("team", ""),
                "position": r.get("position", ""),
                "market": market,
                "probability": round(prob, 3),
                "fair_odds": fair_odds(prob),
                "model_score": r.get("model_score", ""),
                "last5_sequence": r.get("last5_sequence", ""),
                "vs_opponent_sequence": r.get("vs_opponent_sequence", ""),
                "avg_try_minute": r.get("avg_try_minute", ""),
                "avg_first_try_minute": r.get("avg_first_try_minute", ""),
                "timing_profile": r.get("timing_profile", ""),
                "timing_label": r.get("timing_label", ""),
                "source": "Model + Try Timing",
            })

    out = pd.DataFrame(rows)

    if odds is not None and not odds.empty:
        odds = odds.copy()
        odds.columns = [str(c).strip().lower() for c in odds.columns]
        if "best_odds" in odds.columns:
            odds["best_odds"] = pd.to_numeric(odds["best_odds"], errors="coerce")
        keep = [c for c in ["player", "team", "market", "best_odds", "best_bookmaker"] if c in odds.columns]
        if keep:
            merge_cols = ["player", "market"]
            if "team" in keep:
                merge_cols = ["player", "team", "market"]
            out = out.merge(odds[keep], on=merge_cols, how="left")
    else:
        out["best_odds"] = np.nan
        out["best_bookmaker"] = ""

    out["best_odds"] = pd.to_numeric(out.get("best_odds", np.nan), errors="coerce")
    out["fair_odds"] = pd.to_numeric(out["fair_odds"], errors="coerce")
    out["edge_pct"] = ((out["best_odds"] / out["fair_odds"]) - 1).replace([np.inf, -np.inf], np.nan).fillna(0).round(4)
    out["ev_pct"] = ((out["probability"] * out["best_odds"]) - 1).replace([np.inf, -np.inf], np.nan).fillna(0).round(4)
    out["market_flag"] = out.apply(lambda row: market_flag(row["edge_pct"], row["probability"], row["market"]), axis=1)

    return out.sort_values(["market", "probability", "edge_pct"], ascending=[True, False, False])

def build_top_market_board(try_market_predictions):
    if try_market_predictions is None or try_market_predictions.empty:
        return pd.DataFrame()

    df = try_market_predictions.copy()
    boards = []
    for market, group in df.groupby("market"):
        g = group.sort_values(["probability", "edge_pct"], ascending=[False, False]).head(10)
        g.insert(0, "rank", range(1, len(g) + 1))
        boards.append(g)
    return pd.concat(boards, ignore_index=True) if boards else pd.DataFrame()

def build_player_market_card(try_market_predictions, player):
    if try_market_predictions is None or try_market_predictions.empty:
        return pd.DataFrame()
    df = try_market_predictions[try_market_predictions["player"] == player].copy()
    order = {"Anytime Try": 1, "First Try": 2, "2+ Tries": 3, "3+ Tries": 4}
    df["sort_order"] = df["market"].map(order).fillna(99)
    return df.sort_values("sort_order")
