import pandas as pd
from pathlib import Path
from datetime import datetime

from src.warehouse_engine import (
    create_warehouse_tables,
    replace_warehouse_table,
    read_warehouse_table,
    warehouse_table_counts,
)
from src.phase2_feature_engine import build_master_feature_table
from src.phase2_player_dna_engine import build_player_dna
from src.phase2_team_dna_2_engine import build_team_dna_2
from src.phase2_matchup_engine import build_matchup_intelligence
from src.phase2_simulation_engine import simulate_matches, simulate_try_markets
from src.phase2_ensemble_learning_engine import build_ensemble_predictions, learning_summary, grade_predictions

SAMPLE_DIR = Path("sample_data")

def demo_matches():
    return pd.DataFrame([
        {"match_id":"2026-R18-PAN-RAB","season":2026,"round":"R18","home_team":"PAN","away_team":"RAB","home_score":34,"away_score":16,"winner":"PAN","margin":18,"total_points":50},
        {"match_id":"2026-R17-PAN-STO","season":2026,"round":"R17","home_team":"PAN","away_team":"STO","home_score":28,"away_score":18,"winner":"PAN","margin":10,"total_points":46},
        {"match_id":"2026-R16-PAN-BRI","season":2026,"round":"R16","home_team":"PAN","away_team":"BRI","home_score":30,"away_score":20,"winner":"PAN","margin":10,"total_points":50},
        {"match_id":"2026-R17-RAB-BRI","season":2026,"round":"R17","home_team":"RAB","away_team":"BRI","home_score":12,"away_score":30,"winner":"BRI","margin":18,"total_points":42},
        {"match_id":"2026-R18-STO-BRI","season":2026,"round":"R18","home_team":"STO","away_team":"BRI","home_score":24,"away_score":22,"winner":"STO","margin":2,"total_points":46},
    ])

def demo_player_stats():
    rows = []
    base = [
        ("P-THOMAS-JENKINS","Thomas Jenkins","PAN","Centre",[2,1,2,0,2],[152,140,165,118,150],[2,1,2,0,2],[5,4,6,2,5]),
        ("P-BRIAN-TOO","Brian To'o","PAN","Winger",[1,1,2,1,1],[188,174,205,160,181],[1,1,2,1,1],[7,6,8,5,7]),
        ("P-ISAAH-YEO","Isaah Yeo","PAN","Lock",[0,1,0,0,1],[132,148,125,140,155],[0,0,0,0,0],[2,3,2,2,3]),
        ("P-LATRELL-MITCHELL","Latrell Mitchell","RAB","Fullback",[1,0,1,0,0],[155,110,160,98,122],[1,0,1,0,0],[4,2,5,1,3]),
        ("P-RAB-WINGER","Rabbitohs Winger","RAB","Winger",[0,1,0,0,1],[120,145,100,115,130],[0,1,0,0,1],[3,4,2,2,3]),
        ("P-STO-WINGER","Storm Winger","STO","Winger",[1,1,1,2,1],[165,170,158,210,175],[1,1,1,2,1],[5,6,5,8,6]),
        ("P-BRI-WINGER","Broncos Winger","BRI","Winger",[1,0,2,1,0],[150,120,190,155,115],[1,0,2,1,0],[4,2,7,5,2]),
    ]
    rounds = ["R14","R15","R16","R17","R18"]
    for pid, name, team, pos, tries, metres, lbs, tbs in base:
        for i in range(5):
            rows.append({
                "match_id": f"2026-{rounds[i]}-{team}-OPP",
                "season": 2026,
                "round": rounds[i],
                "team_id": team,
                "player_id": pid,
                "player_name": name,
                "position": pos,
                "minutes_played": 80,
                "tries": tries[i],
                "try_assists": 0,
                "line_breaks": lbs[i],
                "line_break_assists": 0,
                "tackle_breaks": tbs[i],
                "offloads": 1,
                "runs": 14,
                "run_metres": metres[i],
                "post_contact_metres": 35,
                "kick_return_metres": 0,
                "tackles": 12,
                "missed_tackles": 1,
                "ineffective_tackles": 0,
                "errors": 0,
                "penalties": 0,
                "sin_bins": 0,
                "send_offs": 0,
            })
    return pd.DataFrame(rows)

def demo_try_events():
    rows = []
    stats = demo_player_stats()
    counter = 1
    for _, r in stats.iterrows():
        tries = int(r.get("tries", 0))
        for t in range(tries):
            pos = str(r.get("position",""))
            if "Lock" in pos or "Prop" in pos:
                channel = "Middle"
            elif "Winger" in pos or "Centre" in pos:
                channel = "Right Edge" if "Jenkins" in r.get("player_name","") or "Storm" in r.get("player_name","") else "Left Edge"
            else:
                channel = "Kick / Other"
            rows.append({
                "try_id": f"DEMO-TRY-{counter}",
                "match_id": r.get("match_id"),
                "season": r.get("season"),
                "round": r.get("round"),
                "minute": 12 + (counter * 7 % 65),
                "scoring_team": r.get("team_id"),
                "opponent": "RAB" if r.get("team_id") == "PAN" else "PAN",
                "scorer_player_id": r.get("player_id"),
                "scorer_name": r.get("player_name"),
                "assister_player_id": "",
                "assister_name": "",
                "scorer_position": r.get("position"),
                "channel": channel,
                "try_type": "Shift Play" if "Edge" in channel else "Crash Play",
                "distance_from_goal_m": 12,
                "first_try": "YES" if t == 0 and counter % 3 == 0 else "NO",
                "last_try": "NO",
                "match_winning_try": "NO",
            })
            counter += 1
    return pd.DataFrame(rows)

def demo_weather():
    return pd.DataFrame([
        {"weather_id":"W-2026-R18-PAN-RAB","match_id":"2026-R18-PAN-RAB","venue":"BlueBet Stadium","temperature_c":18,"rainfall_mm":0,"wind_speed_kmh":12,"wind_direction":"SE","humidity_pct":55,"ground_condition":"Dry","weather_summary":"Dry","source":"Demo"},
        {"weather_id":"W-2026-R18-STO-BRI","match_id":"2026-R18-STO-BRI","venue":"AAMI Park","temperature_c":12,"rainfall_mm":2,"wind_speed_kmh":18,"wind_direction":"S","humidity_pct":72,"ground_condition":"Soft","weather_summary":"Light rain","source":"Demo"},
    ])

def demo_odds():
    return pd.DataFrame([
        {"odds_id":"O-1","match_id":"2026-R18-PAN-RAB","bookmaker":"DemoBook","market":"Head To Head","selection":"PAN","decimal_odds":1.35,"timestamp":"2026-07-01 18:00","opening_or_closing":"Current","source":"Demo"},
        {"odds_id":"O-2","match_id":"2026-R18-PAN-RAB","bookmaker":"DemoBook","market":"Anytime Try","selection":"Thomas Jenkins","decimal_odds":1.61,"timestamp":"2026-07-01 18:00","opening_or_closing":"Current","source":"Demo"},
    ])

def load_demo_data():
    create_warehouse_tables()
    replace_warehouse_table("matches", demo_matches())
    replace_warehouse_table("player_match_stats", demo_player_stats())
    replace_warehouse_table("try_events", demo_try_events())
    replace_warehouse_table("weather_history", demo_weather())
    replace_warehouse_table("odds_history", demo_odds())
    return warehouse_table_counts()

def run_phase2_pipeline(sims=2500):
    create_warehouse_tables()
    matches = read_warehouse_table("matches")
    player_stats = read_warehouse_table("player_match_stats")
    try_events = read_warehouse_table("try_events")

    features = build_master_feature_table(player_stats, try_events, matches)
    player_dna = build_player_dna(features)
    team_dna = build_team_dna_2(matches, try_events, player_stats)
    matchups = build_matchup_intelligence(matches, team_dna, player_dna)
    simulation = simulate_matches(matchups, sims=int(sims))
    try_markets = simulate_try_markets(player_dna, team_dna)
    ensemble = build_ensemble_predictions(matchups, simulation)
    graded = grade_predictions(ensemble, matches)
    learning = learning_summary(graded)

    replace_warehouse_table("phase2_master_features", features)
    replace_warehouse_table("phase2_player_dna", player_dna)
    replace_warehouse_table("phase2_team_dna_2", team_dna)
    replace_warehouse_table("phase2_matchup_intelligence", matchups)
    replace_warehouse_table("phase2_match_simulation", simulation)
    replace_warehouse_table("phase2_try_market_simulation", try_markets)
    replace_warehouse_table("phase2_ensemble_predictions", ensemble)
    replace_warehouse_table("phase2_learning_summary", learning)

    return {
        "features": features,
        "player_dna": player_dna,
        "team_dna": team_dna,
        "matchups": matchups,
        "simulation": simulation,
        "try_markets": try_markets,
        "ensemble": ensemble,
        "learning": learning,
    }

def setup_status():
    counts = warehouse_table_counts()
    def rows(table):
        hit = counts[counts["table_name"] == table]
        return int(hit["rows"].iloc[0]) if not hit.empty else 0

    checks = [
        {"step":"Matches loaded","table":"matches","rows":rows("matches"),"status":"PASS" if rows("matches") > 0 else "WAITING"},
        {"step":"Player stats loaded","table":"player_match_stats","rows":rows("player_match_stats"),"status":"PASS" if rows("player_match_stats") > 0 else "WAITING"},
        {"step":"Try events loaded","table":"try_events","rows":rows("try_events"),"status":"PASS" if rows("try_events") > 0 else "WAITING"},
        {"step":"Player DNA built","table":"phase2_player_dna","rows":rows("phase2_player_dna"),"status":"PASS" if rows("phase2_player_dna") > 0 else "WAITING"},
        {"step":"Team DNA built","table":"phase2_team_dna_2","rows":rows("phase2_team_dna_2"),"status":"PASS" if rows("phase2_team_dna_2") > 0 else "WAITING"},
        {"step":"Simulation built","table":"phase2_match_simulation","rows":rows("phase2_match_simulation"),"status":"PASS" if rows("phase2_match_simulation") > 0 else "WAITING"},
        {"step":"Ensemble built","table":"phase2_ensemble_predictions","rows":rows("phase2_ensemble_predictions"),"status":"PASS" if rows("phase2_ensemble_predictions") > 0 else "WAITING"},
    ]
    return pd.DataFrame(checks)

def reset_demo_outputs():
    for table in [
        "phase2_master_features","phase2_player_dna","phase2_team_dna_2",
        "phase2_matchup_intelligence","phase2_match_simulation",
        "phase2_try_market_simulation","phase2_ensemble_predictions",
        "phase2_learning_summary","phase2_realtime_events"
    ]:
        replace_warehouse_table(table, pd.DataFrame())
