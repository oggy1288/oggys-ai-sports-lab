
from pathlib import Path
import pandas as pd

RAW_TABLES = {
    "fixtures": "data/raw/fixtures.csv",
    "team_lists": "data/raw/team_lists.csv",
    "player_stats": "data/raw/player_stats.csv",
    "team_stats": "data/raw/team_stats.csv",
    "weather": "data/raw/weather.csv",
    "odds": "data/raw/odds.csv",
    "injuries": "data/raw/injuries.csv",
}

def root_dir() -> Path:
    return Path(__file__).resolve().parents[1]

def read_table(name: str) -> pd.DataFrame:
    path = root_dir() / RAW_TABLES[name]
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)

def save_uploaded_file(uploaded_file, destination: Path):
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(uploaded_file.getbuffer())

def format_percent(series):
    return (series.astype(float) * 100).round(1).astype(str) + "%"
