import pandas as pd

WIZARD_STEPS = [
    {"step": 1, "name": "Select Round", "table": "wizard_state"},
    {"step": 2, "name": "Fixtures", "table": "fixtures"},
    {"step": 3, "name": "Team Lists", "table": "team_lists"},
    {"step": 4, "name": "Player Stats", "table": "player_stats"},
    {"step": 5, "name": "Odds", "table": "odds"},
    {"step": 6, "name": "Injuries / Team News", "table": "injuries"},
    {"step": 7, "name": "Context", "table": "context"},
    {"step": 8, "name": "Name Matching", "table": "name_match_report"},
    {"step": 9, "name": "Integrity Check", "table": "player_integrity_report"},
    {"step": 10, "name": "Run Predictions", "table": "predictions"},
    {"step": 11, "name": "Review Dashboard", "table": "predictions"},
]

def table_ready(df, required_rows=1):
    return df is not None and not df.empty and len(df) >= required_rows

def build_wizard_status(tables):
    rows = []
    for item in WIZARD_STEPS:
        table = item["table"]
        if table == "wizard_state":
            state = tables.get("wizard_state", pd.DataFrame())
            ready = table_ready(state)
            count = len(state) if state is not None else 0
        elif table == "context":
            count = sum(len(tables.get(t, pd.DataFrame())) for t in [
                "milestone_report", "origin_players", "narrative_context", "middle_forward_context"
            ])
            ready = count > 0
        else:
            df = tables.get(table, pd.DataFrame())
            ready = table_ready(df)
            count = len(df) if df is not None else 0

        rows.append({
            "step": item["step"],
            "name": item["name"],
            "table": table,
            "rows": count,
            "status": "Complete" if ready else "Needs Work",
            "next_action": "" if ready else f"Add or check {item['name']}",
        })
    return pd.DataFrame(rows)

def progress_percent(status_df):
    if status_df is None or status_df.empty:
        return 0
    complete = (status_df["status"] == "Complete").sum()
    return round(complete / len(status_df) * 100, 1)
