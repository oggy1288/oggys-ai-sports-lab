import pandas as pd

MIDDLE_POSITIONS = {
    "Prop",
    "Lock",
    "Hooker",
    "Second Row",
    "Bench",
    "Middle Forward",
    "Interchange Forward",
}

MIDDLE_ROLE_BOOSTS = {
    "Crash Ball": 5,
    "Short Ball Runner": 4,
    "Dummy Half Sneak": 4,
    "Bench Impact Middle": 3,
    "Decoy / Low Usage": 0,
    "No Middle Role": 0,
}

def is_middle_forward(position):
    return str(position).strip() in MIDDLE_POSITIONS

def calculate_middle_boost(row):
    position = row.get("position", "")
    middle_role = row.get("middle_try_role", "No Middle Role")
    opponent_middle_weakness = pd.to_numeric(row.get("opponent_middle_weakness", 50), errors="coerce")
    team_red_zone_middle = pd.to_numeric(row.get("team_red_zone_middle_attack", 50), errors="coerce")
    projected_minutes = pd.to_numeric(row.get("avg_minutes", row.get("minutes_projection", 0)), errors="coerce")
    wet_weather = str(row.get("weather_impact", "")).lower()

    if pd.isna(opponent_middle_weakness):
        opponent_middle_weakness = 50
    if pd.isna(team_red_zone_middle):
        team_red_zone_middle = 50
    if pd.isna(projected_minutes):
        projected_minutes = 0

    boost = 0
    reasons = []

    if is_middle_forward(position):
        boost += 1
        reasons.append("middle forward eligible")

    role_boost = MIDDLE_ROLE_BOOSTS.get(str(middle_role).strip(), 0)
    boost += role_boost
    if role_boost:
        reasons.append(str(middle_role))

    if opponent_middle_weakness >= 80:
        boost += 4
        reasons.append("opponent middle very weak")
    elif opponent_middle_weakness >= 70:
        boost += 3
        reasons.append("opponent middle weak")
    elif opponent_middle_weakness >= 60:
        boost += 2
        reasons.append("opponent middle slightly weak")

    if team_red_zone_middle >= 80:
        boost += 3
        reasons.append("strong red-zone middle attack")
    elif team_red_zone_middle >= 70:
        boost += 2
        reasons.append("good red-zone middle attack")

    if projected_minutes >= 55:
        boost += 2
        reasons.append("strong minutes")
    elif projected_minutes >= 40:
        boost += 1
        reasons.append("useful minutes")

    if "wet" in wet_weather or "rain" in wet_weather or "heavy" in wet_weather:
        if is_middle_forward(position):
            boost += 2
            reasons.append("wet weather favours middle carries")

    # Cap so middles are recognised but do not overpower elite outside backs.
    boost = min(boost, 10)

    return boost, ", ".join(reasons)

def apply_middle_forward_modifier(players_df, middle_context_df=None):
    if players_df is None or players_df.empty:
        return players_df

    df = players_df.copy()

    # Optional context table can override/add fields by team or player.
    if middle_context_df is not None and not middle_context_df.empty:
        ctx = middle_context_df.copy()
        if "player" in ctx.columns:
            df = df.merge(ctx, on="player", how="left", suffixes=("", "_middle_ctx"))
        elif "team" in ctx.columns:
            df = df.merge(ctx, on="team", how="left", suffixes=("", "_middle_ctx"))

    defaults = {
        "middle_try_role": "No Middle Role",
        "opponent_middle_weakness": 50,
        "team_red_zone_middle_attack": 50,
        "weather_impact": "",
    }
    for col, val in defaults.items():
        if col not in df.columns:
            df[col] = val
        else:
            df[col] = df[col].fillna(val)

    results = df.apply(calculate_middle_boost, axis=1)
    df["middle_forward_boost"] = [x[0] for x in results]
    df["middle_forward_note"] = [x[1] for x in results]
    df["middle_forward_flag"] = df["middle_forward_boost"].apply(
        lambda x: "Middle Try Chance" if float(x or 0) > 0 else ""
    )
    return df