from pathlib import Path
import pandas as pd

REQUIRED_COLUMNS = {
    "fixtures": ["fixture_id", "round", "date", "home_team", "away_team", "venue"],
    "team_lists": ["round", "team", "player", "position", "starting", "edge", "minutes_projection"],
    "player_stats": ["player", "team", "position", "tries", "games", "last5_tries", "avg_minutes", "goal_line_role"],
    "team_stats": ["team", "attack", "defence", "pace"],
    "weather": ["fixture_id", "venue", "condition", "rain_mm", "wind_kmh", "temp_c", "weather_impact"],
    "odds": ["player", "market", "bookmaker", "odds"],
    "injuries": ["player", "status", "impact", "minutes_adjustment"],
}

def read_csv(path):
    path = Path(path)
    if not path.exists():
        return pd.DataFrame()
    return pd.read_csv(path)

def validate_table(name, df):
    rows = []
    for col in REQUIRED_COLUMNS.get(name, []):
        ok = col in df.columns
        rows.append({"table": name, "check": f"required column: {col}", "status": "PASS" if ok else "FAIL", "count": len(df), "action": "" if ok else f"Add missing column {col}"})
    rows.append({"table": name, "check": "row count > 0", "status": "PASS" if len(df) > 0 else "WARN", "count": len(df), "action": "" if len(df) > 0 else "Load data before final predictions"})
    return rows

def clean_all(raw_dir="data/raw", clean_dir="data/clean", output_dir="outputs"):
    raw_dir, clean_dir, output_dir = Path(raw_dir), Path(clean_dir), Path(output_dir)
    clean_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)
    tables, quality_rows = {}, []
    for name in REQUIRED_COLUMNS:
        df = read_csv(raw_dir / f"{name}.csv")
        if not df.empty:
            df.columns = [c.strip().lower() for c in df.columns]
            df = df.drop_duplicates()
        quality_rows.extend(validate_table(name, df))
        df.to_csv(clean_dir / f"{name}_clean.csv", index=False)
        tables[name] = df
    pd.DataFrame(quality_rows).to_csv(output_dir / "data_quality.csv", index=False)
    return tables