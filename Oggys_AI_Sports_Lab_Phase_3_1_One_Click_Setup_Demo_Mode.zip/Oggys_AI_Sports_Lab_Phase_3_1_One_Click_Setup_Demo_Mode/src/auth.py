import streamlit as st

def require_password():
    """Simple password protection for private prototype use."""
    try:
        expected_password = st.secrets.get("APP_PASSWORD", "")
    except Exception:
        expected_password = ""

    if not expected_password:
        st.warning("No app password has been set. Add APP_PASSWORD in Streamlit secrets before public use.")
        return True

    if "authenticated" not in st.session_state:
        st.session_state.authenticated = False

    if st.session_state.authenticated:
        return True

    st.title("NRL Predictor Pro")
    password = st.text_input("Enter app password", type="password")

    if st.button("Login"):
        if password == expected_password:
            st.session_state.authenticated = True
            st.rerun()
        else:
            st.error("Incorrect password.")

    return False