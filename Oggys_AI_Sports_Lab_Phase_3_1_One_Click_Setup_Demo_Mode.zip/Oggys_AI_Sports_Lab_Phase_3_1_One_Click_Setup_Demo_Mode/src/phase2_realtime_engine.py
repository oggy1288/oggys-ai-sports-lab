import pandas as pd
from datetime import datetime

def build_change_event(event_type, team="", player="", impact=0, notes=""):
    return {
        "event_time": datetime.now().isoformat(timespec="seconds"),
        "event_type": event_type,
        "team": team,
        "player": player,
        "impact": impact,
        "notes": notes,
    }

def apply_realtime_events(ensemble_predictions, events):
    if ensemble_predictions is None or ensemble_predictions.empty:
        return ensemble_predictions
    out=ensemble_predictions.copy()
    out["realtime_adjustment"]=0.0
    out["realtime_notes"]=""
    if events is None or events.empty:
        return out
    for _,ev in events.iterrows():
        team=str(ev.get("team",""))
        impact=float(ev.get("impact",0) or 0)
        notes=str(ev.get("notes",""))
        mask=out["predicted_winner"].astype(str).eq(team) if "predicted_winner" in out.columns else False
        out.loc[mask,"realtime_adjustment"] += impact
        out.loc[mask,"realtime_notes"] = (out.loc[mask,"realtime_notes"].astype(str) + " | " + notes).str.strip(" |")
    out["live_win_probability"]=(pd.to_numeric(out["final_win_probability"], errors="coerce").fillna(0)+out["realtime_adjustment"]).clip(0.01,0.99).round(3)
    return out
