import re
import pandas as pd
from difflib import SequenceMatcher

def normalise_name(name):
    if pd.isna(name):
        return ""
    value = str(name).strip().lower()
    value = re.sub(r"[^a-z0-9 ]", "", value)
    value = re.sub(r"\s+", " ", value)
    return value

def initials_key(name):
    name = normalise_name(name)
    parts = name.split()
    if not parts:
        return ""
    if len(parts) == 1:
        return parts[0]
    return f"{parts[0][0]} {parts[-1]}"

def generate_player_id(player, team=""):
    name_key = normalise_name(player).replace(" ", "_")
    team_key = normalise_name(team).replace(" ", "_")
    if team_key:
        return f"{team_key}_{name_key}"
    return name_key

def add_name_keys(df, player_col="player", team_col="team"):
    if df is None or df.empty:
        return df
    out = df.copy()
    if player_col not in out.columns:
        return out
    out["name_key"] = out[player_col].apply(normalise_name)
    out["initials_key"] = out[player_col].apply(initials_key)
    if "player_id" not in out.columns:
        if team_col in out.columns:
            out["player_id"] = out.apply(lambda r: generate_player_id(r.get(player_col, ""), r.get(team_col, "")), axis=1)
        else:
            out["player_id"] = out[player_col].apply(generate_player_id)
    return out

def build_alias_table(player_stats):
    if player_stats is None or player_stats.empty or "player" not in player_stats.columns:
        return pd.DataFrame(columns=["player_id", "player", "team", "alias", "name_key", "initials_key"])

    players = add_name_keys(player_stats)
    rows = []
    for _, row in players.iterrows():
        player = row.get("player", "")
        team = row.get("team", "")
        player_id = row.get("player_id", generate_player_id(player, team))
        rows.append({
            "player_id": player_id,
            "player": player,
            "team": team,
            "alias": player,
            "name_key": normalise_name(player),
            "initials_key": initials_key(player),
        })
        rows.append({
            "player_id": player_id,
            "player": player,
            "team": team,
            "alias": initials_key(player),
            "name_key": normalise_name(initials_key(player)),
            "initials_key": initials_key(player),
        })
    return pd.DataFrame(rows).drop_duplicates()

def best_name_match(input_name, alias_table, min_score=0.84):
    if alias_table is None or alias_table.empty:
        return None

    key = normalise_name(input_name)
    if not key:
        return None

    aliases = alias_table.copy()
    if "name_key" not in aliases.columns:
        aliases["name_key"] = aliases["alias"].apply(normalise_name)

    exact = aliases[aliases["name_key"] == key]
    if not exact.empty:
        row = exact.iloc[0].to_dict()
        row["match_score"] = 1.0
        row["match_type"] = "Exact"
        return row

    init = initials_key(input_name)
    init_matches = aliases[aliases.get("initials_key", "") == init]
    if not init_matches.empty:
        row = init_matches.iloc[0].to_dict()
        row["match_score"] = 0.95
        row["match_type"] = "Initials"
        return row

    best = None
    best_score = 0
    for _, row in aliases.iterrows():
        score = SequenceMatcher(None, key, row.get("name_key", "")).ratio()
        if score > best_score:
            best_score = score
            best = row.to_dict()

    if best and best_score >= min_score:
        best["match_score"] = round(best_score, 3)
        best["match_type"] = "Fuzzy"
        return best

    return {
        "player_id": "",
        "player": "",
        "team": "",
        "alias": input_name,
        "name_key": key,
        "initials_key": init,
        "match_score": round(best_score, 3),
        "match_type": "No Match",
    }

def resolve_names_against_master(input_df, alias_table, player_col="player"):
    if input_df is None or input_df.empty or player_col not in input_df.columns:
        return input_df

    rows = []
    for _, row in input_df.iterrows():
        match = best_name_match(row.get(player_col, ""), alias_table)
        new_row = row.to_dict()
        if match:
            new_row["matched_player_id"] = match.get("player_id", "")
            new_row["matched_player"] = match.get("player", "")
            new_row["matched_team"] = match.get("team", "")
            new_row["match_score"] = match.get("match_score", 0)
            new_row["match_type"] = match.get("match_type", "")
        rows.append(new_row)

    return pd.DataFrame(rows)