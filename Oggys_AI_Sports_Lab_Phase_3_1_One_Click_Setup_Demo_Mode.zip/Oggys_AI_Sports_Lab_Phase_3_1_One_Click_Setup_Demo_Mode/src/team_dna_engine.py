import pandas as pd
import numpy as np

CHANNELS = ["Left Edge", "Middle", "Right Edge", "Kick / Other"]

POSITION_CHANNEL_MAP = {
    "Left Winger": "Left Edge",
    "Left Centre": "Left Edge",
    "Right Winger": "Right Edge",
    "Right Centre": "Right Edge",
    "Winger": "Edge",
    "Centre": "Edge",
    "Fullback": "Kick / Other",
    "Five-Eighth": "Left Edge",
    "Halfback": "Right Edge",
    "Hooker": "Middle",
    "Prop": "Middle",
    "Lock": "Middle",
    "Second Row": "Edge",
    "Bench": "Middle",
}

def safe_num(value, default=0):
    try:
        if pd.isna(value):
            return default
        return float(value)
    except Exception:
        return default

def normalise_channel(value):
    value = str(value).strip().lower()
    if "left" in value:
        return "Left Edge"
    if "right" in value:
        return "Right Edge"
    if "middle" in value or "ruck" in value or "forward" in value:
        return "Middle"
    if "kick" in value or "other" in value:
        return "Kick / Other"
    return "Kick / Other"

def infer_player_channel(row):
    channel = str(row.get("channel", "")).strip()
    if channel:
        return normalise_channel(channel)

    edge = str(row.get("edge", "")).strip()
    if edge:
        return normalise_channel(edge)

    pos = str(row.get("position", "")).strip()
    mapped = POSITION_CHANNEL_MAP.get(pos, "")
    if mapped == "Edge":
        return "Left Edge"
    if mapped:
        return mapped
    return "Kick / Other"

def build_team_dna(try_history):
    if try_history is None or try_history.empty:
        return pd.DataFrame(columns=[
            "team", "tries", "left_edge_pct", "middle_pct", "right_edge_pct",
            "kick_other_pct", "primary_attack_channel", "team_dna_summary"
        ])

    df = try_history.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    for col in ["team", "opponent", "channel"]:
        if col not in df.columns:
            df[col] = ""

    df["channel_clean"] = df["channel"].apply(normalise_channel)

    rows = []
    for team, group in df.groupby("team", dropna=False):
        total = len(group)
        counts = group["channel_clean"].value_counts().to_dict()
        pct = {c: counts.get(c, 0) / total if total else 0 for c in CHANNELS}
        primary = max(pct, key=pct.get) if total else ""
        rows.append({
            "team": team,
            "tries": total,
            "left_edge_pct": round(pct["Left Edge"], 3),
            "middle_pct": round(pct["Middle"], 3),
            "right_edge_pct": round(pct["Right Edge"], 3),
            "kick_other_pct": round(pct["Kick / Other"], 3),
            "primary_attack_channel": primary,
            "team_dna_summary": f"{team} attack mainly through {primary} ({pct[primary]*100:.1f}%)." if primary else "",
        })

    return pd.DataFrame(rows).sort_values("tries", ascending=False)

def build_team_concede_dna(try_history):
    if try_history is None or try_history.empty:
        return pd.DataFrame(columns=[
            "team", "tries_conceded", "left_edge_concede_pct", "middle_concede_pct",
            "right_edge_concede_pct", "kick_other_concede_pct", "weakest_defensive_channel",
            "concede_dna_summary"
        ])

    df = try_history.copy()
    df.columns = [str(c).strip().lower() for c in df.columns]

    for col in ["team", "opponent", "channel"]:
        if col not in df.columns:
            df[col] = ""

    df["channel_clean"] = df["channel"].apply(normalise_channel)

    rows = []
    for conceding_team, group in df.groupby("opponent", dropna=False):
        total = len(group)
        counts = group["channel_clean"].value_counts().to_dict()
        pct = {c: counts.get(c, 0) / total if total else 0 for c in CHANNELS}
        weak = max(pct, key=pct.get) if total else ""
        rows.append({
            "team": conceding_team,
            "tries_conceded": total,
            "left_edge_concede_pct": round(pct["Left Edge"], 3),
            "middle_concede_pct": round(pct["Middle"], 3),
            "right_edge_concede_pct": round(pct["Right Edge"], 3),
            "kick_other_concede_pct": round(pct["Kick / Other"], 3),
            "weakest_defensive_channel": weak,
            "concede_dna_summary": f"{conceding_team} concede most through {weak} ({pct[weak]*100:.1f}%)." if weak else "",
        })

    return pd.DataFrame(rows).sort_values("tries_conceded", ascending=False)

def matchup_boost(attack_pct, concede_pct):
    attack_pct = safe_num(attack_pct, 0)
    concede_pct = safe_num(concede_pct, 0)
    score = (attack_pct * 0.55 + concede_pct * 0.45) * 100

    if score >= 45:
        return 8, "Monster Channel Matchup"
    if score >= 35:
        return 5, "Strong Channel Matchup"
    if score >= 25:
        return 3, "Good Channel Matchup"
    if score >= 18:
        return 1, "Small Channel Edge"
    return 0, "No Clear Channel Edge"

def build_channel_matchups(fixtures, team_dna, concede_dna):
    if fixtures is None or fixtures.empty or team_dna is None or team_dna.empty or concede_dna is None or concede_dna.empty:
        return pd.DataFrame(columns=[
            "fixture_id", "team", "opponent", "channel", "attack_pct", "opponent_concede_pct",
            "channel_boost", "channel_verdict", "matchup_summary"
        ])

    fixtures = fixtures.copy()
    fixtures.columns = [str(c).strip().lower() for c in fixtures.columns]

    rows = []
    for _, f in fixtures.iterrows():
        for team_col, opp_col in [("home_team", "away_team"), ("away_team", "home_team")]:
            team = f.get(team_col, "")
            opponent = f.get(opp_col, "")

            atk = team_dna[team_dna["team"] == team]
            con = concede_dna[concede_dna["team"] == opponent]

            if atk.empty or con.empty:
                continue

            atk = atk.iloc[0]
            con = con.iloc[0]

            channel_pairs = {
                "Left Edge": ("left_edge_pct", "left_edge_concede_pct"),
                "Middle": ("middle_pct", "middle_concede_pct"),
                "Right Edge": ("right_edge_pct", "right_edge_concede_pct"),
                "Kick / Other": ("kick_other_pct", "kick_other_concede_pct"),
            }

            for channel, (a_col, c_col) in channel_pairs.items():
                a = safe_num(atk.get(a_col, 0))
                c = safe_num(con.get(c_col, 0))
                boost, verdict = matchup_boost(a, c)
                rows.append({
                    "fixture_id": f.get("fixture_id", ""),
                    "team": team,
                    "opponent": opponent,
                    "channel": channel,
                    "attack_pct": round(a, 3),
                    "opponent_concede_pct": round(c, 3),
                    "channel_boost": boost,
                    "channel_verdict": verdict,
                    "matchup_summary": f"{team} {channel}: attack {a*100:.1f}% vs {opponent} concede {c*100:.1f}% — {verdict}.",
                })

    return pd.DataFrame(rows).sort_values("channel_boost", ascending=False)

def apply_team_dna_boost(predictions, channel_matchups):
    if predictions is None or predictions.empty:
        return predictions

    out = predictions.copy()
    if channel_matchups is None or channel_matchups.empty:
        out["team_dna_channel"] = ""
        out["team_dna_boost"] = 0
        out["team_dna_verdict"] = ""
        out["team_dna_summary"] = ""
        return out

    out["player_channel"] = out.apply(infer_player_channel, axis=1)

    rows = []
    for _, r in out.iterrows():
        team = r.get("team", "")
        channel = r.get("player_channel", "")

        match = channel_matchups[
            (channel_matchups["team"] == team) &
            (channel_matchups["channel"] == channel)
        ]

        if match.empty:
            # If player is a generic edge player, use the strongest edge.
            match = channel_matchups[
                (channel_matchups["team"] == team) &
                (channel_matchups["channel"].isin(["Left Edge", "Right Edge"]))
            ].sort_values("channel_boost", ascending=False)

        if match.empty:
            r["team_dna_channel"] = ""
            r["team_dna_boost"] = 0
            r["team_dna_verdict"] = ""
            r["team_dna_summary"] = ""
        else:
            m = match.iloc[0]
            r["team_dna_channel"] = m.get("channel", "")
            r["team_dna_boost"] = m.get("channel_boost", 0)
            r["team_dna_verdict"] = m.get("channel_verdict", "")
            r["team_dna_summary"] = m.get("matchup_summary", "")

        rows.append(r)

    result = pd.DataFrame(rows)
    if "model_score" in result.columns:
        result["model_score"] = pd.to_numeric(result["model_score"], errors="coerce").fillna(0)
        result["team_dna_boost"] = pd.to_numeric(result["team_dna_boost"], errors="coerce").fillna(0)
        result["model_score"] = (result["model_score"] + result["team_dna_boost"]).clip(0, 100)

    return result
