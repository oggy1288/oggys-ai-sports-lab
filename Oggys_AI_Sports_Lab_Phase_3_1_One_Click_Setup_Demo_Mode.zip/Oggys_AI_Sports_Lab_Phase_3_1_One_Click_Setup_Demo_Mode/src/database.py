from __future__ import annotations

import sqlite3
from pathlib import Path
import pandas as pd

DB_PATH = Path("database/nrl_predictor.db")

TABLE_SCHEMAS = {
        "middle_forward_context": {
            "player": "TEXT",
            "team": "TEXT",
            "middle_try_role": "TEXT",
            "opponent": "TEXT",
            "opponent_middle_weakness": "REAL",
            "team_red_zone_middle_attack": "REAL",
            "weather_impact": "TEXT",
            "middle_note": "TEXT",
        },
        "player_try_history": {
            "player": "TEXT",
            "team": "TEXT",
            "opponent": "TEXT",
            "round": "TEXT",
            "date": "TEXT",
            "venue": "TEXT",
            "minute": "REAL",
            "try_number": "REAL",
            "is_first_try": "TEXT",
            "result": "TEXT",
            "channel": "TEXT",
            "position": "TEXT",
        },
        "player_try_timing_profile": {
            "player": "TEXT",
            "team": "TEXT",
            "tries": "REAL",
            "avg_try_minute": "REAL",
            "avg_first_try_minute": "TEXT",
            "first_try_count": "REAL",
            "first_try_rate": "REAL",
            "two_plus_count": "REAL",
            "three_plus_count": "REAL",
            "pct_0_20": "REAL",
            "pct_20_40": "REAL",
            "pct_40_60": "REAL",
            "pct_60_80": "REAL",
            "timing_profile": "TEXT",
            "timing_label": "TEXT",
        },
        "team_try_timeline": {
            "team": "TEXT",
            "tries": "REAL",
            "pct_0_20": "REAL",
            "pct_20_40": "REAL",
            "pct_40_60": "REAL",
            "pct_60_80": "REAL",
            "team_timing_profile": "TEXT",
            "team_timing_label": "TEXT",
        },
        "team_conceded_timeline": {
            "team": "TEXT",
            "tries_conceded": "REAL",
            "concede_pct_0_20": "REAL",
            "concede_pct_20_40": "REAL",
            "concede_pct_40_60": "REAL",
            "concede_pct_60_80": "REAL",
            "concede_timing_profile": "TEXT",
            "concede_timing_label": "TEXT",
        },
        "team_dna_profile": {
            "team": "TEXT",
            "tries": "REAL",
            "left_edge_pct": "REAL",
            "middle_pct": "REAL",
            "right_edge_pct": "REAL",
            "kick_other_pct": "REAL",
            "primary_attack_channel": "TEXT",
            "team_dna_summary": "TEXT",
        },
        "team_concede_dna_profile": {
            "team": "TEXT",
            "tries_conceded": "REAL",
            "left_edge_concede_pct": "REAL",
            "middle_concede_pct": "REAL",
            "right_edge_concede_pct": "REAL",
            "kick_other_concede_pct": "REAL",
            "weakest_defensive_channel": "TEXT",
            "concede_dna_summary": "TEXT",
        },
        "channel_matchups": {
            "fixture_id": "TEXT",
            "team": "TEXT",
            "opponent": "TEXT",
            "channel": "TEXT",
            "attack_pct": "REAL",
            "opponent_concede_pct": "REAL",
            "channel_boost": "REAL",
            "channel_verdict": "TEXT",
            "matchup_summary": "TEXT",
        },
        "try_market_predictions": {
            "player_id": "TEXT",
            "player": "TEXT",
            "team": "TEXT",
            "position": "TEXT",
            "market": "TEXT",
            "probability": "REAL",
            "fair_odds": "REAL",
            "best_odds": "REAL",
            "best_bookmaker": "TEXT",
            "edge_pct": "REAL",
            "ev_pct": "REAL",
            "market_flag": "TEXT",
            "model_score": "REAL",
            "last5_sequence": "TEXT",
            "vs_opponent_sequence": "TEXT",
            "avg_try_minute": "TEXT",
            "avg_first_try_minute": "TEXT",
            "timing_profile": "TEXT",
            "timing_label": "TEXT",
            "source": "TEXT",
        },
        "top_try_market_board": {
            "rank": "REAL",
            "player": "TEXT",
            "team": "TEXT",
            "position": "TEXT",
            "market": "TEXT",
            "probability": "REAL",
            "fair_odds": "REAL",
            "best_odds": "REAL",
            "best_bookmaker": "TEXT",
            "edge_pct": "REAL",
            "ev_pct": "REAL",
            "market_flag": "TEXT",
        },
        "try_market_seed_report": {
            "player": "TEXT",
            "team": "TEXT",
            "position": "TEXT",
            "model_score": "REAL",
            "model_probability": "REAL",
            "avg_try_minute": "REAL",
            "avg_first_try_minute": "TEXT",
            "first_try_seed_prob": "REAL",
            "first_try_seed_fair_odds": "REAL",
            "two_plus_seed_prob": "REAL",
            "two_plus_seed_fair_odds": "REAL",
            "three_plus_seed_prob": "REAL",
            "three_plus_seed_fair_odds": "REAL",
            "timing_profile": "TEXT",
            "timing_label": "TEXT",
        },
        "why_ai_report": {
            "player": "TEXT",
            "team": "TEXT",
            "model_score": "REAL",
            "ai_summary": "TEXT",
            "reasons": "TEXT",
            "risks": "TEXT",
            "overall_verdict": "TEXT",
            "recent_form_score": "REAL",
            "vs_opponent_score": "REAL",
            "market_value_score": "REAL",
            "context_score": "REAL",
            "risk_score": "REAL",
            "overall_score": "REAL",
        },
        "player_game_history": {
            "player": "TEXT",
            "team": "TEXT",
            "opponent": "TEXT",
            "round": "TEXT",
            "date": "TEXT",
            "result": "TEXT",
            "tries": "REAL",
        },
        "team_game_history": {
            "team": "TEXT",
            "opponent": "TEXT",
            "round": "TEXT",
            "date": "TEXT",
            "tries_scored": "REAL",
            "tries_conceded": "REAL",
            "result": "TEXT",
        },
        "player_vs_opponent_history": {
            "player": "TEXT",
            "team": "TEXT",
            "opponent": "TEXT",
            "round": "TEXT",
            "date": "TEXT",
            "result": "TEXT",
            "tries": "REAL",
        },
        "player_sequence_report": {
            "player": "TEXT",
            "team": "TEXT",
            "opponent": "TEXT",
            "last5_sequence": "TEXT",
            "last5_total": "REAL",
            "last5_avg": "REAL",
            "last5_scored_games": "REAL",
            "last5_multi_games": "REAL",
            "last5_rating": "TEXT",
        },
        "team_sequence_report": {
            "team": "TEXT",
            "opponent": "TEXT",
            "team_last5_scored_sequence": "TEXT",
            "team_last5_conceded_sequence": "TEXT",
            "team_avg_scored": "REAL",
            "team_avg_conceded": "REAL",
            "team_attack_rating": "TEXT",
            "team_defence_leak_rating": "TEXT",
        },
        "opponent_sequence_report": {
            "player": "TEXT",
            "team": "TEXT",
            "opponent": "TEXT",
            "vs_opponent_sequence": "TEXT",
            "vs_opponent_total": "REAL",
            "vs_opponent_avg": "REAL",
            "vs_opponent_scored_games": "REAL",
            "vs_opponent_multi_games": "REAL",
            "vs_opponent_rating": "TEXT",
        },
        "best_odds": {
            "player": "TEXT",
            "team": "TEXT",
            "market": "TEXT",
            "best_odds": "REAL",
            "best_bookmaker": "TEXT",
            "bookmaker_count": "REAL",
            "average_odds": "REAL",
            "lowest_odds": "REAL",
        },
        "odds_value_report": {
            "player_id": "TEXT",
            "player": "TEXT",
            "team": "TEXT",
            "position": "TEXT",
            "model_score": "REAL",
            "model_probability": "REAL",
            "fair_odds": "REAL",
            "best_odds": "REAL",
            "best_bookmaker": "TEXT",
            "market_edge_pct": "REAL",
            "ev_pct": "REAL",
            "odds_value_flag": "TEXT",
        },
        "wizard_state": {
            "round": "TEXT",
            "season": "TEXT",
            "week_start": "TEXT",
            "notes": "TEXT",
        },
        "wizard_status": {
            "step": "REAL",
            "name": "TEXT",
            "table": "TEXT",
            "rows": "REAL",
            "status": "TEXT",
            "next_action": "TEXT",
        },
        "player_aliases": {
            "player_id": "TEXT",
            "player": "TEXT",
            "team": "TEXT",
            "alias": "TEXT",
            "name_key": "TEXT",
            "initials_key": "TEXT",
        },
        "name_match_report": {
            "source_table": "TEXT",
            "input_player": "TEXT",
            "matched_player_id": "TEXT",
            "matched_player": "TEXT",
            "matched_team": "TEXT",
            "match_score": "REAL",
            "match_type": "TEXT",
            "action": "TEXT",
        },
        "narrative_context": {
            "player": "TEXT",
            "team": "TEXT",
            "context_type": "TEXT",
            "narrative_note": "TEXT",
            "context_nrl_debut": "TEXT",
            "context_club_debut": "TEXT",
            "context_home_debut": "TEXT",
            "context_playing_former_club": "TEXT",
            "context_captain_first_game": "TEXT",
            "context_final_home_game": "TEXT",
            "context_retirement_game": "TEXT",
            "context_rivalry_game": "TEXT",
            "context_finals_intensity": "TEXT",
            "context_grand_final": "TEXT",
            "context_first_game_back_from_injury": "TEXT",
            "context_returning_from_suspension": "TEXT",
            "context_birthday_game": "TEXT",
        },
        "origin_players": {
            "player": "TEXT",
            "team": "TEXT",
            "origin_status": "TEXT",
            "origin_minutes": "REAL",
            "origin_note": "TEXT",
        },
        "origin_team_impact": {
            "team": "TEXT",
            "origin_team_status": "TEXT",
            "origin_team_note": "TEXT",
        },
        "origin_team_adjustments": {
            "team": "TEXT",
            "origin_team_status": "TEXT",
            "team_attack_adjustment": "REAL",
            "team_defence_adjustment": "REAL",
            "origin_team_note": "TEXT",
        },
        "milestone_report": {
            "player": "TEXT",
            "team": "TEXT",
            "career_games": "REAL",
            "middle_try_role": "TEXT",
            "opponent_middle_weakness": "REAL",
            "team_red_zone_middle_attack": "REAL",
            "milestone_game": "REAL",
            "milestone_boost": "REAL",
            "milestone_flag": "TEXT",
            "milestone_note": "TEXT",
        },

    "fixtures": {
        "fixture_id": "TEXT",
        "round": "TEXT",
        "date": "TEXT",
        "home_team": "TEXT",
        "away_team": "TEXT",
        "venue": "TEXT",
    },
    "team_lists": {
        "round": "TEXT",
        "team": "TEXT",
        "player": "TEXT",
        "position": "TEXT",
        "starting": "TEXT",
        "edge": "TEXT",
        "minutes_projection": "REAL",
    },
    "player_stats": {
        "player": "TEXT",
        "team": "TEXT",
        "position": "TEXT",
        "tries": "REAL",
        "games": "REAL",
        "last5_tries": "REAL",
        "line_breaks": "REAL",
        "tackle_breaks": "REAL",
        "avg_minutes": "REAL",
        "goal_line_role": "TEXT",
            "career_games": "REAL",
            "middle_try_role": "TEXT",
            "opponent_middle_weakness": "REAL",
            "team_red_zone_middle_attack": "REAL",
    },
    "team_stats": {
        "team": "TEXT",
        "attack": "REAL",
        "defence": "REAL",
        "pace": "REAL",
        "left_edge_attack": "REAL",
        "right_edge_attack": "REAL",
        "left_edge_defence": "REAL",
        "right_edge_defence": "REAL",
    },
    "weather": {
        "fixture_id": "TEXT",
        "venue": "TEXT",
        "condition": "TEXT",
        "rain_mm": "REAL",
        "wind_kmh": "REAL",
        "temp_c": "REAL",
        "weather_impact": "TEXT",
    },
    "odds": {
        "player": "TEXT",
        "market": "TEXT",
        "bookmaker": "TEXT",
        "odds": "REAL",
    },
    "injuries": {
        "player": "TEXT",
        "status": "TEXT",
        "impact": "TEXT",
        "minutes_adjustment": "REAL",
    },
    "predictions": {
        "player": "TEXT",
        "team": "TEXT",
        "position": "TEXT",
        "model_score": "REAL",
        "model_probability": "REAL",
        "fair_odds": "REAL",
        "bookmaker_odds": "REAL",
        "edge_pct": "REAL",
        "confidence_band": "TEXT",
        "bet_recommendation": "TEXT",
    },
    "model_history": {
        "round": "TEXT",
        "date": "TEXT",
        "player": "TEXT",
        "team": "TEXT",
        "market": "TEXT",
        "model_score": "REAL",
        "bookmaker_odds": "REAL",
        "stake": "REAL",
        "result": "TEXT",
        "profit_loss": "REAL",
    },
}

def connect(db_path: Path = DB_PATH) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(db_path)

def init_db(db_path: Path = DB_PATH) -> None:
    with connect(db_path) as conn:
        for table, cols in TABLE_SCHEMAS.items():
            col_sql = ", ".join([f"{name} {dtype}" for name, dtype in cols.items()])
            conn.execute(f"CREATE TABLE IF NOT EXISTS {table} ({col_sql})")
        conn.commit()

def replace_table(table: str, df: pd.DataFrame, db_path: Path = DB_PATH) -> None:
    init_db(db_path)
    clean = df.copy()
    clean.columns = [str(c).strip().lower() for c in clean.columns]
    with connect(db_path) as conn:
        clean.to_sql(table, conn, if_exists="replace", index=False)

def append_table(table: str, df: pd.DataFrame, db_path: Path = DB_PATH) -> None:
    init_db(db_path)
    clean = df.copy()
    clean.columns = [str(c).strip().lower() for c in clean.columns]
    with connect(db_path) as conn:
        clean.to_sql(table, conn, if_exists="append", index=False)

def read_table(table: str, db_path: Path = DB_PATH) -> pd.DataFrame:
    init_db(db_path)
    with connect(db_path) as conn:
        try:
            return pd.read_sql_query(f"SELECT * FROM {table}", conn)
        except Exception:
            return pd.DataFrame()

def table_counts(db_path: Path = DB_PATH) -> pd.DataFrame:
    init_db(db_path)
    rows = []
    with connect(db_path) as conn:
        for table in TABLE_SCHEMAS:
            try:
                count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
            except Exception:
                count = 0
            rows.append({"table": table, "rows": count})
    return pd.DataFrame(rows)