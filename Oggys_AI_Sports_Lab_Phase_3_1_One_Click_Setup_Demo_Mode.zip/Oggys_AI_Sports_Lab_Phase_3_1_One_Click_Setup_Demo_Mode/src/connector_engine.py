import pandas as pd
from datetime import datetime
import json
from pathlib import Path

from src.source_adapters import ADAPTER_CONFIG, import_with_adapter, apply_adapter
from src.warehouse_engine import read_warehouse_table, WAREHOUSE_SCHEMA

SOURCE_REGISTRY_PATH = Path("config/source_registry.json")

def load_source_registry():
    if not SOURCE_REGISTRY_PATH.exists():
        return {}
    return json.loads(SOURCE_REGISTRY_PATH.read_text(encoding="utf-8"))

def source_registry_table():
    registry = load_source_registry()
    rows = []
    for source_id, meta in registry.items():
        row = {"source_id": source_id}
        row.update(meta)
        rows.append(row)
    return pd.DataFrame(rows)

def import_source_csv(source_id, raw_df, dataset_version_id="working", source_file="", mode="replace"):
    registry = load_source_registry()
    if source_id not in registry:
        raise ValueError(f"Unknown source_id: {source_id}")
    adapter = registry[source_id].get("adapter", "")
    if not adapter:
        raise ValueError(f"Source {source_id} has no adapter yet.")
    return import_with_adapter(adapter, raw_df, dataset_version_id, source_file, mode)

def preview_source_csv(source_id, raw_df):
    registry = load_source_registry()
    if source_id not in registry:
        raise ValueError(f"Unknown source_id: {source_id}")
    adapter = registry[source_id].get("adapter", "")
    if not adapter:
        return pd.DataFrame()
    return apply_adapter(adapter, raw_df)

def build_import_plan():
    registry = load_source_registry()
    rows = []
    for source_id, meta in registry.items():
        target = meta.get("target_table", "")
        df = read_warehouse_table(target) if target else pd.DataFrame()
        rows.append({
            "source_id": source_id,
            "source_name": meta.get("source_name", ""),
            "priority": meta.get("priority", ""),
            "target_table": target,
            "status": meta.get("status", ""),
            "refresh_frequency": meta.get("refresh_frequency", ""),
            "current_rows": len(df) if df is not None else 0,
            "next_action": "Import historical CSV" if len(df) == 0 else "Update / append latest data",
            "notes": meta.get("notes", ""),
        })
    return pd.DataFrame(rows).sort_values(["priority", "source_id"])

def field_coverage_report():
    registry = load_source_registry()
    rows = []
    for source_id, meta in registry.items():
        target = meta.get("target_table", "")
        if not target or target not in WAREHOUSE_SCHEMA:
            continue
        df = read_warehouse_table(target)
        expected_fields = list(WAREHOUSE_SCHEMA[target].keys())
        if df is None or df.empty:
            for field in expected_fields:
                rows.append({
                    "source_id": source_id,
                    "target_table": target,
                    "field_name": field,
                    "coverage_pct": 0,
                    "status": "No Data",
                })
            continue
        for field in expected_fields:
            if field not in df.columns:
                coverage = 0
                status = "Missing Field"
            else:
                non_blank = (df[field].astype(str).str.strip() != "").sum()
                coverage = round(non_blank / len(df) * 100, 1) if len(df) else 0
                status = "Good" if coverage >= 90 else ("Partial" if coverage > 0 else "Blank")
            rows.append({
                "source_id": source_id,
                "target_table": target,
                "field_name": field,
                "coverage_pct": coverage,
                "status": status,
            })
    return pd.DataFrame(rows)

def connector_health_report():
    plan = build_import_plan()
    coverage = field_coverage_report()
    rows = []
    for _, src in plan.iterrows():
        src_cov = coverage[coverage["source_id"] == src["source_id"]]
        if src_cov.empty:
            avg_cov = 0
        else:
            avg_cov = round(src_cov["coverage_pct"].mean(), 1)
        row_count = int(src["current_rows"])
        health = 0
        if row_count > 0:
            health += 50
        health += min(avg_cov * 0.5, 50)
        rows.append({
            "source_id": src["source_id"],
            "source_name": src["source_name"],
            "target_table": src["target_table"],
            "rows_loaded": row_count,
            "avg_field_coverage_pct": avg_cov,
            "connector_health_score": round(health, 1),
            "status": "Ready" if health >= 80 else ("Needs Data" if row_count == 0 else "Needs Cleanup"),
        })
    return pd.DataFrame(rows)
