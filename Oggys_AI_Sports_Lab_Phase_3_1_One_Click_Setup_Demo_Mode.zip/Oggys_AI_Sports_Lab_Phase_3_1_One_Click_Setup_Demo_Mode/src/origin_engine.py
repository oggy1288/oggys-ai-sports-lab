import pandas as pd

ORIGIN_STATUS_BOOSTS = {
    "Selected": 3,
    "Backup": 2,
    "Unlucky Miss": 2,
    "Rested": -8,
    "Backing Up": -3,
    "Backing Up Heavy Minutes": -5,
    "Not In Origin Frame": 0,
}

TEAM_ORIGIN_IMPACT = {
    "Key Spine Out": {"attack": -8, "defence": -3, "note": "Spine player missing; attack structure likely weaker."},
    "Key Middle Out": {"attack": -3, "defence": -6, "note": "Middle forward missing; ruck defence and go-forward likely weaker."},
    "Key Edge Out": {"attack": -4, "defence": -5, "note": "Edge player missing; defensive combinations may be weaker."},
    "Multiple Stars Out": {"attack": -10, "defence": -8, "note": "Multiple Origin players missing; team style likely changes."},
    "Origin Stars Backing Up": {"attack": -2, "defence": -3, "note": "Stars available but fatigue risk applies."},
    "Origin Players Available": {"attack": 2, "defence": 2, "note": "Origin-calibre players available; small quality boost."},
    "No Major Impact": {"attack": 0, "defence": 0, "note": "No major Origin-related team adjustment."},
}

def apply_origin_player_modifier(players_df, origin_df):
    if players_df is None or players_df.empty:
        return players_df

    df = players_df.copy()

    if origin_df is None or origin_df.empty or "player" not in origin_df.columns:
        df["origin_status"] = ""
        df["origin_boost"] = 0
        df["origin_note"] = ""
        return df

    origin = origin_df.copy()
    keep_cols = [c for c in ["player", "origin_status", "origin_minutes", "origin_note"] if c in origin.columns]
    origin = origin[keep_cols].drop_duplicates("player")

    df = df.merge(origin, on="player", how="left")
    df["origin_status"] = df["origin_status"].fillna("Not In Origin Frame")
    df["origin_boost"] = df["origin_status"].map(ORIGIN_STATUS_BOOSTS).fillna(0)

    if "origin_minutes" in df.columns:
        df["origin_minutes"] = pd.to_numeric(df["origin_minutes"], errors="coerce").fillna(0)
        df.loc[(df["origin_status"] == "Backing Up") & (df["origin_minutes"] >= 65), "origin_boost"] = -5
        df.loc[(df["origin_status"] == "Selected") & (df["origin_minutes"] >= 70), "origin_boost"] = 1

    df["origin_note"] = df.get("origin_note", "").fillna("")
    return df

def build_team_origin_adjustments(origin_team_df):
    if origin_team_df is None or origin_team_df.empty:
        return pd.DataFrame(columns=[
            "team", "origin_team_status", "team_attack_adjustment",
            "team_defence_adjustment", "origin_team_note"
        ])

    rows = []
    for _, row in origin_team_df.iterrows():
        status = row.get("origin_team_status", "No Major Impact")
        impact = TEAM_ORIGIN_IMPACT.get(status, TEAM_ORIGIN_IMPACT["No Major Impact"])
        rows.append({
            "team": row.get("team", ""),
            "origin_team_status": status,
            "team_attack_adjustment": impact["attack"],
            "team_defence_adjustment": impact["defence"],
            "origin_team_note": row.get("origin_team_note", impact["note"]) or impact["note"],
        })
    return pd.DataFrame(rows)