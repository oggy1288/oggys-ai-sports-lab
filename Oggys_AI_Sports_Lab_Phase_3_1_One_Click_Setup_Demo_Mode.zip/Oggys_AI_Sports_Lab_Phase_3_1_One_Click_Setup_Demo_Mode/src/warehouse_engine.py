import pandas as pd
import sqlite3
from pathlib import Path
from datetime import datetime
import uuid

WAREHOUSE_SCHEMA = {'matches': {'match_id': 'TEXT', 'season': 'INTEGER', 'round': 'TEXT', 'match_date': 'TEXT', 'kickoff_time': 'TEXT', 'home_team': 'TEXT', 'away_team': 'TEXT', 'venue': 'TEXT', 'referee': 'TEXT', 'crowd': 'INTEGER', 'weather_id': 'TEXT', 'home_score': 'INTEGER', 'away_score': 'INTEGER', 'home_halftime_score': 'INTEGER', 'away_halftime_score': 'INTEGER', 'extra_time': 'TEXT', 'winner': 'TEXT', 'margin': 'INTEGER', 'total_points': 'INTEGER'}, 'teams_master': {'team_id': 'TEXT', 'team_name': 'TEXT', 'short_name': 'TEXT', 'home_ground': 'TEXT', 'coach': 'TEXT', 'founded': 'INTEGER', 'primary_colour': 'TEXT', 'secondary_colour': 'TEXT', 'active': 'TEXT'}, 'players_master': {'player_id': 'TEXT', 'full_name': 'TEXT', 'date_of_birth': 'TEXT', 'height_cm': 'REAL', 'weight_kg': 'REAL', 'preferred_position': 'TEXT', 'current_club': 'TEXT', 'debut_date': 'TEXT', 'career_games': 'INTEGER', 'career_tries': 'INTEGER', 'representative_honours': 'TEXT', 'active': 'TEXT'}, 'team_lists_history': {'match_id': 'TEXT', 'team_id': 'TEXT', 'player_id': 'TEXT', 'player_name': 'TEXT', 'jersey_number': 'INTEGER', 'position': 'TEXT', 'starting_or_bench': 'TEXT', 'captain': 'TEXT', 'minutes_played': 'REAL', 'late_change_flag': 'TEXT'}, 'player_match_stats': {'match_id': 'TEXT', 'season': 'INTEGER', 'round': 'TEXT', 'team_id': 'TEXT', 'player_id': 'TEXT', 'player_name': 'TEXT', 'position': 'TEXT', 'minutes_played': 'REAL', 'tries': 'INTEGER', 'try_assists': 'INTEGER', 'line_breaks': 'INTEGER', 'line_break_assists': 'INTEGER', 'tackle_breaks': 'INTEGER', 'offloads': 'INTEGER', 'runs': 'INTEGER', 'run_metres': 'REAL', 'post_contact_metres': 'REAL', 'kick_return_metres': 'REAL', 'tackles': 'INTEGER', 'missed_tackles': 'INTEGER', 'ineffective_tackles': 'INTEGER', 'errors': 'INTEGER', 'penalties': 'INTEGER', 'sin_bins': 'INTEGER', 'send_offs': 'INTEGER'}, 'try_events': {'try_id': 'TEXT', 'match_id': 'TEXT', 'season': 'INTEGER', 'round': 'TEXT', 'minute': 'REAL', 'scoring_team': 'TEXT', 'opponent': 'TEXT', 'scorer_player_id': 'TEXT', 'scorer_name': 'TEXT', 'assister_player_id': 'TEXT', 'assister_name': 'TEXT', 'scorer_position': 'TEXT', 'channel': 'TEXT', 'try_type': 'TEXT', 'distance_from_goal_m': 'REAL', 'first_try': 'TEXT', 'last_try': 'TEXT', 'match_winning_try': 'TEXT'}, 'weather_history': {'weather_id': 'TEXT', 'match_id': 'TEXT', 'venue': 'TEXT', 'temperature_c': 'REAL', 'rainfall_mm': 'REAL', 'wind_speed_kmh': 'REAL', 'wind_direction': 'TEXT', 'humidity_pct': 'REAL', 'ground_condition': 'TEXT', 'weather_summary': 'TEXT', 'source': 'TEXT'}, 'venues_master': {'venue_id': 'TEXT', 'venue_name': 'TEXT', 'city': 'TEXT', 'state': 'TEXT', 'surface_type': 'TEXT', 'home_team': 'TEXT', 'capacity': 'INTEGER', 'average_score': 'REAL', 'average_tries': 'REAL', 'home_win_pct': 'REAL'}, 'referees_history': {'referee_id': 'TEXT', 'referee_name': 'TEXT', 'match_id': 'TEXT', 'penalties': 'INTEGER', 'six_agains': 'INTEGER', 'sin_bins': 'INTEGER', 'send_offs': 'INTEGER', 'total_points': 'INTEGER', 'home_win': 'TEXT'}, 'odds_history': {'odds_id': 'TEXT', 'match_id': 'TEXT', 'bookmaker': 'TEXT', 'market': 'TEXT', 'selection': 'TEXT', 'decimal_odds': 'REAL', 'timestamp': 'TEXT', 'opening_or_closing': 'TEXT', 'source': 'TEXT'}, 'injuries_suspensions_history': {'record_id': 'TEXT', 'player_id': 'TEXT', 'player_name': 'TEXT', 'team_id': 'TEXT', 'match_id': 'TEXT', 'status': 'TEXT', 'reason': 'TEXT', 'expected_return': 'TEXT', 'source': 'TEXT', 'notes': 'TEXT'}, 'milestones_history': {'milestone_id': 'TEXT', 'match_id': 'TEXT', 'player_id': 'TEXT', 'player_name': 'TEXT', 'team_id': 'TEXT', 'milestone_type': 'TEXT', 'milestone_value': 'INTEGER', 'notes': 'TEXT'}, 'data_quality_log': {'check_id': 'TEXT', 'table_name': 'TEXT', 'check_name': 'TEXT', 'severity': 'TEXT', 'rows_checked': 'INTEGER', 'issues_found': 'INTEGER', 'status': 'TEXT', 'checked_at': 'TEXT', 'notes': 'TEXT'}, 'dataset_versions': {'dataset_version_id': 'TEXT', 'dataset_name': 'TEXT', 'version_label': 'TEXT', 'created_at': 'TEXT', 'created_by': 'TEXT', 'source_files': 'TEXT', 'tables_included': 'TEXT', 'row_count_total': 'INTEGER', 'quality_score': 'REAL', 'notes': 'TEXT'}, 'import_log': {'import_id': 'TEXT', 'dataset_version_id': 'TEXT', 'table_name': 'TEXT', 'source_file': 'TEXT', 'imported_at': 'TEXT', 'rows_imported': 'INTEGER', 'rows_rejected': 'INTEGER', 'status': 'TEXT', 'notes': 'TEXT'}, 'relationship_quality_report': {'report_id': 'TEXT', 'dataset_version_id': 'TEXT', 'check_name': 'TEXT', 'table_name': 'TEXT', 'related_table': 'TEXT', 'severity': 'TEXT', 'issues_found': 'INTEGER', 'status': 'TEXT', 'notes': 'TEXT'}}
WAREHOUSE_DB_PATH = Path("database/oasl_historical_warehouse.db")

PRIMARY_KEYS = {
    "matches": ["match_id"],
    "teams_master": ["team_id"],
    "players_master": ["player_id"],
    "try_events": ["try_id"],
    "weather_history": ["weather_id"],
    "venues_master": ["venue_id"],
    "referees_history": ["referee_id", "match_id"],
    "odds_history": ["odds_id"],
    "injuries_suspensions_history": ["record_id"],
    "milestones_history": ["milestone_id"],
    "dataset_versions": ["dataset_version_id"],
    "import_log": ["import_id"],
    "relationship_quality_report": ["report_id"],
}

RELATIONSHIP_CHECKS = [
    ("team_lists_history", "match_id", "matches", "match_id"),
    ("player_match_stats", "match_id", "matches", "match_id"),
    ("try_events", "match_id", "matches", "match_id"),
    ("weather_history", "match_id", "matches", "match_id"),
    ("odds_history", "match_id", "matches", "match_id"),
    ("injuries_suspensions_history", "match_id", "matches", "match_id"),
    ("milestones_history", "match_id", "matches", "match_id"),
    ("team_lists_history", "player_id", "players_master", "player_id"),
    ("player_match_stats", "player_id", "players_master", "player_id"),
    ("try_events", "scorer_player_id", "players_master", "player_id"),
    ("team_lists_history", "team_id", "teams_master", "team_id"),
    ("player_match_stats", "team_id", "teams_master", "team_id"),
]

ALLOWED_VALUES = {
    "channel": ["Left Edge", "Middle", "Right Edge", "Kick / Other", ""],
    "starting_or_bench": ["Starting", "Bench", ""],
    "captain": ["YES", "NO", ""],
    "late_change_flag": ["YES", "NO", ""],
    "first_try": ["YES", "NO", ""],
    "last_try": ["YES", "NO", ""],
    "match_winning_try": ["YES", "NO", ""],
    "extra_time": ["YES", "NO", ""],
    "active": ["YES", "NO", ""],
    "opening_or_closing": ["Opening", "Current", "Closing", ""],
    "status": ["PASS", "WARN", "FAIL", "SUCCESS", "ERROR", "LOW", "MEDIUM", "HIGH", ""],
    "severity": ["PASS", "LOW", "MEDIUM", "HIGH", ""],
}

def get_warehouse_connection():
    WAREHOUSE_DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    return sqlite3.connect(WAREHOUSE_DB_PATH)

def create_warehouse_tables():
    conn = get_warehouse_connection()
    cur = conn.cursor()
    for table_name, fields in WAREHOUSE_SCHEMA.items():
        columns = ", ".join([f'"{field}" {dtype}' for field, dtype in fields.items()])
        cur.execute(f'CREATE TABLE IF NOT EXISTS "{table_name}" ({columns})')
    conn.commit()
    conn.close()

def read_warehouse_table(table_name):
    create_warehouse_tables()
    if table_name not in WAREHOUSE_SCHEMA:
        return pd.DataFrame()
    conn = get_warehouse_connection()
    try:
        df = pd.read_sql_query(f'SELECT * FROM "{table_name}"', conn)
    except Exception:
        df = pd.DataFrame(columns=list(WAREHOUSE_SCHEMA[table_name].keys()))
    conn.close()
    return df

def replace_warehouse_table(table_name, df):
    create_warehouse_tables()
    if table_name not in WAREHOUSE_SCHEMA:
        raise ValueError(f"Unknown warehouse table: {table_name}")
    expected_cols = list(WAREHOUSE_SCHEMA[table_name].keys())
    out = df.copy() if df is not None else pd.DataFrame()
    for col in expected_cols:
        if col not in out.columns:
            out[col] = ""
    out = out[expected_cols]
    conn = get_warehouse_connection()
    out.to_sql(table_name, conn, if_exists="replace", index=False)
    conn.close()

def append_warehouse_table(table_name, df):
    create_warehouse_tables()
    if table_name not in WAREHOUSE_SCHEMA:
        raise ValueError(f"Unknown warehouse table: {table_name}")
    expected_cols = list(WAREHOUSE_SCHEMA[table_name].keys())
    out = df.copy() if df is not None else pd.DataFrame()
    for col in expected_cols:
        if col not in out.columns:
            out[col] = ""
    out = out[expected_cols]
    conn = get_warehouse_connection()
    out.to_sql(table_name, conn, if_exists="append", index=False)
    conn.close()

def warehouse_table_counts():
    create_warehouse_tables()
    rows = []
    conn = get_warehouse_connection()
    for table_name in WAREHOUSE_SCHEMA:
        try:
            count = pd.read_sql_query(f'SELECT COUNT(*) AS n FROM "{table_name}"', conn)["n"].iloc[0]
        except Exception:
            count = 0
        rows.append({"table_name": table_name, "rows": int(count)})
    conn.close()
    return pd.DataFrame(rows)

def build_empty_template(table_name):
    if table_name not in WAREHOUSE_SCHEMA:
        return pd.DataFrame()
    return pd.DataFrame(columns=list(WAREHOUSE_SCHEMA[table_name].keys()))

def _issue(severity, issue, field="", fix="", table_name=""):
    return {"severity": severity, "table_name": table_name, "issue": issue, "field": field, "fix": fix}

def validate_warehouse_table(table_name, df):
    issues = []
    if table_name not in WAREHOUSE_SCHEMA:
        return pd.DataFrame([_issue("HIGH", "Unknown table", "", "Use a registered warehouse table.", table_name)])

    expected = WAREHOUSE_SCHEMA[table_name]
    if df is None:
        df = pd.DataFrame()

    for field in expected:
        if field not in df.columns:
            issues.append(_issue("HIGH", "Missing schema field", field, f"Add column {field}.", table_name))

    pk_fields = PRIMARY_KEYS.get(table_name, [])
    for field in pk_fields:
        if field in df.columns:
            blank_count = int((df[field].astype(str).str.strip() == "").sum())
            if blank_count:
                issues.append(_issue("HIGH", f"Blank primary key values found: {blank_count}", field, "Fill stable IDs.", table_name))
        else:
            issues.append(_issue("HIGH", "Primary key field missing", field, f"Add {field}.", table_name))

    if pk_fields and all(c in df.columns for c in pk_fields) and not df.empty:
        dupes = int(df.duplicated(pk_fields).sum())
        if dupes:
            issues.append(_issue("HIGH", f"Duplicate primary key rows: {dupes}", ",".join(pk_fields), "Remove duplicates.", table_name))

    numeric_fields = [f for f, dtype in expected.items() if dtype in ["INTEGER", "REAL"]]
    for field in numeric_fields:
        if field in df.columns and not df.empty:
            non_blank = df[field].astype(str).str.strip() != ""
            converted = pd.to_numeric(df.loc[non_blank, field], errors="coerce")
            bad = int(converted.isna().sum())
            if bad:
                issues.append(_issue("MEDIUM", f"Non-numeric values found: {bad}", field, "Use numeric values only.", table_name))

    for field, allowed in ALLOWED_VALUES.items():
        if field in df.columns and not df.empty:
            bad_values = sorted(set(df[field].astype(str).fillna("").unique()) - set(allowed))
            if bad_values:
                issues.append(_issue("MEDIUM", f"Unexpected allowed-value entries: {bad_values[:8]}", field, f"Use one of: {' | '.join(allowed)}", table_name))

    if not issues:
        issues.append(_issue("PASS", "No major schema issues found", "", "Ready for import.", table_name))

    return pd.DataFrame(issues)

def validate_relationships(dataset_version_id="current"):
    create_warehouse_tables()
    reports = []
    for child_table, child_field, parent_table, parent_field in RELATIONSHIP_CHECKS:
        child = read_warehouse_table(child_table)
        parent = read_warehouse_table(parent_table)

        if child.empty or parent.empty or child_field not in child.columns or parent_field not in parent.columns:
            reports.append({
                "report_id": str(uuid.uuid4()),
                "dataset_version_id": dataset_version_id,
                "check_name": f"{child_table}.{child_field} links to {parent_table}.{parent_field}",
                "table_name": child_table,
                "related_table": parent_table,
                "severity": "MEDIUM",
                "issues_found": 0,
                "status": "WARN",
                "notes": "Skipped because child or parent table is empty or missing fields.",
            })
            continue

        child_values = set(child[child_field].astype(str).str.strip())
        parent_values = set(parent[parent_field].astype(str).str.strip())
        child_values.discard("")
        parent_values.discard("")
        missing = child_values - parent_values

        reports.append({
            "report_id": str(uuid.uuid4()),
            "dataset_version_id": dataset_version_id,
            "check_name": f"{child_table}.{child_field} links to {parent_table}.{parent_field}",
            "table_name": child_table,
            "related_table": parent_table,
            "severity": "HIGH" if missing else "PASS",
            "issues_found": len(missing),
            "status": "FAIL" if missing else "PASS",
            "notes": "Missing parent IDs: " + ", ".join(list(missing)[:20]) if missing else "All relationship values matched.",
        })

    report_df = pd.DataFrame(reports)
    replace_warehouse_table("relationship_quality_report", report_df)
    return report_df

def create_dataset_version(dataset_name, version_label, created_by="", notes=""):
    counts = warehouse_table_counts()
    total_rows = int(counts["rows"].sum()) if not counts.empty else 0

    # Quality score is a simple starting measure: relationship pass rate minus high issue penalty.
    relationships = validate_relationships(version_label)
    if relationships.empty:
        quality_score = 0
    else:
        pass_rate = (relationships["status"] == "PASS").mean() * 100
        quality_score = round(float(pass_rate), 1)

    version_id = f"{dataset_name}-{version_label}".replace(" ", "_")
    record = pd.DataFrame([{
        "dataset_version_id": version_id,
        "dataset_name": dataset_name,
        "version_label": version_label,
        "created_at": datetime.now().isoformat(timespec="seconds"),
        "created_by": created_by,
        "source_files": "",
        "tables_included": ", ".join(counts[counts["rows"] > 0]["table_name"].tolist()) if not counts.empty else "",
        "row_count_total": total_rows,
        "quality_score": quality_score,
        "notes": notes,
    }])

    existing = read_warehouse_table("dataset_versions")
    if not existing.empty:
        existing = existing[existing["dataset_version_id"] != version_id]
        record = pd.concat([existing, record], ignore_index=True)
    replace_warehouse_table("dataset_versions", record)
    return record.tail(1)

def log_import(dataset_version_id, table_name, source_file, rows_imported, rows_rejected=0, status="SUCCESS", notes=""):
    record = pd.DataFrame([{
        "import_id": str(uuid.uuid4()),
        "dataset_version_id": dataset_version_id,
        "table_name": table_name,
        "source_file": source_file,
        "imported_at": datetime.now().isoformat(timespec="seconds"),
        "rows_imported": int(rows_imported),
        "rows_rejected": int(rows_rejected),
        "status": status,
        "notes": notes,
    }])
    append_warehouse_table("import_log", record)
    return record

def build_data_health_score():
    counts = warehouse_table_counts()
    rel = read_warehouse_table("relationship_quality_report")
    versions = read_warehouse_table("dataset_versions")

    total_rows = int(counts["rows"].sum()) if not counts.empty else 0
    failed_relationships = int((rel["status"] == "FAIL").sum()) if not rel.empty and "status" in rel.columns else 0
    warn_relationships = int((rel["status"] == "WARN").sum()) if not rel.empty and "status" in rel.columns else 0

    base = 100
    base -= failed_relationships * 8
    base -= warn_relationships * 2
    if total_rows == 0:
        base = 0
    score = max(min(base, 100), 0)

    return pd.DataFrame([{
        "total_rows": total_rows,
        "warehouse_tables": len(WAREHOUSE_SCHEMA),
        "failed_relationship_checks": failed_relationships,
        "warning_relationship_checks": warn_relationships,
        "dataset_versions": len(versions) if versions is not None else 0,
        "data_health_score": score,
    }])


# ---- Phase 1.5 historical backfill additions ----
import json as _json
_schema_file = Path("data_dictionary/warehouse_schema.json")
if _schema_file.exists():
    try:
        WAREHOUSE_SCHEMA.update(_json.loads(_schema_file.read_text(encoding="utf-8")))
    except Exception:
        pass

def ensure_phase_1_5_tables():
    create_warehouse_tables()

def build_default_backfill_plan(start_season=2010, end_season=2026):
    rows = []
    for season in range(int(start_season), int(end_season) + 1):
        rows.append({
            "season": season,
            "target_matches": 201 if season < 2023 else 204,
            "matches_loaded": 0,
            "team_lists_loaded": 0,
            "player_stats_loaded": 0,
            "try_events_loaded": 0,
            "weather_loaded": 0,
            "odds_loaded": 0,
            "injuries_loaded": 0,
            "season_status": "Not Started",
            "priority": 1 if season >= 2020 else 2,
            "notes": "",
        })
    return pd.DataFrame(rows)

def refresh_backfill_plan_from_warehouse(existing_plan=None):
    ensure_phase_1_5_tables()
    matches = read_warehouse_table("matches")
    team_lists = read_warehouse_table("team_lists_history")
    player_stats = read_warehouse_table("player_match_stats")
    try_events = read_warehouse_table("try_events")
    weather = read_warehouse_table("weather_history")
    odds = read_warehouse_table("odds_history")
    injuries = read_warehouse_table("injuries_suspensions_history")

    plan = existing_plan.copy() if existing_plan is not None and not existing_plan.empty else read_warehouse_table("season_backfill_plan")
    if plan.empty:
        plan = build_default_backfill_plan()

    for idx, row in plan.iterrows():
        season = int(row.get("season", 0))
        if not matches.empty and "season" in matches.columns:
            season_matches = matches[pd.to_numeric(matches["season"], errors="coerce").fillna(0).astype(int) == season]
            plan.loc[idx, "matches_loaded"] = len(season_matches)
            match_ids = set(season_matches["match_id"].astype(str)) if "match_id" in season_matches.columns else set()
        else:
            match_ids = set()

        def count_by_match(df):
            if df is None or df.empty or "match_id" not in df.columns or not match_ids:
                return 0
            return int(df[df["match_id"].astype(str).isin(match_ids)]["match_id"].nunique())

        plan.loc[idx, "team_lists_loaded"] = count_by_match(team_lists)
        plan.loc[idx, "player_stats_loaded"] = count_by_match(player_stats)
        plan.loc[idx, "try_events_loaded"] = count_by_match(try_events)
        plan.loc[idx, "weather_loaded"] = count_by_match(weather)
        plan.loc[idx, "odds_loaded"] = count_by_match(odds)
        plan.loc[idx, "injuries_loaded"] = count_by_match(injuries)

        target = max(float(row.get("target_matches", 0) or 0), 1)
        core_pct = (
            min(float(plan.loc[idx, "matches_loaded"]) / target, 1) * 0.30 +
            min(float(plan.loc[idx, "team_lists_loaded"]) / target, 1) * 0.20 +
            min(float(plan.loc[idx, "player_stats_loaded"]) / target, 1) * 0.25 +
            min(float(plan.loc[idx, "try_events_loaded"]) / target, 1) * 0.15 +
            min(float(plan.loc[idx, "weather_loaded"]) / target, 1) * 0.05 +
            min(float(plan.loc[idx, "odds_loaded"]) / target, 1) * 0.05
        ) * 100

        if core_pct >= 90:
            status = "Ready For Modelling"
        elif core_pct >= 60:
            status = "In Progress"
        elif core_pct > 0:
            status = "Started"
        else:
            status = "Not Started"
        plan.loc[idx, "season_status"] = status

    replace_warehouse_table("season_backfill_plan", plan)
    return plan

def build_season_completeness_report():
    plan = refresh_backfill_plan_from_warehouse()
    rows = []
    for _, row in plan.iterrows():
        target = max(float(row.get("target_matches", 0) or 0), 1)
        metrics = {
            "matches_pct": min(float(row.get("matches_loaded", 0) or 0) / target * 100, 100),
            "team_lists_pct": min(float(row.get("team_lists_loaded", 0) or 0) / target * 100, 100),
            "player_stats_pct": min(float(row.get("player_stats_loaded", 0) or 0) / target * 100, 100),
            "try_events_pct": min(float(row.get("try_events_loaded", 0) or 0) / target * 100, 100),
            "weather_pct": min(float(row.get("weather_loaded", 0) or 0) / target * 100, 100),
            "odds_pct": min(float(row.get("odds_loaded", 0) or 0) / target * 100, 100),
        }
        overall = (
            metrics["matches_pct"] * 0.30 +
            metrics["team_lists_pct"] * 0.20 +
            metrics["player_stats_pct"] * 0.25 +
            metrics["try_events_pct"] * 0.15 +
            metrics["weather_pct"] * 0.05 +
            metrics["odds_pct"] * 0.05
        )
        readiness = "Model Ready" if overall >= 90 else ("Training Partial" if overall >= 60 else ("Data Started" if overall > 0 else "Not Ready"))
        rows.append({
            "season": int(row.get("season", 0)),
            **{k: round(v, 1) for k, v in metrics.items()},
            "overall_completeness_pct": round(overall, 1),
            "readiness": readiness,
        })
    report = pd.DataFrame(rows)
    replace_warehouse_table("season_completeness_report", report)
    return report

def build_missing_data_report():
    plan = refresh_backfill_plan_from_warehouse()
    reports = []
    for _, row in plan.iterrows():
        season = int(row.get("season", 0))
        target = int(row.get("target_matches", 0) or 0)
        checks = [
            ("matches", "matches_loaded", "HIGH"),
            ("team_lists", "team_lists_loaded", "HIGH"),
            ("player_stats", "player_stats_loaded", "HIGH"),
            ("try_events", "try_events_loaded", "HIGH"),
            ("weather", "weather_loaded", "MEDIUM"),
            ("odds", "odds_loaded", "MEDIUM"),
            ("injuries", "injuries_loaded", "LOW"),
        ]
        for area, field, severity in checks:
            loaded = int(row.get(field, 0) or 0)
            if target and loaded < target:
                reports.append({
                    "report_id": str(uuid.uuid4()),
                    "season": season,
                    "match_id": "",
                    "missing_area": area,
                    "severity": severity,
                    "status": "MISSING" if loaded == 0 else "PARTIAL",
                    "notes": f"{loaded}/{target} match-level records loaded for {area}.",
                })
    report_df = pd.DataFrame(reports)
    replace_warehouse_table("missing_data_report", report_df)
    return report_df


# ---- Phase 2 AI Core schema additions ----
WAREHOUSE_SCHEMA.update({'phase2_master_features': {'player_id': 'TEXT', 'player_name': 'TEXT', 'team_id': 'TEXT', 'position': 'TEXT', 'overall_feature_score': 'REAL', 'feature_confidence': 'REAL'}, 'phase2_player_dna': {'player_id': 'TEXT', 'player_name': 'TEXT', 'team_id': 'TEXT', 'position': 'TEXT', 'try_scoring_dna': 'REAL', 'explosiveness_dna': 'REAL', 'finishing_dna': 'REAL', 'physical_dna': 'REAL', 'momentum_dna': 'REAL', 'confidence_dna': 'REAL', 'overall_player_dna': 'REAL', 'dna_summary': 'TEXT'}, 'phase2_team_dna_2': {'team': 'TEXT', 'attack_dna': 'REAL', 'defence_dna': 'REAL', 'momentum_dna': 'REAL', 'left_edge_attack_pct': 'REAL', 'middle_attack_pct': 'REAL', 'right_edge_attack_pct': 'REAL', 'kick_other_pct': 'REAL', 'primary_attack_channel': 'TEXT', 'overall_team_dna': 'REAL', 'team_identity': 'TEXT'}, 'phase2_matchup_intelligence': {'match_id': 'TEXT', 'home_team': 'TEXT', 'away_team': 'TEXT', 'home_matchup_score': 'REAL', 'away_matchup_score': 'REAL', 'predicted_winner': 'TEXT', 'winner_probability': 'REAL', 'biggest_mismatch': 'TEXT', 'matchup_summary': 'TEXT'}, 'phase2_match_simulation': {'match_id': 'TEXT', 'home_team': 'TEXT', 'away_team': 'TEXT', 'home_win_prob': 'REAL', 'away_win_prob': 'REAL', 'draw_prob': 'REAL', 'avg_home_score': 'REAL', 'avg_away_score': 'REAL', 'predicted_score': 'TEXT', 'predicted_winner': 'TEXT', 'sim_confidence': 'REAL'}, 'phase2_try_market_simulation': {'player_id': 'TEXT', 'player_name': 'TEXT', 'team_id': 'TEXT', 'position': 'TEXT', 'anytime_prob': 'REAL', 'first_try_prob': 'REAL', 'two_plus_prob': 'REAL', 'three_plus_prob': 'REAL', 'anytime_fair_odds': 'REAL', 'first_try_fair_odds': 'REAL', 'two_plus_fair_odds': 'REAL', 'three_plus_fair_odds': 'REAL'}, 'phase2_ensemble_predictions': {'match_id': 'TEXT', 'predicted_winner': 'TEXT', 'matchup_model_prob': 'REAL', 'simulation_model_prob': 'REAL', 'final_win_probability': 'REAL', 'agreement_score': 'REAL', 'confidence_label': 'TEXT', 'ensemble_summary': 'TEXT'}, 'phase2_realtime_events': {'event_time': 'TEXT', 'event_type': 'TEXT', 'team': 'TEXT', 'player': 'TEXT', 'impact': 'REAL', 'notes': 'TEXT'}, 'phase2_learning_summary': {'metric': 'TEXT', 'value': 'REAL', 'notes': 'TEXT'}})
