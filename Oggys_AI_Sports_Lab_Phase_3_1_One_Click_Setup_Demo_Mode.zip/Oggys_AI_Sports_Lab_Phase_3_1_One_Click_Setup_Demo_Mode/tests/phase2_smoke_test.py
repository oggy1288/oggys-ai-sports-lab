import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd
from src.phase2_feature_engine import build_master_feature_table
from src.phase2_player_dna_engine import build_player_dna
from src.phase2_team_dna_2_engine import build_team_dna_2
from src.phase2_matchup_engine import build_matchup_intelligence
from src.phase2_simulation_engine import simulate_matches, simulate_try_markets
from src.phase2_ensemble_learning_engine import build_ensemble_predictions

matches=pd.DataFrame([
 {"match_id":"M1","season":2026,"round":"R1","home_team":"PAN","away_team":"RAB","home_score":34,"away_score":16,"winner":"PAN"}
])
stats=pd.DataFrame([
 {"match_id":"M1","season":2026,"round":"R1","team_id":"PAN","player_id":"P1","player_name":"Thomas Jenkins","position":"Centre","minutes_played":80,"tries":2,"line_breaks":2,"tackle_breaks":5,"run_metres":150}
])
tries=pd.DataFrame([
 {"try_id":"T1","match_id":"M1","season":2026,"round":"R1","minute":12,"scoring_team":"PAN","opponent":"RAB","scorer_player_id":"P1","scorer_name":"Thomas Jenkins","channel":"Right Edge"}
])
features=build_master_feature_table(stats, tries, matches)
pdna=build_player_dna(features)
tdna=build_team_dna_2(matches, tries, stats)
matchups=build_matchup_intelligence(matches, tdna, pdna)
sims=simulate_matches(matchups, sims=100)
markets=simulate_try_markets(pdna, tdna)
ens=build_ensemble_predictions(matchups, sims)
assert not features.empty
assert not pdna.empty
assert not tdna.empty
assert not matchups.empty
assert not sims.empty
assert not markets.empty
assert not ens.empty
print("PASS")
