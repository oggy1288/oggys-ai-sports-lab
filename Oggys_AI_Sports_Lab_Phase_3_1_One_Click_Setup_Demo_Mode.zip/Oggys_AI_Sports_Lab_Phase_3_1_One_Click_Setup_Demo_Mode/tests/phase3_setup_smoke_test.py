import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.phase3_setup_engine import load_demo_data, run_phase2_pipeline, setup_status

load_demo_data()
outputs = run_phase2_pipeline(sims=100)
status = setup_status()

assert not outputs["ensemble"].empty
assert not outputs["try_markets"].empty
assert not outputs["player_dna"].empty
assert (status["status"] == "PASS").sum() >= 6
print("PASS")
