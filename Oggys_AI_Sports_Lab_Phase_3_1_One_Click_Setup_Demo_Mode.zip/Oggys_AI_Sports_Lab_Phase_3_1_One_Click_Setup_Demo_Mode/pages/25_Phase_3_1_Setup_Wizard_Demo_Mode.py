import streamlit as st
import pandas as pd

from src.phase3_setup_engine import (
    load_demo_data,
    run_phase2_pipeline,
    setup_status,
    reset_demo_outputs,
)
from src.warehouse_engine import read_warehouse_table, warehouse_table_counts
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 3.1 Setup Wizard", layout="wide")
mobile_header("Phase 3.1 — One-Click Setup & Demo Mode", "Load demo data, run the AI pipeline, and check the app is working")

tabs = st.tabs(["Setup Wizard", "Demo Results", "App Health", "How To Use"])

with tabs[0]:
    st.subheader("One-Click Setup")
    st.write("Use this when you want to test Oggy's AI Sports Lab without importing real data yet.")

    sims = st.number_input("Simulation runs", min_value=100, max_value=100000, value=2500, step=100)

    col1, col2, col3 = st.columns(3)

    with col1:
        if st.button("1. Load demo data", use_container_width=True):
            counts = load_demo_data()
            st.success("Demo data loaded.")
            st.dataframe(counts, use_container_width=True)

    with col2:
        if st.button("2. Run AI pipeline", use_container_width=True):
            outputs = run_phase2_pipeline(sims=sims)
            st.success("AI pipeline complete.")
            st.write("Ensemble predictions")
            st.dataframe(outputs["ensemble"], use_container_width=True)

    with col3:
        if st.button("Reset Phase 2 outputs", use_container_width=True):
            reset_demo_outputs()
            st.warning("Phase 2 output tables reset.")

    st.subheader("Setup Status")
    st.dataframe(setup_status(), use_container_width=True)

with tabs[1]:
    st.subheader("Demo AI Results")

    st.markdown("### Match Winner Predictions")
    ensemble = read_warehouse_table("phase2_ensemble_predictions")
    if ensemble.empty:
        st.info("Run the AI pipeline first.")
    else:
        st.dataframe(ensemble, use_container_width=True)

    st.markdown("### Top Try Market Predictions")
    markets = read_warehouse_table("phase2_try_market_simulation")
    if markets.empty:
        st.info("Run the AI pipeline first.")
    else:
        cols = [c for c in ["player_name","team_id","position","anytime_prob","first_try_prob","two_plus_prob","three_plus_prob","anytime_fair_odds"] if c in markets.columns]
        st.dataframe(markets[cols].head(20), use_container_width=True)

    st.markdown("### Player DNA")
    player_dna = read_warehouse_table("phase2_player_dna")
    if not player_dna.empty:
        st.dataframe(player_dna, use_container_width=True)

with tabs[2]:
    st.subheader("App Health")
    status = setup_status()
    st.dataframe(status, use_container_width=True)

    passed = (status["status"] == "PASS").sum() if not status.empty else 0
    total = len(status)
    st.metric("Setup Completion", f"{passed}/{total}")

    counts = warehouse_table_counts()
    st.subheader("Warehouse Table Counts")
    st.dataframe(counts, use_container_width=True)

with tabs[3]:
    st.subheader("How To Use This Page")
    st.write("""
    Start here if you're using the app for the first time.

    1. Click **Load demo data**.
    2. Click **Run AI pipeline**.
    3. Open **Demo Results** to see predictions.
    4. Open **App Health** to check each part is working.

    Once this works, you can replace the demo data with real NRL historical CSVs through the Phase 1 import pages.
    """)
