import streamlit as st
import pandas as pd

from src.source_adapters import (
    ADAPTER_CONFIG,
    adapter_summary,
    adapter_template,
    apply_adapter,
    import_with_adapter,
)
from src.warehouse_engine import read_warehouse_table
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 1.3 Source Adapters", layout="wide")
mobile_header("Phase 1.3 — Source Adapter Framework", "Turn raw CSVs into clean warehouse tables")

st.info("Use this page to import fixtures/results, player stats, try events, weather and odds into the warehouse using consistent mapping rules.")

tabs = st.tabs(["Adapters", "Import", "Preview Mapping", "Warehouse Output", "Guide"])

with tabs[0]:
    st.subheader("Available Source Adapters")
    st.dataframe(adapter_summary(), use_container_width=True)

with tabs[1]:
    st.subheader("Import CSV With Adapter")
    adapter = st.selectbox("Adapter", list(ADAPTER_CONFIG.keys()))
    mode = st.radio("Import mode", ["replace", "append"], horizontal=True)
    dataset_version_id = st.text_input("Dataset version ID", value="working")
    uploaded = st.file_uploader("Upload source CSV", type=["csv"])

    st.download_button(
        "Download target table template",
        adapter_template(adapter).to_csv(index=False).encode("utf-8"),
        f"{adapter}_target_template.csv",
        "text/csv",
    )

    if uploaded:
        raw = pd.read_csv(uploaded)
        st.subheader("Raw preview")
        st.dataframe(raw.head(50), use_container_width=True)

        clean = apply_adapter(adapter, raw)
        st.subheader("Clean warehouse preview")
        st.dataframe(clean.head(50), use_container_width=True)

        if st.button("Import using adapter"):
            imported, issues = import_with_adapter(adapter, raw, dataset_version_id, uploaded.name, mode)
            st.success(f"Imported {len(imported)} rows.")
            st.dataframe(issues, use_container_width=True)

with tabs[2]:
    st.subheader("Preview Mapping Without Importing")
    adapter = st.selectbox("Adapter to preview", list(ADAPTER_CONFIG.keys()), key="preview_adapter")
    uploaded_preview = st.file_uploader("Upload CSV for preview", type=["csv"], key="preview_upload")

    if uploaded_preview:
        raw = pd.read_csv(uploaded_preview)
        clean = apply_adapter(adapter, raw)
        col1, col2 = st.columns(2)
        with col1:
            st.write("Raw")
            st.dataframe(raw.head(30), use_container_width=True)
        with col2:
            st.write("Mapped")
            st.dataframe(clean.head(30), use_container_width=True)

with tabs[3]:
    st.subheader("Warehouse Output")
    adapter = st.selectbox("Adapter warehouse table", list(ADAPTER_CONFIG.keys()), key="output_adapter")
    target = ADAPTER_CONFIG[adapter]["target_table"]
    df = read_warehouse_table(target)
    st.caption(f"Target table: {target}")
    st.dataframe(df, use_container_width=True)

with tabs[4]:
    st.subheader("How Source Adapters Work")
    st.write("""
    A source adapter converts messy CSV column names into the clean OASL warehouse schema.

    Example:
    - `home` becomes `home_team`
    - `away` becomes `away_team`
    - `odds` becomes `decimal_odds`
    - `player` becomes `scorer_name` for try events

    The goal is to keep imports flexible while protecting the warehouse structure.
    """)
