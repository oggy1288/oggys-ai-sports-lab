import streamlit as st
import pandas as pd

from src.database import read_table, replace_table
from src.wizard_engine import build_wizard_status, progress_percent
from src.name_matching import build_alias_table, resolve_names_against_master
from src.integrity_checker import build_player_integrity_report
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Weekly Setup Wizard", layout="wide")
mobile_header("V7.1 Weekly Setup Wizard", "Round setup, data checks, odds, predictions and dashboard")

tabs = st.tabs([
    "1 Round",
    "2 Fixtures",
    "3 Team Lists",
    "4 Stats & Odds",
    "5 Context",
    "6 Checks",
    "7 Predictions",
    "8 Status",
])

with tabs[0]:
    st.subheader("Step 1 — Select Round")
    with st.form("round_form"):
        round_no = st.text_input("Round", value="")
        season = st.text_input("Season", value="2026")
        week_start = st.date_input("Week start")
        notes = st.text_area("Round notes")
        submitted = st.form_submit_button("Save round setup")

    if submitted:
        replace_table("wizard_state", pd.DataFrame([{
            "round": round_no,
            "season": season,
            "week_start": str(week_start),
            "notes": notes,
        }]))
        st.success("Round setup saved.")

    state = read_table("wizard_state")
    if not state.empty:
        st.dataframe(state, use_container_width=True)

with tabs[1]:
    st.subheader("Step 2 — Fixtures")
    st.info("Add the games for this round. These drive which teams and players should appear.")
    current = read_table("fixtures")
    if current.empty:
        current = pd.DataFrame(columns=["fixture_id", "round", "date", "home_team", "away_team", "venue"])
    edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
    if st.button("Save fixtures"):
        replace_table("fixtures", edited)
        st.success("Fixtures saved.")

with tabs[2]:
    st.subheader("Step 3 — Team Lists")
    st.info("Only players named in the weekly team list should show in weekly predictions by default.")
    current = read_table("team_lists")
    if current.empty:
        current = pd.DataFrame(columns=["round", "team", "player", "position", "starting", "edge", "minutes_projection"])
    edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
    if st.button("Save team lists"):
        replace_table("team_lists", edited)
        st.success("Team lists saved.")

with tabs[3]:
    st.subheader("Step 4 — Player Stats, Odds & Injuries")
    st.info("For best-price comparison, use the Live Odds Aggregator page after adding/importing odds.")

    data_type = st.radio("Choose table", ["player_stats", "odds", "injuries"], horizontal=True)
    current = read_table(data_type)

    if current.empty:
        if data_type == "player_stats":
            current = pd.DataFrame(columns=[
                "player_id", "player", "team", "position", "tries", "games", "last5_tries",
                "line_breaks", "tackle_breaks", "avg_minutes", "goal_line_role",
                "career_games", "middle_try_role", "opponent_middle_weakness",
                "team_red_zone_middle_attack"
            ])
        elif data_type == "odds":
            current = pd.DataFrame(columns=["fixture_id", "round", "player", "team", "market", "bookmaker", "odds", "timestamp"])
        else:
            current = pd.DataFrame(columns=["player", "status", "impact", "minutes_adjustment"])

    edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
    if st.button(f"Save {data_type}"):
        replace_table(data_type, edited)
        st.success(f"{data_type} saved.")

    try:
        st.page_link("pages/13_Live_Odds_Aggregator.py", label="Open Live Odds Aggregator", icon="💸")
    except Exception:
        st.caption("Use the sidebar to open Live Odds Aggregator.")

with tabs[4]:
    st.subheader("Step 5 — Context")
    st.info("Add the special factors that make your model smarter: milestones, Origin, narrative, and middle forwards.")

    context_type = st.radio(
        "Choose context table",
        ["origin_players", "origin_team_impact", "narrative_context", "middle_forward_context"],
        horizontal=False,
    )
    current = read_table(context_type)

    if current.empty:
        if context_type == "origin_players":
            current = pd.DataFrame(columns=["player", "team", "origin_status", "origin_minutes", "origin_note"])
        elif context_type == "origin_team_impact":
            current = pd.DataFrame(columns=["team", "origin_team_status", "origin_team_note"])
        elif context_type == "narrative_context":
            current = pd.DataFrame(columns=["player", "team", "context_type", "narrative_note"])
        else:
            current = pd.DataFrame(columns=[
                "player", "team", "middle_try_role", "opponent",
                "opponent_middle_weakness", "team_red_zone_middle_attack",
                "weather_impact", "middle_note"
            ])

    edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
    if st.button(f"Save {context_type}"):
        replace_table(context_type, edited)
        st.success(f"{context_type} saved.")

with tabs[5]:
    st.subheader("Step 6 — Run Checks")

    if st.button("Run name matching"):
        players = read_table("player_stats")
        aliases = build_alias_table(players)
        replace_table("player_aliases", aliases)

        reports = []
        for source_table in ["team_lists", "odds", "injuries", "origin_players", "narrative_context"]:
            src = read_table(source_table)
            if not src.empty:
                report = resolve_names_against_master(src, aliases)
                report["source_table"] = source_table
                if "player" in report.columns:
                    report = report.rename(columns={"player": "input_player"})
                if "match_type" in report.columns:
                    report["action"] = report["match_type"].apply(
                        lambda x: "OK" if x in ["Exact", "Initials", "Fuzzy"] else "Fix spelling or add alias"
                    )
                reports.append(report)

        if reports:
            combined = pd.concat(reports, ignore_index=True)
            save_cols = [c for c in [
                "source_table", "input_player", "matched_player_id", "matched_player",
                "matched_team", "match_score", "match_type", "action"
            ] if c in combined.columns]
            replace_table("name_match_report", combined[save_cols])
            st.success("Name matching complete.")
            st.dataframe(combined[save_cols], use_container_width=True)
        else:
            st.warning("No source tables found to check.")

    if st.button("Run integrity checker"):
        report = build_player_integrity_report(
            read_table("player_stats"),
            read_table("team_lists"),
            read_table("odds"),
            read_table("injuries"),
        )
        replace_table("player_integrity_report", report)
        st.success("Integrity check complete.")
        st.dataframe(report, use_container_width=True)

with tabs[6]:
    st.subheader("Step 7 — Run Predictions")
    st.info("Run the prediction engine after completing setup and checks.")

    try:
        st.page_link("pages/2_Run_Predictor.py", label="Open Run Predictor", icon="🎯")
        st.page_link("pages/13_Live_Odds_Aggregator.py", label="Open Live Odds Aggregator", icon="💸")
        st.page_link("pages/5_Mobile_Dashboard.py", label="Open Mobile Dashboard", icon="📱")
    except Exception:
        st.write("Open the Run Predictor, Live Odds Aggregator, or Mobile Dashboard page from the sidebar.")

with tabs[7]:
    st.subheader("Step 8 — Round Status")

    tables = {
        "wizard_state": read_table("wizard_state"),
        "fixtures": read_table("fixtures"),
        "team_lists": read_table("team_lists"),
        "player_stats": read_table("player_stats"),
        "odds": read_table("odds"),
        "injuries": read_table("injuries"),
        "milestone_report": read_table("milestone_report"),
        "origin_players": read_table("origin_players"),
        "narrative_context": read_table("narrative_context"),
        "middle_forward_context": read_table("middle_forward_context"),
        "name_match_report": read_table("name_match_report"),
        "player_integrity_report": read_table("player_integrity_report"),
        "predictions": read_table("predictions"),
    }

    status = build_wizard_status(tables)
    replace_table("wizard_status", status)

    pct = progress_percent(status)
    st.progress(int(pct))
    st.metric("Setup Progress", f"{pct}%")
    st.dataframe(status, use_container_width=True)

    incomplete = status[status["status"] != "Complete"]
    if incomplete.empty:
        st.success("Round setup is complete.")
    else:
        st.warning("Some steps still need work.")
        st.dataframe(incomplete[["step", "name", "next_action"]], use_container_width=True)
