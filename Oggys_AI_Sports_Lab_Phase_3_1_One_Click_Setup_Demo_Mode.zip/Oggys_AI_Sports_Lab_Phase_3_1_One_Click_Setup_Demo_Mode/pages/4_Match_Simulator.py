
import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
import numpy as np

st.set_page_config(page_title="Match Simulator", layout="wide")
inject_mobile_css()
st.title("Simple Match Simulator")
st.caption("Starter V6 simulator. Later this can connect to the full Monte Carlo engine.")

c1,c2,c3 = st.columns(3)
home = c1.text_input('Home Team', 'Broncos')
away = c2.text_input('Away Team', 'Storm')
sims = c3.number_input('Simulations', min_value=1000, max_value=50000, value=10000, step=1000)

c4,c5 = st.columns(2)
home_rating = c4.slider('Home Power Rating', 0, 100, 84)
away_rating = c5.slider('Away Power Rating', 0, 100, 80)

if st.button('Run Match Simulation'):
    rng = np.random.default_rng(42)
    home_mu = 18 + (home_rating - away_rating) * 0.18 + 2
    away_mu = 18 + (away_rating - home_rating) * 0.18
    home_scores = rng.poisson(max(home_mu, 4), int(sims))
    away_scores = rng.poisson(max(away_mu, 4), int(sims))
    home_win = (home_scores > away_scores).mean()
    away_win = (away_scores > home_scores).mean()
    draw = (home_scores == away_scores).mean()
    c1,c2,c3 = st.columns(3)
    c1.metric(f'{home} Win %', f'{home_win*100:.1f}%')
    c2.metric(f'{away} Win %', f'{away_win*100:.1f}%')
    c3.metric('Draw %', f'{draw*100:.1f}%')
    st.write(f"Expected score: **{home} {home_scores.mean():.1f} - {away_scores.mean():.1f} {away}**")
    df = pd.DataFrame({'Home Score': home_scores, 'Away Score': away_scores, 'Total Points': home_scores+away_scores})
    st.dataframe(df.describe().round(2), use_container_width=True)
