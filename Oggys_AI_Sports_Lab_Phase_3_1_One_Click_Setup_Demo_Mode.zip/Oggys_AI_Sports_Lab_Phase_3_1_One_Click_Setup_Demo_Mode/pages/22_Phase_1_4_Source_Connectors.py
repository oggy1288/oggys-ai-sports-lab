import streamlit as st
import pandas as pd

from src.connector_engine import (
    source_registry_table,
    build_import_plan,
    field_coverage_report,
    connector_health_report,
    import_source_csv,
    preview_source_csv,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 1.4 Source Connectors", layout="wide")
mobile_header("Phase 1.4 — Source Connectors & Import Planner", "Plan, import and monitor verified data sources")

st.warning("This build is CSV-first and API-ready. It does not scrape bookmaker websites. Use approved APIs, licensed feeds or verified CSV exports.")

tabs = st.tabs(["Source Registry", "Import Planner", "Import Source", "Field Coverage", "Connector Health", "Guide"])

with tabs[0]:
    st.subheader("Source Registry")
    registry = source_registry_table()
    st.dataframe(registry, use_container_width=True)

with tabs[1]:
    st.subheader("Import Plan")
    plan = build_import_plan()
    st.dataframe(plan, use_container_width=True)

with tabs[2]:
    st.subheader("Import Source CSV")
    registry = source_registry_table()
    source_id = st.selectbox("Source", registry["source_id"].tolist())
    mode = st.radio("Mode", ["replace", "append"], horizontal=True)
    dataset_version_id = st.text_input("Dataset version ID", value="working")
    uploaded = st.file_uploader("Upload CSV", type=["csv"])

    if uploaded:
        raw = pd.read_csv(uploaded)
        st.write("Raw preview")
        st.dataframe(raw.head(50), use_container_width=True)

        try:
            clean = preview_source_csv(source_id, raw)
            st.write("Mapped preview")
            st.dataframe(clean.head(50), use_container_width=True)
        except Exception as exc:
            st.error(f"Preview failed: {exc}")
            clean = pd.DataFrame()

        if st.button("Import source CSV"):
            try:
                imported, issues = import_source_csv(source_id, raw, dataset_version_id, uploaded.name, mode)
                st.success(f"Imported {len(imported)} rows.")
                st.dataframe(issues, use_container_width=True)
            except Exception as exc:
                st.error(f"Import failed: {exc}")

with tabs[3]:
    st.subheader("Field Coverage Report")
    coverage = field_coverage_report()
    if coverage.empty:
        st.info("No coverage report available.")
    else:
        source_filter = st.selectbox("Source filter", ["All"] + sorted(coverage["source_id"].unique().tolist()))
        shown = coverage if source_filter == "All" else coverage[coverage["source_id"] == source_filter]
        st.dataframe(shown, use_container_width=True)

with tabs[4]:
    st.subheader("Connector Health")
    health = connector_health_report()
    st.dataframe(health, use_container_width=True)

with tabs[5]:
    st.subheader("Guide")
    st.write("""
    Phase 1.4 creates a safe way to bring data into the warehouse.

    Workflow:
    1. Check the Source Registry.
    2. Review the Import Planner.
    3. Upload verified CSV files.
    4. Preview mapped warehouse output.
    5. Import into the warehouse.
    6. Check field coverage and connector health.

    Priority data sources:
    - Fixtures and results
    - Player match stats
    - Try events
    - Weather history
    - Odds history
    """)
