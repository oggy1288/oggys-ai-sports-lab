import streamlit as st
from src.ui_helpers import inject_mobile_css
inject_mobile_css()
import pandas as pd
from src.database import replace_table, read_table, table_counts

st.title("Upload Data")

st.write("Upload CSV files and save them into the SQLite database.")

table_options = [
    "fixtures",
    "team_lists",
    "player_stats",
    "team_stats",
    "weather",
    "odds",
    "injuries",
    "model_history",
]

table = st.selectbox("Choose table", table_options)
uploaded = st.file_uploader(f"Upload {table}.csv", type=["csv"])

if uploaded:
    df = pd.read_csv(uploaded)
    st.write("Preview")
    st.dataframe(df.head(25), use_container_width=True)

    if st.button("Save to database"):
        replace_table(table, df)
        st.success(f"Saved {len(df)} rows to {table}.")

st.subheader("Current Database Counts")
st.dataframe(table_counts(), use_container_width=True)

st.subheader("Current Table Preview")
current = read_table(table)
if current.empty:
    st.info("No rows saved yet.")
else:
    st.dataframe(current.head(50), use_container_width=True)