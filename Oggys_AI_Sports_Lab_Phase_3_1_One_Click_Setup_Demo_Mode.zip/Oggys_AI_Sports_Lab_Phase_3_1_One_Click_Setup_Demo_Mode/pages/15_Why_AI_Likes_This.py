import streamlit as st
import pandas as pd

from src.database import read_table, replace_table
from src.why_engine import build_why_report, factor_scores, build_reasons, verdict, bar, traffic_light
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Why AI Likes This", layout="wide")
mobile_header("Why AI Likes This", "Plain-English prediction reasoning for each player")

predictions = read_table("predictions")

if predictions.empty:
    st.warning("No predictions saved yet. Run the predictor first.")
else:
    report = build_why_report(predictions)
    replace_table("why_ai_report", report)

    players = report["player"].dropna().tolist()
    selected = st.selectbox("Choose player", players)

    row = predictions[predictions["player"] == selected].iloc[0]
    why = report[report["player"] == selected].iloc[0]

    col1, col2 = st.columns([2, 1])
    with col1:
        st.subheader(f"{row.get('player', '')}")
        st.caption(f"{row.get('team', '')} — {row.get('position', '')}")

    with col2:
        st.metric("OASL Score", f"{float(row.get('model_score', 0)):.1f}")

    st.markdown("### 🧠 AI Summary")
    st.success(why["ai_summary"])

    st.markdown("### ✅ Why AI Likes This")
    reasons, risks = build_reasons(row)
    for r in reasons:
        st.write(f"🟢 {r}")

    st.markdown("### ⚠️ Risk Checks")
    if risks:
        for r in risks:
            st.write(f"🟡 {r}")
    else:
        st.write("🟢 No major risk flags from current inputs.")

    st.markdown("### 📊 Confidence Breakdown")
    scores = factor_scores(row)
    for name, score in scores.items():
        light = traffic_light(score)
        st.write(f"{light} **{name}**  `{bar(score)}`  {score:.1f}/100")

    st.markdown("### ⭐ Overall Verdict")
    st.info(verdict(row))

    st.markdown("### Full Why Report")
    st.dataframe(report, use_container_width=True)

    csv = report.to_csv(index=False).encode("utf-8")
    st.download_button("Download why report", csv, "why_ai_report.csv", "text/csv")
