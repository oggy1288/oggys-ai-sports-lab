import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import read_table, replace_table, append_table
from src.narrative_engine import NARRATIVE_BOOSTS, apply_narrative_context

st.set_page_config(page_title="Narrative Context Engine", layout="wide")
inject_mobile_css()

st.title("Narrative Context Engine")
st.caption("Adds small human-context modifiers like former club games, debuts, retirement games, rivalry games, and big occasion matches.")

st.warning("Narrative factors are intentionally capped. They should never overpower core stats like try rate, role, minutes, team attack, opposition defence, weather, and injuries.")

tab1, tab2 = st.tabs(["Add Context", "Context Report"])

with tab1:
    with st.form("narrative_form", clear_on_submit=True):
        player = st.text_input("Player")
        team = st.text_input("Team")
        context_type = st.selectbox("Context type", list(NARRATIVE_BOOSTS.keys()))
        note = st.text_area("Narrative note")
        submitted = st.form_submit_button("Save narrative context")

    if submitted:
        append_table("narrative_context", pd.DataFrame([{
            "player": player,
            "team": team,
            "context_type": context_type,
            "narrative_note": note,
            "context_nrl_debut": "",
            "context_club_debut": "",
            "context_home_debut": "",
            "context_playing_former_club": "",
            "context_captain_first_game": "",
            "context_final_home_game": "",
            "context_retirement_game": "",
            "context_rivalry_game": "",
            "context_finals_intensity": "",
            "context_grand_final": "",
            "context_first_game_back_from_injury": "",
            "context_returning_from_suspension": "",
            "context_birthday_game": "",
        }]))
        st.success(f"Saved context for {player}.")

    current = read_table("narrative_context")
    if current.empty:
        st.info("No narrative context saved yet.")
    else:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited narrative context"):
            replace_table("narrative_context", edited)
            st.success("Narrative context saved.")

with tab2:
    players = read_table("player_stats")
    narrative = read_table("narrative_context")
    output = apply_narrative_context(players, narrative)

    if output.empty or "narrative_boost" not in output.columns:
        st.info("No context report available yet.")
    else:
        report = output[["player", "team", "narrative_boost", "narrative_flags", "narrative_note"]]
        report = report[pd.to_numeric(report["narrative_boost"], errors="coerce").fillna(0) != 0]
        st.dataframe(report, use_container_width=True)

    with st.expander("Boost guide"):
        for key, value in NARRATIVE_BOOSTS.items():
            st.write(f"{key}: {value:+}")
        st.caption("Total narrative boost is capped at +6 and floor -4.")
