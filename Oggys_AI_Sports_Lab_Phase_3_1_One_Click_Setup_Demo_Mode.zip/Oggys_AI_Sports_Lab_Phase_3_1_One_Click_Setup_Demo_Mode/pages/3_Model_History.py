import streamlit as st
from src.ui_helpers import inject_mobile_css
inject_mobile_css()
import pandas as pd
from src.database import read_table, replace_table

st.title("Model History & ROI")

history = read_table("model_history")

uploaded = st.file_uploader("Upload model_history.csv", type=["csv"])
if uploaded:
    df = pd.read_csv(uploaded)
    st.dataframe(df.head(25), use_container_width=True)
    if st.button("Save model history"):
        replace_table("model_history", df)
        st.success(f"Saved {len(df)} history rows.")
        history = df

if history.empty:
    st.info("No model history saved yet.")
else:
    if "profit_loss" in history.columns:
        history["profit_loss"] = pd.to_numeric(history["profit_loss"], errors="coerce").fillna(0)
        st.metric("Total Profit/Loss", round(history["profit_loss"].sum(), 2))
    if "result" in history.columns:
        wins = history["result"].astype(str).str.lower().eq("win").sum()
        st.metric("Wins", int(wins))
    st.dataframe(history, use_container_width=True)