import streamlit as st
from src.ui_helpers import inject_mobile_css
from src.database import read_table, replace_table
from src.milestone_engine import apply_milestone_modifier

st.set_page_config(page_title="Milestone Games", layout="wide")
inject_mobile_css()

st.title("Milestone Game Tracker")
st.caption("Flags players approaching 50, 100, 150, 200, 250, 300+ career games and applies a small prediction boost.")

st.info("Milestone logic uses career games BEFORE the match. Example: if a player is on 99 career games, this week is their 100th game.")

players = read_table("player_stats")

if players.empty:
    st.warning("No player_stats data found. Add players first.")
else:
    if "career_games" not in players.columns:
        players["career_games"] = 0

    st.subheader("Edit Career Games")
    edited = st.data_editor(
        players,
        use_container_width=True,
        num_rows="dynamic",
        column_config={
            "career_games": st.column_config.NumberColumn(
                "Career games before this match",
                min_value=0,
                step=1
            )
        }
    )

    if st.button("Save career games"):
        replace_table("player_stats", edited)
        st.success("Career games saved.")

    milestone_df = apply_milestone_modifier(edited)
    report = milestone_df[milestone_df["milestone_game"] > 0][[
        "player", "team", "career_games", "milestone_game",
        "milestone_boost", "milestone_flag", "milestone_note"
    ]]

    replace_table("milestone_report", report)

    st.subheader("Milestone Players This Week")
    if report.empty:
        st.info("No milestone players detected from current player_stats.")
    else:
        st.dataframe(report, use_container_width=True)

    with st.expander("Boost rules"):
        st.write("- 50th game: +2 model score")
        st.write("- 100th game: +3 model score")
        st.write("- 150th game: +3 model score")
        st.write("- 200th game: +4 model score")
        st.write("- 300th game: +5 model score")
        st.write("- 400th game: +6 model score")
        st.caption("This is a small emotional/team-lift modifier, not a major override.")
