import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import read_table, replace_table
from src.integrity_checker import build_player_integrity_report

st.set_page_config(page_title="Player Integrity Checker", layout="wide")
inject_mobile_css()

st.title("Player Integrity Checker")
st.caption("Find missing players, spelling mismatches, duplicates, missing odds, and players not selected this week.")

st.info("By default, the predictor should only show players who are in this week's team lists. If a player is not in the weekly games/team list, they should not appear in the weekly try-scorer predictions.")

player_stats = read_table("player_stats")
team_lists = read_table("team_lists")
odds = read_table("odds")
injuries = read_table("injuries")

if st.button("Run integrity check"):
    report = build_player_integrity_report(player_stats, team_lists, odds, injuries)
    replace_table("player_integrity_report", report)
    st.success(f"Integrity check complete. {len(report)} rows found.")

report = read_table("player_integrity_report")

if report.empty:
    st.warning("No integrity report yet. Click Run integrity check.")
else:
    severity_filter = st.multiselect(
        "Filter severity",
        sorted(report["severity"].dropna().unique().tolist()),
        default=sorted(report["severity"].dropna().unique().tolist())
    )
    area_filter = st.multiselect(
        "Filter area",
        sorted(report["area"].dropna().unique().tolist()),
        default=sorted(report["area"].dropna().unique().tolist())
    )

    filtered = report[
        report["severity"].isin(severity_filter) &
        report["area"].isin(area_filter)
    ]

    c1, c2, c3 = st.columns(3)
    c1.metric("High Issues", int((report["severity"] == "HIGH").sum()))
    c2.metric("Medium Issues", int((report["severity"] == "MEDIUM").sum()))
    c3.metric("Info Rows", int((report["severity"] == "INFO").sum()))

    st.dataframe(filtered, use_container_width=True)

    csv = filtered.to_csv(index=False).encode("utf-8")
    st.download_button("Download integrity report", csv, "player_integrity_report.csv", "text/csv")

with st.expander("How to read this"):
    st.write("""
    - **Missing Player** means someone is in the weekly team list but missing from player_stats.
    - **Not Selected This Week** means the player exists in the database but is not named for this round.
    - **Duplicate Player** means the same name appears more than once.
    - **Missing Odds** means the player can still be rated, but value betting cannot be calculated.
    - **Missing Injury Status** is optional, but useful for late changes.
    """)
