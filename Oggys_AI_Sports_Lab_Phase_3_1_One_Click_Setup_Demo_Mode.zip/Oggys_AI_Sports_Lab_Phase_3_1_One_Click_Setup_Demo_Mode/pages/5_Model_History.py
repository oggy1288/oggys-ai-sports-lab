
from pathlib import Path
import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
st.set_page_config(page_title="Model History", layout="wide")
inject_mobile_css()
st.title("Model History")
path = ROOT/'outputs/model_history.csv'
if not path.exists():
    st.info("No model history file yet. Add results after each round to begin tracking accuracy and ROI.")
    sample = pd.DataFrame({
        'round':[18], 'player':['Player A'], 'bet_recommendation':['Strong Bet'], 'odds':[2.2], 'stake_units':[1], 'result':['Win'], 'profit_units':[1.2]
    })
    st.dataframe(sample, use_container_width=True)
else:
    df = pd.read_csv(path)
    st.dataframe(df, use_container_width=True)
    if 'profit_units' in df:
        st.line_chart(df['profit_units'].cumsum())
