import streamlit as st
import pandas as pd

from src.warehouse_engine import (
    ensure_phase_1_5_tables,
    build_default_backfill_plan,
    read_warehouse_table,
    replace_warehouse_table,
    refresh_backfill_plan_from_warehouse,
    build_season_completeness_report,
    build_missing_data_report,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 1.5 Historical Backfill", layout="wide")
mobile_header("Phase 1.5 — Historical Season Backfill Tracker", "Track 2010–current data completeness season by season")

ensure_phase_1_5_tables()

tabs = st.tabs(["Backfill Plan", "Completeness", "Missing Data", "Season Checklist", "Guide"])

with tabs[0]:
    st.subheader("Season Backfill Plan")
    col1, col2 = st.columns(2)
    with col1:
        start = st.number_input("Start season", min_value=1998, max_value=2026, value=2010, step=1)
    with col2:
        end = st.number_input("End season", min_value=1998, max_value=2026, value=2026, step=1)

    if st.button("Create default backfill plan"):
        plan = build_default_backfill_plan(start, end)
        replace_warehouse_table("season_backfill_plan", plan)
        st.success("Default backfill plan created.")

    if st.button("Refresh plan from warehouse data"):
        plan = refresh_backfill_plan_from_warehouse()
        st.success("Backfill plan refreshed from warehouse.")
        st.dataframe(plan, use_container_width=True)

    plan = read_warehouse_table("season_backfill_plan")
    if plan.empty:
        st.info("Create a default backfill plan to begin.")
    else:
        edited = st.data_editor(plan, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited backfill plan"):
            replace_warehouse_table("season_backfill_plan", edited)
            st.success("Backfill plan saved.")

with tabs[1]:
    st.subheader("Season Completeness Report")
    if st.button("Build completeness report"):
        report = build_season_completeness_report()
        st.success("Completeness report built.")
        st.dataframe(report, use_container_width=True)

    report = read_warehouse_table("season_completeness_report")
    if not report.empty:
        st.dataframe(report, use_container_width=True)
        if "overall_completeness_pct" in report.columns:
            avg = pd.to_numeric(report["overall_completeness_pct"], errors="coerce").fillna(0).mean()
            st.metric("Average Completeness", f"{avg:.1f}%")

with tabs[2]:
    st.subheader("Missing Data Report")
    if st.button("Build missing data report"):
        missing = build_missing_data_report()
        st.success("Missing data report built.")
        st.dataframe(missing, use_container_width=True)

    missing = read_warehouse_table("missing_data_report")
    if not missing.empty:
        severity = st.selectbox("Severity filter", ["All"] + sorted(missing["severity"].dropna().unique().tolist()))
        shown = missing if severity == "All" else missing[missing["severity"] == severity]
        st.dataframe(shown, use_container_width=True)

with tabs[3]:
    st.subheader("Season Import Checklist")
    season = st.number_input("Season to review", min_value=1998, max_value=2026, value=2026, step=1)
    report = read_warehouse_table("season_completeness_report")
    row = report[pd.to_numeric(report["season"], errors="coerce").fillna(0).astype(int) == int(season)] if not report.empty and "season" in report.columns else pd.DataFrame()

    checklist = [
        "Import fixtures and results",
        "Import team lists",
        "Import player match stats",
        "Import try events",
        "Import weather history",
        "Import odds history",
        "Import injuries/suspensions/late mail",
        "Run relationship checks",
        "Create dataset version snapshot",
    ]
    if row.empty:
        st.info("Build the completeness report first.")
        for item in checklist:
            st.checkbox(item, value=False)
    else:
        r = row.iloc[0]
        st.write(f"Readiness: **{r.get('readiness', '')}**")
        for item in checklist:
            done = False
            if "fixtures" in item.lower():
                done = float(r.get("matches_pct", 0)) >= 90
            elif "team lists" in item.lower():
                done = float(r.get("team_lists_pct", 0)) >= 90
            elif "player match" in item.lower():
                done = float(r.get("player_stats_pct", 0)) >= 90
            elif "try events" in item.lower():
                done = float(r.get("try_events_pct", 0)) >= 90
            elif "weather" in item.lower():
                done = float(r.get("weather_pct", 0)) >= 80
            elif "odds" in item.lower():
                done = float(r.get("odds_pct", 0)) >= 50
            st.checkbox(item, value=done)

with tabs[4]:
    st.subheader("Guide")
    st.write("""
    Phase 1.5 helps you backfill historical seasons safely.

    Recommended order:
    1. Create the backfill plan.
    2. Import one season at a time.
    3. Start with fixtures/results, player stats and try events.
    4. Add weather and odds after the core season data is loaded.
    5. Run completeness and missing-data reports.
    6. Create a dataset version once the season is clean.

    Suggested first target:
    - 2023–2026 first
    - then expand backwards to 2020
    - then 2015
    - then 2010 and earlier if reliable data is available
    """)
