import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import read_table, replace_table
from src.name_matching import build_alias_table, resolve_names_against_master, generate_player_id

st.set_page_config(page_title="Player ID & Name Matching", layout="wide")
inject_mobile_css()

st.title("Player ID & Name Matching")
st.caption("Fixes missing-player problems caused by spelling differences, initials, short names, or duplicated names.")

st.info("This creates one stable player_id for each player, then links team lists, odds, Origin, injuries, and narrative context back to that ID.")

player_stats = read_table("player_stats")

if player_stats.empty:
    st.warning("No player_stats loaded yet.")
else:
    if "player_id" not in player_stats.columns:
        player_stats["player_id"] = player_stats.apply(lambda r: generate_player_id(r.get("player", ""), r.get("team", "")), axis=1)

    st.subheader("Master Player IDs")
    edited_players = st.data_editor(player_stats, use_container_width=True, num_rows="dynamic")

    if st.button("Save player IDs"):
        replace_table("player_stats", edited_players)
        st.success("Player IDs saved.")

    aliases = build_alias_table(edited_players)
    replace_table("player_aliases", aliases)

    st.subheader("Generated Alias Table")
    st.dataframe(aliases, use_container_width=True)

    st.subheader("Check Tables Against Master Player List")

    source_table = st.selectbox(
        "Choose table to check",
        ["team_lists", "odds", "injuries", "origin_players", "narrative_context"]
    )

    source_df = read_table(source_table)

    if source_df.empty:
        st.warning(f"No data in {source_table}.")
    else:
        report = resolve_names_against_master(source_df, aliases)

        if "match_type" in report.columns:
            report["action"] = report["match_type"].apply(
                lambda x: "OK" if x in ["Exact", "Initials", "Fuzzy"] else "Fix spelling or add alias"
            )

        display_cols = [c for c in [
            "player", "matched_player_id", "matched_player", "matched_team",
            "match_score", "match_type", "action"
        ] if c in report.columns]

        st.dataframe(report[display_cols], use_container_width=True)

        out_report = report.copy()
        out_report["source_table"] = source_table
        if "player" in out_report.columns:
            out_report = out_report.rename(columns={"player": "input_player"})

        save_cols = [c for c in [
            "source_table", "input_player", "matched_player_id", "matched_player",
            "matched_team", "match_score", "match_type", "action"
        ] if c in out_report.columns]

        if st.button("Save name match report"):
            replace_table("name_match_report", out_report[save_cols])
            st.success("Name match report saved.")

with st.expander("Why this matters"):
    st.write("""
    If the team list says `H. Farnworth` but player_stats says `Herbie Farnworth`, the old model may treat them as different people.
    This page creates aliases and match reports so the app can find the correct player instead of dropping them from predictions.
    """)
