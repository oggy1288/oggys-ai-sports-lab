import streamlit as st
import pandas as pd
from src.warehouse_engine import WAREHOUSE_SCHEMA, create_warehouse_tables, read_warehouse_table, replace_warehouse_table, warehouse_table_counts, build_empty_template, validate_warehouse_table
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 1 Historical Data Warehouse", layout="wide")
mobile_header("Phase 1 — Historical Data Warehouse", "The source of truth for Oggy's AI Sports Lab")
st.info("This is the foundation for every future AI engine. Start by creating tables, downloading templates, and importing clean historical data.")
create_warehouse_tables()
tabs = st.tabs(["Warehouse Status", "Table Builder", "Import Templates", "Data Quality", "Data Dictionary"])
with tabs[0]:
    st.subheader("Warehouse Status")
    counts = warehouse_table_counts()
    st.dataframe(counts, use_container_width=True)
    st.metric("Registered Warehouse Tables", len(WAREHOUSE_SCHEMA))
    st.metric("Total Rows Loaded", int(counts["rows"].sum()) if not counts.empty else 0)
with tabs[1]:
    st.subheader("View / Edit Warehouse Table")
    table = st.selectbox("Choose table", list(WAREHOUSE_SCHEMA.keys()))
    df = read_warehouse_table(table)
    if df.empty: df = build_empty_template(table)
    edited = st.data_editor(df, use_container_width=True, num_rows="dynamic")
    if st.button(f"Save {table}"):
        replace_warehouse_table(table, edited); st.success(f"{table} saved.")
with tabs[2]:
    st.subheader("Download Import Templates")
    table = st.selectbox("Template table", list(WAREHOUSE_SCHEMA.keys()), key="template_table")
    template = build_empty_template(table)
    st.dataframe(template, use_container_width=True)
    st.download_button(f"Download {table} template CSV", template.to_csv(index=False).encode("utf-8"), f"{table}_template.csv", "text/csv")
    st.subheader("Upload CSV Into Warehouse")
    upload_table = st.selectbox("Upload target table", list(WAREHOUSE_SCHEMA.keys()), key="upload_table")
    uploaded = st.file_uploader("Upload CSV", type=["csv"])
    if uploaded:
        raw = pd.read_csv(uploaded)
        st.write("Preview"); st.dataframe(raw.head(50), use_container_width=True)
        issues = validate_warehouse_table(upload_table, raw)
        st.write("Validation"); st.dataframe(issues, use_container_width=True)
        if st.button("Import CSV to warehouse"):
            replace_warehouse_table(upload_table, raw); st.success(f"Imported {len(raw)} rows into {upload_table}.")
with tabs[3]:
    st.subheader("Data Quality Checker")
    table = st.selectbox("Validate table", list(WAREHOUSE_SCHEMA.keys()), key="quality_table")
    df = read_warehouse_table(table)
    issues = validate_warehouse_table(table, df)
    st.dataframe(issues, use_container_width=True)
with tabs[4]:
    st.subheader("Master Data Dictionary")
    dictionary = pd.read_csv("data_dictionary/master_data_dictionary.csv")
    st.dataframe(dictionary, use_container_width=True)
    st.download_button("Download master data dictionary", dictionary.to_csv(index=False).encode("utf-8"), "master_data_dictionary.csv", "text/csv")
