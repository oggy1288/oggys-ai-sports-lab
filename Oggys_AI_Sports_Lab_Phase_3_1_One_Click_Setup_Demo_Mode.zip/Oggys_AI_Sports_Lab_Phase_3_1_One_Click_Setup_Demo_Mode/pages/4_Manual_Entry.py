import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import read_table, append_table, replace_table
from src.ui_helpers import mobile_header, tip

st.set_page_config(page_title="Manual Entry", layout="wide")
inject_mobile_css()
mobile_header("Manual Entry", "Add and edit NRL data from your phone")

entry_type = st.radio(
    "What do you want to add?",
    ["Player Stats", "Odds", "Injury / Team News", "Fixture", "Result / Model History"],
    horizontal=False,
)

if entry_type == "Player Stats":
    tip("Use this after team lists or when you want to add a player manually.")
    with st.form("player_form", clear_on_submit=True):
        player = st.text_input("Player name")
        team = st.text_input("Team")
        position = st.selectbox("Position", ["Fullback", "Winger", "Centre", "Five-Eighth", "Halfback", "Hooker", "Prop", "Second Row", "Lock", "Bench", "Other"])
        tries = st.number_input("Season tries", min_value=0, step=1)
        games = st.number_input("Games played", min_value=0, step=1)
        last5_tries = st.number_input("Last 5 tries", min_value=0, step=1)
        line_breaks = st.number_input("Line breaks", min_value=0, step=1)
        tackle_breaks = st.number_input("Tackle breaks", min_value=0, step=1)
        avg_minutes = st.number_input("Average minutes", min_value=0, max_value=100, value=80, step=1)
        role = st.selectbox("Goal-line role", ["High", "Medium", "Low"])
        career_games = st.number_input("Career games before this match", min_value=0, step=1)
        middle_try_role = st.selectbox("Middle try role", ["No Middle Role", "Crash Ball", "Short Ball Runner", "Dummy Half Sneak", "Bench Impact Middle", "Decoy / Low Usage"])
        opponent_middle_weakness = st.number_input("Opponent middle weakness 0-100", min_value=0, max_value=100, value=50, step=1)
        team_red_zone_middle_attack = st.number_input("Team red-zone middle attack 0-100", min_value=0, max_value=100, value=50, step=1)
        submitted = st.form_submit_button("Save player")
    if submitted:
        df = pd.DataFrame([{
            "player": player, "team": team, "position": position, "tries": tries,
            "games": games, "last5_tries": last5_tries, "line_breaks": line_breaks,
            "tackle_breaks": tackle_breaks, "avg_minutes": avg_minutes,
            "goal_line_role": role, "career_games": career_games,
                "middle_try_role": middle_try_role,
                "opponent_middle_weakness": opponent_middle_weakness,
                "team_red_zone_middle_attack": team_red_zone_middle_attack
        }])
        append_table("player_stats", df)
        st.success(f"Saved {player}.")

    current = read_table("player_stats")
    st.subheader("Current player stats")
    if not current.empty:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited player table"):
            replace_table("player_stats", edited)
            st.success("Player table updated.")
    else:
        st.info("No player stats saved yet.")

elif entry_type == "Odds":
    tip("Enter decimal odds. Example: $2.20 should be entered as 2.20.")
    with st.form("odds_form", clear_on_submit=True):
        player = st.text_input("Player name")
        market = st.selectbox("Market", ["Anytime Try", "First Try", "Two Tries", "Other"])
        bookmaker = st.text_input("Bookmaker", value="Sportsbet")
        odds = st.number_input("Odds", min_value=1.01, value=2.00, step=0.01)
        submitted = st.form_submit_button("Save odds")
    if submitted:
        append_table("odds", pd.DataFrame([{
            "player": player, "market": market, "bookmaker": bookmaker, "odds": odds
        }]))
        st.success(f"Saved odds for {player}.")

    current = read_table("odds")
    st.subheader("Current odds")
    if not current.empty:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited odds"):
            replace_table("odds", edited)
            st.success("Odds table updated.")

elif entry_type == "Injury / Team News":
    with st.form("injury_form", clear_on_submit=True):
        player = st.text_input("Player name")
        status = st.selectbox("Status", ["Healthy", "Questionable", "Returning", "Limited Minutes", "Out", "Suspended"])
        impact = st.text_area("Notes / impact")
        minutes_adjustment = st.number_input("Minutes / score adjustment", value=0.0, step=1.0)
        submitted = st.form_submit_button("Save injury/news")
    if submitted:
        append_table("injuries", pd.DataFrame([{
            "player": player, "status": status, "impact": impact, "minutes_adjustment": minutes_adjustment
        }]))
        st.success(f"Saved team news for {player}.")

    current = read_table("injuries")
    st.subheader("Current injuries/team news")
    if not current.empty:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited injuries"):
            replace_table("injuries", edited)
            st.success("Injuries table updated.")

elif entry_type == "Fixture":
    with st.form("fixture_form", clear_on_submit=True):
        fixture_id = st.text_input("Fixture ID")
        round_no = st.text_input("Round")
        date = st.date_input("Date")
        home_team = st.text_input("Home team")
        away_team = st.text_input("Away team")
        venue = st.text_input("Venue")
        submitted = st.form_submit_button("Save fixture")
    if submitted:
        append_table("fixtures", pd.DataFrame([{
            "fixture_id": fixture_id, "round": round_no, "date": str(date),
            "home_team": home_team, "away_team": away_team, "venue": venue
        }]))
        st.success("Fixture saved.")

    current = read_table("fixtures")
    st.subheader("Current fixtures")
    if not current.empty:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited fixtures"):
            replace_table("fixtures", edited)
            st.success("Fixtures updated.")

else:
    tip("Use this after matches finish to track whether the model was right.")
    with st.form("history_form", clear_on_submit=True):
        round_no = st.text_input("Round")
        date = st.date_input("Date")
        player = st.text_input("Player")
        team = st.text_input("Team")
        market = st.selectbox("Market", ["Anytime Try", "First Try", "Match Winner", "Other"])
        model_score = st.number_input("Model score", min_value=0.0, max_value=100.0, step=1.0)
        bookmaker_odds = st.number_input("Bookmaker odds", min_value=1.01, value=2.00, step=0.01)
        stake = st.number_input("Stake", min_value=0.0, value=1.0, step=0.5)
        result = st.selectbox("Result", ["Win", "Loss", "Push", "Pending"])
        profit_loss = st.number_input("Profit / Loss", value=0.0, step=0.5)
        submitted = st.form_submit_button("Save result")
    if submitted:
        append_table("model_history", pd.DataFrame([{
            "round": round_no, "date": str(date), "player": player, "team": team,
            "market": market, "model_score": model_score, "bookmaker_odds": bookmaker_odds,
            "stake": stake, "result": result, "profit_loss": profit_loss
        }]))
        st.success("Result saved.")

    current = read_table("model_history")
    st.subheader("Current model history")
    if not current.empty:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited history"):
            replace_table("model_history", edited)
            st.success("Model history updated.")
