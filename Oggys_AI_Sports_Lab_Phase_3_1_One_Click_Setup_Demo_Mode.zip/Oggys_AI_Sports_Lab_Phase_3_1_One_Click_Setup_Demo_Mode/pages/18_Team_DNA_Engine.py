import streamlit as st
import pandas as pd

from src.database import read_table, replace_table
from src.team_dna_engine import (
    build_team_dna,
    build_team_concede_dna,
    build_channel_matchups,
    apply_team_dna_boost,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Team DNA Engine", layout="wide")
mobile_header("V8.2 Team DNA Engine", "Where teams score, where opponents concede, and which channels create the best matchup")

st.info("This identifies if a team's strongest attack channel lines up with the opponent's weakest defensive channel.")

tabs = st.tabs(["Team Attack DNA", "Defence DNA", "Channel Matchups", "Prediction Boosts", "How It Works"])

try_history = read_table("player_try_history")
fixtures = read_table("fixtures")

attack_dna = build_team_dna(try_history)
concede_dna = build_team_concede_dna(try_history)
matchups = build_channel_matchups(fixtures, attack_dna, concede_dna)

replace_table("team_dna_profile", attack_dna)
replace_table("team_concede_dna_profile", concede_dna)
replace_table("channel_matchups", matchups)

with tabs[0]:
    st.subheader("Team Attack DNA")
    if attack_dna.empty:
        st.warning("No player_try_history loaded yet.")
    else:
        st.dataframe(attack_dna, use_container_width=True)

with tabs[1]:
    st.subheader("Team Defence DNA")
    if concede_dna.empty:
        st.warning("No conceded DNA available yet.")
    else:
        st.dataframe(concede_dna, use_container_width=True)

with tabs[2]:
    st.subheader("Channel Matchups")
    if matchups.empty:
        st.warning("Add fixtures and player_try_history first.")
    else:
        fixture_filter = st.selectbox("Fixture", ["All"] + sorted(matchups["fixture_id"].dropna().unique().tolist()))
        shown = matchups if fixture_filter == "All" else matchups[matchups["fixture_id"] == fixture_filter]
        st.dataframe(shown, use_container_width=True)

with tabs[3]:
    st.subheader("Predictions With Team DNA Boosts")
    predictions = read_table("predictions")
    boosted = apply_team_dna_boost(predictions, matchups)

    if boosted.empty:
        st.warning("No predictions available yet.")
    else:
        display_cols = [c for c in [
            "player", "team", "position", "model_score", "team_dna_channel",
            "team_dna_boost", "team_dna_verdict", "team_dna_summary",
            "last5_sequence", "vs_opponent_sequence", "fair_odds"
        ] if c in boosted.columns]
        st.dataframe(boosted[display_cols], use_container_width=True)

        if st.button("Save Team DNA boosted predictions"):
            replace_table("predictions", boosted)
            st.success("Boosted predictions saved.")

with tabs[4]:
    st.subheader("How Team DNA Works")
    st.write("""
    Team DNA looks at every historical try and classifies it into:
    - Left Edge
    - Middle
    - Right Edge
    - Kick / Other

    Then it compares:
    - where the attacking team scores most
    - where the opponent concedes most

    If those two match, the player receives a small model boost.
    """)
