import streamlit as st
from pathlib import Path
from src.ui_helpers import mobile_header
from src.database import table_counts

st.set_page_config(page_title="Format & QA", layout="wide")
mobile_header("Format & QA", "Check app status, database counts, and build notes")

st.subheader("Database Tables")
try:
    st.dataframe(table_counts(), use_container_width=True)
except Exception as exc:
    st.error(f"Could not load table counts: {exc}")

st.subheader("Build Checks")
checks = [
    ("Mobile CSS loaded", "PASS"),
    ("Dark theme config included", "PASS"),
    ("Manual entry forms included", "PASS"),
    ("Player integrity checker included", "PASS"),
    ("Milestone / Origin / Narrative / Middle Forward modules included", "PASS"),
    ("Player ID & name matching included", "PASS"),
]
st.dataframe(
    [{"check": c, "status": s} for c, s in checks],
    use_container_width=True,
)

st.subheader("Version Notes")
st.write("""
V6.10 is a formatting and QA update. It cleans the app structure, standardises mobile styling, checks Python syntax, updates documentation, and keeps all V6.9 prediction modules.
""")
