import streamlit as st
import pandas as pd

from src.database import read_table, replace_table
from src.try_markets_engine import (
    build_try_market_predictions,
    build_top_market_board,
    build_player_market_card,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Try Markets Engine", layout="wide")
mobile_header("V8.1 Try Markets Engine", "Anytime, First Try, 2+ Tries and 3+ Tries")

st.info("This converts player predictions and historical try timing into separate market probabilities and fair odds.")

predictions = read_table("predictions")
timing_seed = read_table("try_market_seed_report")
best_odds = read_table("best_odds")

market_predictions = build_try_market_predictions(predictions, timing_seed, best_odds)
replace_table("try_market_predictions", market_predictions)

top_board = build_top_market_board(market_predictions)
replace_table("top_try_market_board", top_board)

tabs = st.tabs(["Top Markets", "Player Card", "Market Table", "How It Works"])

with tabs[0]:
    st.subheader("Top Try Market Predictions")

    if top_board.empty:
        st.warning("Run predictions and Historical Try Intelligence first.")
    else:
        market = st.selectbox("Market", ["All"] + sorted(top_board["market"].dropna().unique().tolist()))
        shown = top_board if market == "All" else top_board[top_board["market"] == market]

        display_cols = [c for c in [
            "rank", "player", "team", "position", "market", "probability",
            "fair_odds", "best_odds", "best_bookmaker", "edge_pct", "ev_pct", "market_flag"
        ] if c in shown.columns]

        st.dataframe(shown[display_cols], use_container_width=True)

with tabs[1]:
    st.subheader("Player Try Markets Card")

    if market_predictions.empty:
        st.warning("No market predictions yet.")
    else:
        player = st.selectbox("Choose player", sorted(market_predictions["player"].dropna().unique().tolist()))
        card = build_player_market_card(market_predictions, player)

        if not card.empty:
            st.markdown(f"### {player}")
            first = card.iloc[0]
            st.caption(f"{first.get('team', '')} — {first.get('position', '')}")
            st.write(f"Last 5: **{first.get('last5_sequence', '')}**")
            st.write(f"Vs Opponent: **{first.get('vs_opponent_sequence', '')}**")
            st.write(f"Avg Try Minute: **{first.get('avg_try_minute', '')}**")
            st.write(f"Avg First Try Minute: **{first.get('avg_first_try_minute', '')}**")
            st.write(f"Timing: **{first.get('timing_label', '')}**")
            st.caption(first.get("timing_profile", ""))

            for _, row in card.iterrows():
                st.markdown(
                    f"""
                    <div class="nrl-card">
                    <b>{row.get('market', '')}</b><br>
                    Probability: <b>{float(row.get('probability', 0))*100:.1f}%</b><br>
                    Fair Odds: <b>{row.get('fair_odds', '')}</b><br>
                    Best Odds: <b>{row.get('best_odds', '')}</b> — {row.get('best_bookmaker', '')}<br>
                    Edge: <b>{float(row.get('edge_pct', 0))*100:.1f}%</b><br>
                    <b>{row.get('market_flag', '')}</b>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

with tabs[2]:
    st.subheader("Full Try Market Prediction Table")

    if market_predictions.empty:
        st.warning("No try market predictions yet.")
    else:
        market_filter = st.multiselect(
            "Markets",
            sorted(market_predictions["market"].dropna().unique().tolist()),
            default=sorted(market_predictions["market"].dropna().unique().tolist())
        )
        shown = market_predictions[market_predictions["market"].isin(market_filter)] if market_filter else market_predictions
        st.dataframe(shown, use_container_width=True)

        st.download_button(
            "Download try market predictions",
            shown.to_csv(index=False).encode("utf-8"),
            "try_market_predictions.csv",
            "text/csv",
        )

with tabs[3]:
    st.subheader("How the Try Markets Engine Works")
    st.write("""
    The engine builds separate probabilities for:
    - Anytime Try
    - First Try
    - 2+ Tries
    - 3+ Tries

    It uses:
    - existing model probability
    - historical first try rate
    - early scoring timing
    - team early scoring timing
    - opponent early concession timing
    - multi-try history
    - best bookmaker odds when available
    """)
