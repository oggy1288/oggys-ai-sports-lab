
from pathlib import Path
import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
st.set_page_config(page_title="Data Quality", layout="wide")
inject_mobile_css()
st.title("Data Quality Checks")
path = ROOT/'outputs/data_quality.csv'
if not path.exists():
    st.info("Run the predictor engine from the main dashboard first.")
else:
    df = pd.read_csv(path)
    st.dataframe(df, use_container_width=True)
    if 'status' in df:
        st.bar_chart(df['status'].value_counts())
