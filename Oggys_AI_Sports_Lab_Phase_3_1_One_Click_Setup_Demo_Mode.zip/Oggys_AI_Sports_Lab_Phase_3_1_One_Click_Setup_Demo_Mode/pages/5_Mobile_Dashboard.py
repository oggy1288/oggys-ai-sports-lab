import streamlit as st
import pandas as pd
from src.database import read_table
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Mobile Dashboard", layout="wide")
mobile_header("NRL Predictor Pro", "Phone-friendly betting dashboard")

predictions = read_table("predictions")
history = read_table("model_history")

if predictions.empty:
    st.warning("No predictions yet. Add player stats and odds, then run the predictor.")
else:
    predictions["model_score"] = pd.to_numeric(predictions["model_score"], errors="coerce").fillna(0)
    top = predictions.sort_values("model_score", ascending=False).head(10)

    st.subheader("🔥 Top Try Scorer Picks")
    for _, row in top.iterrows():
        score = float(row.get("model_score", 0))
        edge = float(row.get("edge_pct", 0)) * 100
        st.markdown(
            f"""
            <div style="padding:14px; border-radius:16px; border:1px solid #ddd; margin-bottom:10px;">
                <b style="font-size:18px;">{row.get('player','')}</b><br>
                {row.get('team','')} — {row.get('position','')}<br>
                Milestone: <b>{row.get("milestone_flag","")}</b><br>
                Origin: <b>{row.get("origin_status","")}</b> {row.get("origin_boost","")}<br>
                Narrative: <b>{row.get("narrative_flags","")}</b> {row.get("narrative_boost","")}<br>
                Middle: <b>{row.get("middle_forward_flag","")}</b> {row.get("middle_forward_boost","")}<br>
                Last 5: <b>{row.get("last5_sequence","")}</b> | Vs Opp: <b>{row.get("vs_opponent_sequence","")}</b><br>
                Score: <b>{score:.1f}</b> | Fair Odds: <b>{row.get('fair_odds','')}</b> | Bookie: <b>{row.get('bookmaker_odds','')}</b><br>
                Edge: <b>{edge:.1f}%</b> | Call: <b>{row.get('bet_recommendation','')}</b>
            </div>
            """,
            unsafe_allow_html=True,
        )

    st.subheader("💰 Best Value Bets")
    value = predictions[pd.to_numeric(predictions.get("edge_pct", 0), errors="coerce").fillna(0) > 0]
    if value.empty:
        st.info("No positive edge bets found.")
    else:
        st.dataframe(value.sort_values("edge_pct", ascending=False).head(20), use_container_width=True)

st.subheader("📈 Model History")
if history.empty:
    st.info("No model history saved yet.")
else:
    if "profit_loss" in history.columns:
        history["profit_loss"] = pd.to_numeric(history["profit_loss"], errors="coerce").fillna(0)
        st.metric("Profit / Loss", round(history["profit_loss"].sum(), 2))
    st.dataframe(history.tail(20), use_container_width=True)

st.caption("Tap into the Why AI Likes This page for detailed reasoning behind each prediction.")


st.caption("Open Try Markets Engine for First Try, 2+ Tries and 3+ Tries predictions.")
