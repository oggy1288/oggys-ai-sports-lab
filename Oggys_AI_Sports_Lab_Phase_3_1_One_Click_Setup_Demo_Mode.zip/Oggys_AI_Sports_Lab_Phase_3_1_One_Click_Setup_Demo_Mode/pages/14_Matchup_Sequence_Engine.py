import streamlit as st
import pandas as pd

from src.database import read_table, replace_table
from src.sequence_engine import (
    build_player_sequence_report,
    build_team_sequence_report,
    build_opponent_matchup_sequence,
    merge_sequence_into_predictions,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Matchup Sequence Engine", layout="wide")
mobile_header("V7.2 Matchup Sequence Engine", "Quick visual try-scoring form using 2️⃣ 0️⃣ 2️⃣ 0️⃣ 2️⃣ sequences")

st.info("This gives you a fast way to see player form, team form, and player record against the opponent using the same visual sequence style.")

tabs = st.tabs([
    "Player Last 5",
    "Team Last 5",
    "Vs Opponent",
    "Prediction View",
    "Data Entry",
])

with tabs[0]:
    st.subheader("Player Last 5 Try Sequence")
    player_history = read_table("player_game_history")
    report = build_player_sequence_report(player_history)
    replace_table("player_sequence_report", report)

    if report.empty:
        st.warning("No player_game_history data loaded yet.")
    else:
        st.dataframe(report, use_container_width=True)

with tabs[1]:
    st.subheader("Team Last 5 Try Sequence")
    st.caption("Shows how many tries the team scored and conceded in each of its last five games.")
    team_history = read_table("team_game_history")
    report = build_team_sequence_report(team_history)
    replace_table("team_sequence_report", report)

    if report.empty:
        st.warning("No team_game_history data loaded yet.")
    else:
        st.dataframe(report, use_container_width=True)

with tabs[2]:
    st.subheader("Player vs This Opponent Sequence")
    st.caption("This is the fast way to see if a player is a strong try scorer against the team they are facing.")
    h2h = read_table("player_vs_opponent_history")
    report = build_opponent_matchup_sequence(h2h)
    replace_table("opponent_sequence_report", report)

    if report.empty:
        st.warning("No player_vs_opponent_history data loaded yet.")
    else:
        st.dataframe(report, use_container_width=True)

with tabs[3]:
    st.subheader("Predictions With Sequence Intelligence")
    predictions = read_table("predictions")
    player_seq = read_table("player_sequence_report")
    opp_seq = read_table("opponent_sequence_report")

    combined = merge_sequence_into_predictions(predictions, player_seq, opp_seq)

    if combined.empty:
        st.warning("Run predictions and sequence reports first.")
    else:
        display_cols = [c for c in [
            "player", "team", "position", "model_score",
            "last5_sequence", "last5_avg", "last5_rating",
            "opponent", "vs_opponent_sequence", "vs_opponent_avg", "vs_opponent_rating",
            "fair_odds", "best_odds", "bookmaker_odds", "bet_recommendation"
        ] if c in combined.columns]

        st.dataframe(combined[display_cols], use_container_width=True)
        replace_table("predictions", combined)

with tabs[4]:
    st.subheader("Data Entry")
    data_type = st.radio("Choose table", [
        "player_game_history",
        "team_game_history",
        "player_vs_opponent_history",
    ])

    current = read_table(data_type)
    if current.empty:
        if data_type == "team_game_history":
            current = pd.DataFrame(columns=[
                "team", "opponent", "round", "date", "tries_scored", "tries_conceded", "result"
            ])
        else:
            current = pd.DataFrame(columns=[
                "player", "team", "opponent", "round", "date", "result", "tries"
            ])

    edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
    if st.button(f"Save {data_type}"):
        replace_table(data_type, edited)
        st.success(f"{data_type} saved.")
