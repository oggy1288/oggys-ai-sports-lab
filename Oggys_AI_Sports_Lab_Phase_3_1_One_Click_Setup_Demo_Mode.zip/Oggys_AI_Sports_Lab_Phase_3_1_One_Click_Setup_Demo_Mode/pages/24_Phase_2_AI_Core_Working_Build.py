import streamlit as st
import pandas as pd

from src.warehouse_engine import read_warehouse_table, replace_warehouse_table, WAREHOUSE_SCHEMA, create_warehouse_tables
from src.phase2_feature_engine import build_master_feature_table, player_opponent_features, team_form_features
from src.phase2_player_dna_engine import build_player_dna
from src.phase2_team_dna_2_engine import build_team_dna_2
from src.phase2_matchup_engine import build_matchup_intelligence
from src.phase2_simulation_engine import simulate_matches, simulate_try_markets
from src.phase2_ensemble_learning_engine import build_ensemble_predictions, grade_predictions, learning_summary
from src.phase2_realtime_engine import build_change_event, apply_realtime_events
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 2 AI Core", layout="wide")
mobile_header("Phase 2 — AI Core Working Build", "Features, Player DNA, Team DNA 2.0, Matchups, Simulation, Ensemble and Real-Time Intelligence")

create_warehouse_tables()

tabs = st.tabs([
    "Run Pipeline",
    "Feature Library",
    "Player DNA",
    "Team DNA 2.0",
    "Matchups",
    "Simulation",
    "Ensemble",
    "Real-Time",
    "Learning",
])

matches = read_warehouse_table("matches")
player_stats = read_warehouse_table("player_match_stats")
try_events = read_warehouse_table("try_events")

with tabs[0]:
    st.subheader("Run Full Phase 2 Pipeline")
    sims = st.number_input("Simulation runs per match", min_value=100, max_value=100000, value=2500, step=100)

    if st.button("Run Phase 2 AI pipeline"):
        features = build_master_feature_table(player_stats, try_events, matches)
        opp = player_opponent_features(try_events)
        p_dna = build_player_dna(features, opp)
        t_dna = build_team_dna_2(matches, try_events, player_stats)
        matchup = build_matchup_intelligence(matches, t_dna, p_dna)
        sim = simulate_matches(matchup, sims=int(sims))
        try_markets = simulate_try_markets(p_dna, t_dna)
        ensemble = build_ensemble_predictions(matchup, sim)

        replace_warehouse_table("phase2_master_features", features)
        replace_warehouse_table("phase2_player_dna", p_dna)
        replace_warehouse_table("phase2_team_dna_2", t_dna)
        replace_warehouse_table("phase2_matchup_intelligence", matchup)
        replace_warehouse_table("phase2_match_simulation", sim)
        replace_warehouse_table("phase2_try_market_simulation", try_markets)
        replace_warehouse_table("phase2_ensemble_predictions", ensemble)

        st.success("Phase 2 AI pipeline complete.")
        st.write("Ensemble predictions")
        st.dataframe(ensemble, use_container_width=True)

    st.info("Tip: load matches, player_match_stats and try_events first using Phase 1 adapters.")

with tabs[1]:
    st.subheader("Master Feature Library")
    df = read_warehouse_table("phase2_master_features")
    if df.empty:
        df = build_master_feature_table(player_stats, try_events, matches)
    st.dataframe(df, use_container_width=True)

with tabs[2]:
    st.subheader("Player DNA")
    df = read_warehouse_table("phase2_player_dna")
    if df.empty:
        df = build_player_dna(build_master_feature_table(player_stats, try_events, matches))
    st.dataframe(df, use_container_width=True)

with tabs[3]:
    st.subheader("Team DNA 2.0")
    df = read_warehouse_table("phase2_team_dna_2")
    if df.empty:
        df = build_team_dna_2(matches, try_events, player_stats)
    st.dataframe(df, use_container_width=True)

with tabs[4]:
    st.subheader("Match-up Intelligence")
    df = read_warehouse_table("phase2_matchup_intelligence")
    if df.empty:
        df = build_matchup_intelligence(matches, build_team_dna_2(matches, try_events, player_stats), build_player_dna(build_master_feature_table(player_stats, try_events, matches)))
    st.dataframe(df, use_container_width=True)

with tabs[5]:
    st.subheader("AI Match Simulation")
    df = read_warehouse_table("phase2_match_simulation")
    st.dataframe(df, use_container_width=True)
    st.subheader("Try Market Simulation")
    tm = read_warehouse_table("phase2_try_market_simulation")
    st.dataframe(tm, use_container_width=True)

with tabs[6]:
    st.subheader("Ensemble AI")
    df = read_warehouse_table("phase2_ensemble_predictions")
    st.dataframe(df, use_container_width=True)

with tabs[7]:
    st.subheader("Real-Time Intelligence")
    current = read_warehouse_table("phase2_realtime_events")
    if current.empty:
        current = pd.DataFrame(columns=["event_time","event_type","team","player","impact","notes"])

    with st.form("event_form"):
        event_type = st.selectbox("Event type", ["Team List Change", "Injury", "Weather", "Origin", "Odds Move", "Late Mail"])
        team = st.text_input("Team")
        player = st.text_input("Player")
        impact = st.number_input("Probability impact", min_value=-0.30, max_value=0.30, value=0.0, step=0.01)
        notes = st.text_area("Notes")
        submitted = st.form_submit_button("Add event")

    if submitted:
        new = pd.DataFrame([build_change_event(event_type, team, player, impact, notes)])
        current = pd.concat([current, new], ignore_index=True)
        replace_warehouse_table("phase2_realtime_events", current)
        st.success("Event added.")

    st.dataframe(current, use_container_width=True)
    ensemble = read_warehouse_table("phase2_ensemble_predictions")
    live = apply_realtime_events(ensemble, current)
    if live is not None and not live.empty:
        st.subheader("Live Adjusted Predictions")
        st.dataframe(live, use_container_width=True)

with tabs[8]:
    st.subheader("Self-Learning / Accuracy")
    ensemble = read_warehouse_table("phase2_ensemble_predictions")
    graded = grade_predictions(ensemble, matches)
    summary = learning_summary(graded)
    replace_warehouse_table("phase2_learning_summary", summary)
    st.write("Graded predictions")
    st.dataframe(graded, use_container_width=True)
    st.write("Learning summary")
    st.dataframe(summary, use_container_width=True)
