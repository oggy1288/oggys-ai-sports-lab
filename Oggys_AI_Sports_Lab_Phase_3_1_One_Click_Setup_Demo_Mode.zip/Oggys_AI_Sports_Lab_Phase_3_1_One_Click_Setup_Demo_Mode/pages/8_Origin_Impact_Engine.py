import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import read_table, replace_table, append_table
from src.origin_engine import build_team_origin_adjustments

st.set_page_config(page_title="Origin Impact Engine", layout="wide")
inject_mobile_css()

st.title("Origin Impact Engine")
st.caption("Adjusts player and team ratings when Origin selection changes team strength, combinations, fatigue, and opportunity.")

tab1, tab2, tab3 = st.tabs(["Player Origin Status", "Team Origin Impact", "Impact Report"])

with tab1:
    st.subheader("Player Origin Status")

    with st.form("origin_player_form", clear_on_submit=True):
        player = st.text_input("Player")
        team = st.text_input("NRL Team")
        status = st.selectbox(
            "Origin Status",
            [
                "Selected",
                "Backup",
                "Unlucky Miss",
                "Rested",
                "Backing Up",
                "Backing Up Heavy Minutes",
                "Not In Origin Frame",
            ],
        )
        minutes = st.number_input("Origin minutes played", min_value=0, max_value=100, value=0, step=1)
        note = st.text_area("Origin note")
        submitted = st.form_submit_button("Save player Origin status")

    if submitted:
        append_table("origin_players", pd.DataFrame([{
            "player": player,
            "team": team,
            "origin_status": status,
            "origin_minutes": minutes,
            "origin_note": note,
        }]))
        st.success(f"Saved Origin status for {player}.")

    current = read_table("origin_players")
    if current.empty:
        st.info("No Origin player statuses saved yet.")
    else:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited Origin player table"):
            replace_table("origin_players", edited)
            st.success("Origin player table saved.")

with tab2:
    st.subheader("Team Origin Impact")

    st.info("This captures your point: teams play differently when Origin players are out, especially spine players, middles, and edge defenders.")

    with st.form("origin_team_form", clear_on_submit=True):
        team = st.text_input("Team")
        team_status = st.selectbox(
            "Team Origin Status",
            [
                "No Major Impact",
                "Key Spine Out",
                "Key Middle Out",
                "Key Edge Out",
                "Multiple Stars Out",
                "Origin Stars Backing Up",
                "Origin Players Available",
            ],
        )
        note = st.text_area("Team note")
        submitted_team = st.form_submit_button("Save team Origin impact")

    if submitted_team:
        append_table("origin_team_impact", pd.DataFrame([{
            "team": team,
            "origin_team_status": team_status,
            "origin_team_note": note,
        }]))
        st.success(f"Saved Origin team impact for {team}.")

    team_df = read_table("origin_team_impact")
    if team_df.empty:
        st.info("No team Origin impacts saved yet.")
    else:
        edited_team = st.data_editor(team_df, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited team impact table"):
            replace_table("origin_team_impact", edited_team)
            st.success("Team Origin impact table saved.")

with tab3:
    st.subheader("Generated Origin Team Adjustments")

    team_df = read_table("origin_team_impact")
    adjustments = build_team_origin_adjustments(team_df)
    replace_table("origin_team_adjustments", adjustments)

    if adjustments.empty:
        st.info("No adjustments generated yet.")
    else:
        st.dataframe(adjustments, use_container_width=True)

    with st.expander("Adjustment guide"):
        st.write("- Key Spine Out: attack -8, defence -3")
        st.write("- Key Middle Out: attack -3, defence -6")
        st.write("- Key Edge Out: attack -4, defence -5")
        st.write("- Multiple Stars Out: attack -10, defence -8")
        st.write("- Origin Stars Backing Up: attack -2, defence -3")
        st.write("- Origin Players Available: attack +2, defence +2")
