import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
from src.database import read_table, replace_table, append_table
from src.middle_forward_engine import apply_middle_forward_modifier

st.set_page_config(page_title="Middle Forward Try Engine", layout="wide")
inject_mobile_css()

st.title("Middle Forward Try Engine")
st.caption("Adds a proper pathway for props, locks, hookers, second-rowers, and bench middles to rate as try-scorer chances.")

st.info("This handles your observation: in many matches, one or more forwards score through the middle from crash balls, short balls, dummy-half sneaks, or tired ruck defence.")

tab1, tab2 = st.tabs(["Add Middle Context", "Middle Forward Report"])

with tab1:
    with st.form("middle_context_form", clear_on_submit=True):
        player = st.text_input("Player")
        team = st.text_input("Team")
        role = st.selectbox("Middle try role", [
            "No Middle Role",
            "Crash Ball",
            "Short Ball Runner",
            "Dummy Half Sneak",
            "Bench Impact Middle",
            "Decoy / Low Usage",
        ])
        opponent = st.text_input("Opponent")
        opp_weakness = st.slider("Opponent middle weakness", 0, 100, 50)
        team_middle_attack = st.slider("Team red-zone middle attack", 0, 100, 50)
        weather = st.selectbox("Weather impact", ["", "Dry", "Wet", "Heavy Rain", "Windy"])
        note = st.text_area("Middle try note")
        submitted = st.form_submit_button("Save middle context")

    if submitted:
        append_table("middle_forward_context", pd.DataFrame([{
            "player": player,
            "team": team,
            "middle_try_role": role,
            "opponent": opponent,
            "opponent_middle_weakness": opp_weakness,
            "team_red_zone_middle_attack": team_middle_attack,
            "weather_impact": weather,
            "middle_note": note,
        }]))
        st.success(f"Saved middle context for {player or team}.")

    current = read_table("middle_forward_context")
    if current.empty:
        st.info("No middle context saved yet.")
    else:
        edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
        if st.button("Save edited middle context"):
            replace_table("middle_forward_context", edited)
            st.success("Middle context saved.")

with tab2:
    players = read_table("player_stats")
    context = read_table("middle_forward_context")
    output = apply_middle_forward_modifier(players, context)

    if output.empty:
        st.warning("No player stats loaded.")
    else:
        cols = [c for c in [
            "player", "team", "position", "middle_try_role",
            "opponent_middle_weakness", "team_red_zone_middle_attack",
            "middle_forward_boost", "middle_forward_flag", "middle_forward_note"
        ] if c in output.columns]
        report = output[cols].copy()
        if "middle_forward_boost" in report.columns:
            report = report[pd.to_numeric(report["middle_forward_boost"], errors="coerce").fillna(0) > 0]
            report = report.sort_values("middle_forward_boost", ascending=False)

        st.subheader("Forward Try Scorer Watchlist")
        if report.empty:
            st.info("No middle-forward boosts detected yet.")
        else:
            st.dataframe(report, use_container_width=True)

    with st.expander("How this affects predictions"):
        st.write("- Crash ball runner: strong boost")
        st.write("- Short-ball runner near the line: strong boost")
        st.write("- Hooker/dummy-half sneak: strong boost")
        st.write("- Bench impact middle against tired defence: medium boost")
        st.write("- Weak opponent middle defence increases the boost")
        st.write("- Wet weather gives middles a small extra boost")
        st.caption("Boost is capped so forwards are recognised without overpowering elite outside backs.")
