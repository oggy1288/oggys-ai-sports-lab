
from pathlib import Path
import streamlit as st
from src.ui_helpers import inject_mobile_css
import pandas as pd
import plotly.express as px

ROOT = Path(__file__).resolve().parents[1]
st.set_page_config(page_title="Predictions", layout="wide")
inject_mobile_css()
st.title("Player Predictions")
path = ROOT/'outputs/predictions.csv'
if not path.exists():
    st.info("Run the predictor engine from the main dashboard first.")
else:
    df = pd.read_csv(path)
    recs = ['All'] + sorted(df['bet_recommendation'].dropna().unique().tolist()) if 'bet_recommendation' in df else ['All']
    teams = ['All'] + sorted(df['team'].dropna().unique().tolist()) if 'team' in df else ['All']
    c1,c2 = st.columns(2)
    rec = c1.selectbox('Bet Recommendation', recs)
    team = c2.selectbox('Team', teams)
    view = df.copy()
    if rec != 'All': view = view[view['bet_recommendation'] == rec]
    if team != 'All': view = view[view['team'] == team]
    st.dataframe(view, use_container_width=True)
    if not view.empty:
        fig = px.scatter(view, x='fair_odds', y='bookmaker_odds', size='model_score', color='bet_recommendation', hover_name='player')
        st.plotly_chart(fig, use_container_width=True)
