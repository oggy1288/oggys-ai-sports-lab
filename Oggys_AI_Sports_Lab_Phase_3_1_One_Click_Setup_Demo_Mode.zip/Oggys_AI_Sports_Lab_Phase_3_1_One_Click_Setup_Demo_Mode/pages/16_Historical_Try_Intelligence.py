import streamlit as st
import pandas as pd

from src.database import read_table, replace_table
from src.try_history_engine import (
    normalise_try_history,
    build_player_try_timing_profile,
    build_team_try_timeline,
    build_team_conceded_timeline,
    build_try_market_seed,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Historical Try Intelligence", layout="wide")
mobile_header("V8.1.1 Historical Try Intelligence", "Try minutes, first tries, multi-tries and timing profiles")

st.info("This is the data foundation for First Try, 2+ Tries and 3+ Tries markets.")

tabs = st.tabs([
    "Try History",
    "Player Timing",
    "Team Timelines",
    "Try Market Seeds",
    "Data Entry",
])

with tabs[0]:
    st.subheader("Raw Player Try History")
    hist = normalise_try_history(read_table("player_try_history"))

    if hist.empty:
        st.warning("No player_try_history rows loaded yet.")
    else:
        st.dataframe(hist, use_container_width=True)

with tabs[1]:
    st.subheader("Player Try Timing Profiles")
    hist = read_table("player_try_history")
    profile = build_player_try_timing_profile(hist)
    replace_table("player_try_timing_profile", profile)

    if profile.empty:
        st.warning("No timing profile available yet.")
    else:
        player = st.selectbox("Choose player", ["All"] + profile["player"].dropna().unique().tolist())
        shown = profile if player == "All" else profile[profile["player"] == player]
        st.dataframe(shown, use_container_width=True)

with tabs[2]:
    st.subheader("Team Scoring & Conceding Timelines")
    hist = read_table("player_try_history")
    team_timeline = build_team_try_timeline(hist)
    conceded = build_team_conceded_timeline(hist)

    replace_table("team_try_timeline", team_timeline)
    replace_table("team_conceded_timeline", conceded)

    st.markdown("### Team Scoring")
    if team_timeline.empty:
        st.warning("No team scoring timeline available.")
    else:
        st.dataframe(team_timeline, use_container_width=True)

    st.markdown("### Team Conceding")
    if conceded.empty:
        st.warning("No conceded timeline available.")
    else:
        st.dataframe(conceded, use_container_width=True)

with tabs[3]:
    st.subheader("First Try / 2+ / 3+ Seed Report")
    st.caption("This is the first version of the market model. V8.1 will turn these into full market predictions with odds comparison.")

    predictions = read_table("predictions")
    profile = read_table("player_try_timing_profile")
    team_timeline = read_table("team_try_timeline")
    conceded = read_table("team_conceded_timeline")

    report = build_try_market_seed(predictions, profile, team_timeline, conceded)
    replace_table("try_market_seed_report", report)

    if report.empty:
        st.warning("Run predictions and add try history first.")
    else:
        display_cols = [c for c in [
            "player", "team", "position", "model_score", "model_probability",
            "avg_try_minute", "avg_first_try_minute",
            "first_try_seed_prob", "first_try_seed_fair_odds",
            "two_plus_seed_prob", "two_plus_seed_fair_odds",
            "three_plus_seed_prob", "three_plus_seed_fair_odds",
            "timing_profile", "timing_label"
        ] if c in report.columns]
        st.dataframe(report[display_cols], use_container_width=True)

with tabs[4]:
    st.subheader("Add / Edit Player Try History")
    st.write("Each row is one try scored by a player.")

    current = read_table("player_try_history")
    if current.empty:
        current = pd.DataFrame(columns=[
            "player", "team", "opponent", "round", "date", "venue",
            "minute", "try_number", "is_first_try", "result", "channel", "position"
        ])

    edited = st.data_editor(current, use_container_width=True, num_rows="dynamic")
    if st.button("Save player try history"):
        replace_table("player_try_history", edited)
        st.success("Player try history saved.")
