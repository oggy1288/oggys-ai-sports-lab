import streamlit as st
import pandas as pd

from src.database import read_table, replace_table, append_table
from src.odds_aggregator import (
    SUPPORTED_BOOKMAKERS,
    normalise_odds_table,
    aggregate_best_odds,
    compare_model_to_market,
    build_odds_import_template,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Live Odds Aggregator", layout="wide")
mobile_header("V7.1 Live Odds Aggregator", "Compare Sportsbet, Ladbrokes, TAB, Neds, PointsBet, Bet365 and more")

st.warning(
    "This version is API-ready and CSV-ready. It does not scrape bookmaker websites directly. "
    "Use official APIs, licensed odds feeds, or manual CSV imports."
)

tab1, tab2, tab3, tab4 = st.tabs([
    "Import Odds",
    "Best Price Board",
    "Model vs Market",
    "Connector Setup",
])

with tab1:
    st.subheader("Import Odds")
    st.write("Upload a CSV with columns: fixture_id, round, player, team, market, bookmaker, odds, timestamp.")

    template = build_odds_import_template()
    st.download_button(
        "Download odds import template",
        template.to_csv(index=False).encode("utf-8"),
        "odds_import_template.csv",
        "text/csv",
    )

    uploaded = st.file_uploader("Upload odds CSV", type=["csv"])
    if uploaded:
        raw = pd.read_csv(uploaded)
        st.write("Raw preview")
        st.dataframe(raw.head(30), use_container_width=True)

        clean = normalise_odds_table(raw)
        st.write("Cleaned preview")
        st.dataframe(clean.head(30), use_container_width=True)

        if st.button("Save odds import"):
            existing = read_table("odds")
            combined = pd.concat([existing, clean], ignore_index=True) if not existing.empty else clean
            replace_table("odds", combined)
            st.success(f"Saved {len(clean)} imported odds rows. Total odds rows: {len(combined)}.")

    st.subheader("Manual Quick Add")
    with st.form("quick_odds_form", clear_on_submit=True):
        fixture_id = st.text_input("Fixture ID", value="")
        round_no = st.text_input("Round", value="")
        player = st.text_input("Player")
        team = st.text_input("Team")
        market = st.selectbox("Market", ["Anytime Try", "First Try", "Two Tries", "Other"])
        bookmaker = st.selectbox("Bookmaker", SUPPORTED_BOOKMAKERS)
        odds = st.number_input("Decimal odds", min_value=1.01, value=2.00, step=0.01)
        timestamp = st.text_input("Timestamp", value="")
        submitted = st.form_submit_button("Add odds row")

    if submitted:
        append_table("odds", pd.DataFrame([{
            "fixture_id": fixture_id,
            "round": round_no,
            "player": player,
            "team": team,
            "market": market,
            "bookmaker": bookmaker,
            "odds": odds,
            "timestamp": timestamp,
        }]))
        st.success("Odds row added.")

with tab2:
    st.subheader("Best Price Board")
    odds = read_table("odds")
    best = aggregate_best_odds(odds)
    replace_table("best_odds", best)

    if best.empty:
        st.info("No odds loaded yet.")
    else:
        market_filter = st.multiselect(
            "Market",
            sorted(best["market"].dropna().unique().tolist()),
            default=sorted(best["market"].dropna().unique().tolist()),
        )
        shown = best[best["market"].isin(market_filter)] if market_filter else best
        st.dataframe(shown, use_container_width=True)
        st.download_button(
            "Download best odds CSV",
            shown.to_csv(index=False).encode("utf-8"),
            "best_odds.csv",
            "text/csv",
        )

with tab3:
    st.subheader("Model vs Market Value")
    predictions = read_table("predictions")
    best = read_table("best_odds")
    report = compare_model_to_market(predictions, best)

    if report.empty:
        st.info("Run predictions and import odds first.")
    else:
        replace_table("odds_value_report", report)

        value_filter = st.multiselect(
            "Value flag",
            sorted(report["odds_value_flag"].dropna().unique().tolist()),
            default=sorted(report["odds_value_flag"].dropna().unique().tolist()),
        )
        shown = report[report["odds_value_flag"].isin(value_filter)] if value_filter else report

        display_cols = [c for c in [
            "player", "team", "position", "model_score", "model_probability",
            "fair_odds", "best_odds", "best_bookmaker",
            "market_edge_pct", "ev_pct", "odds_value_flag"
        ] if c in shown.columns]

        st.dataframe(shown[display_cols], use_container_width=True)

        st.download_button(
            "Download odds value report",
            shown.to_csv(index=False).encode("utf-8"),
            "odds_value_report.csv",
            "text/csv",
        )

with tab4:
    st.subheader("Connector Setup")
    st.write("""
    The app is prepared for official odds connectors, but direct bookmaker scraping is not included.

    Recommended setup:
    1. Use a licensed odds API/provider where possible.
    2. Import bookmaker odds by CSV until API access is available.
    3. Keep bookmaker name and market names consistent.
    4. Use decimal odds.
    """)

    st.dataframe(pd.DataFrame({
        "Bookmaker": SUPPORTED_BOOKMAKERS,
        "Status": ["CSV Ready"] * len(SUPPORTED_BOOKMAKERS),
        "Future Method": ["Official API / licensed odds feed"] * len(SUPPORTED_BOOKMAKERS),
    }), use_container_width=True)
