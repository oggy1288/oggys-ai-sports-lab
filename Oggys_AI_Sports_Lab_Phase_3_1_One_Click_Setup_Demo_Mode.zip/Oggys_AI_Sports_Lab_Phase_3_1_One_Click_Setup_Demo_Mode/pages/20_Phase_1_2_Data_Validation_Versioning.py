import streamlit as st
import pandas as pd

from src.warehouse_engine import (
    WAREHOUSE_SCHEMA,
    create_warehouse_tables,
    read_warehouse_table,
    replace_warehouse_table,
    append_warehouse_table,
    warehouse_table_counts,
    build_empty_template,
    validate_warehouse_table,
    validate_relationships,
    create_dataset_version,
    log_import,
    build_data_health_score,
)
from src.ui_helpers import mobile_header

st.set_page_config(page_title="Phase 1.2 Data Validation", layout="wide")
mobile_header("Phase 1.2 — Data Validation & Dataset Versioning", "Stronger warehouse checks before the AI uses the data")

create_warehouse_tables()

tabs = st.tabs([
    "Health Score",
    "Schema Validation",
    "Relationship Checks",
    "Dataset Versions",
    "Import Centre",
    "Data Dictionary",
])

with tabs[0]:
    st.subheader("Warehouse Health")
    health = build_data_health_score()
    st.dataframe(health, use_container_width=True)
    if not health.empty:
        st.metric("Data Health Score", f"{float(health['data_health_score'].iloc[0]):.1f}/100")

    st.subheader("Table Counts")
    st.dataframe(warehouse_table_counts(), use_container_width=True)

with tabs[1]:
    st.subheader("Schema Validation")
    table = st.selectbox("Choose table to validate", list(WAREHOUSE_SCHEMA.keys()))
    df = read_warehouse_table(table)
    issues = validate_warehouse_table(table, df)
    st.dataframe(issues, use_container_width=True)

    if st.button("Validate all tables"):
        all_issues = []
        for t in WAREHOUSE_SCHEMA:
            table_issues = validate_warehouse_table(t, read_warehouse_table(t))
            all_issues.append(table_issues)
        combined = pd.concat(all_issues, ignore_index=True)
        st.dataframe(combined, use_container_width=True)

with tabs[2]:
    st.subheader("Relationship Checks")
    st.caption("Checks that match_id, player_id and team_id values link properly across warehouse tables.")
    dataset_version = st.text_input("Dataset version label for this check", value="current")
    if st.button("Run relationship checks"):
        report = validate_relationships(dataset_version)
        st.success("Relationship checks complete.")
        st.dataframe(report, use_container_width=True)

    current_report = read_warehouse_table("relationship_quality_report")
    if not current_report.empty:
        st.subheader("Latest Relationship Report")
        st.dataframe(current_report, use_container_width=True)

with tabs[3]:
    st.subheader("Dataset Versioning")
    st.write("Create a version snapshot after importing a clean dataset.")

    with st.form("dataset_version_form"):
        dataset_name = st.text_input("Dataset name", value="OASL NRL Historical Warehouse")
        version_label = st.text_input("Version label", value="v1.0")
        created_by = st.text_input("Created by", value="Nathan")
        notes = st.text_area("Notes")
        submitted = st.form_submit_button("Create dataset version")

    if submitted:
        record = create_dataset_version(dataset_name, version_label, created_by, notes)
        st.success("Dataset version created.")
        st.dataframe(record, use_container_width=True)

    versions = read_warehouse_table("dataset_versions")
    if not versions.empty:
        st.subheader("Dataset Versions")
        st.dataframe(versions, use_container_width=True)

with tabs[4]:
    st.subheader("CSV Import Centre")
    table = st.selectbox("Target table", list(WAREHOUSE_SCHEMA.keys()), key="import_table")
    template = build_empty_template(table)

    st.download_button(
        f"Download {table} template",
        template.to_csv(index=False).encode("utf-8"),
        f"{table}_template.csv",
        "text/csv",
    )

    uploaded = st.file_uploader("Upload CSV", type=["csv"])
    mode = st.radio("Import mode", ["Replace table", "Append to table"], horizontal=True)
    dataset_version_id = st.text_input("Dataset version ID for import log", value="working")

    if uploaded:
        raw = pd.read_csv(uploaded)
        st.subheader("Preview")
        st.dataframe(raw.head(50), use_container_width=True)
        issues = validate_warehouse_table(table, raw)
        st.subheader("Validation")
        st.dataframe(issues, use_container_width=True)

        if st.button("Import CSV"):
            if mode == "Replace table":
                replace_warehouse_table(table, raw)
            else:
                append_warehouse_table(table, raw)
            log_import(dataset_version_id, table, uploaded.name, len(raw), 0, "SUCCESS", mode)
            st.success(f"Imported {len(raw)} rows into {table}.")

    logs = read_warehouse_table("import_log")
    if not logs.empty:
        st.subheader("Import Log")
        st.dataframe(logs, use_container_width=True)

with tabs[5]:
    st.subheader("Master Data Dictionary")
    dictionary = pd.read_csv("data_dictionary/master_data_dictionary.csv")
    st.dataframe(dictionary, use_container_width=True)
    st.download_button(
        "Download master data dictionary",
        dictionary.to_csv(index=False).encode("utf-8"),
        "master_data_dictionary.csv",
        "text/csv",
    )
