import streamlit as st
import pandas as pd
import numpy as np

from src.database import read_table, replace_table
from src.integrity_checker import filter_predictions_to_week
from src.milestone_engine import apply_milestone_modifier
from src.origin_engine import apply_origin_player_modifier
from src.narrative_engine import apply_narrative_context
from src.name_matching import generate_player_id
from src.middle_forward_engine import apply_middle_forward_modifier
from src.team_dna_engine import apply_team_dna_boost
from src.sequence_engine import build_player_sequence_report, build_opponent_matchup_sequence, merge_sequence_into_predictions
from src.ui_helpers import inject_mobile_css

st.set_page_config(page_title="Run Predictor", layout="wide")
inject_mobile_css()

st.title("Run Predictor")
st.caption("Build try scorer predictions from saved player, odds, injury, Origin, narrative, milestone, and middle-forward data.")

def confidence_band(score):
    if score >= 90:
        return "Elite"
    if score >= 80:
        return "Strong"
    if score >= 70:
        return "Value"
    if score >= 60:
        return "Watch"
    return "Avoid"

def recommendation(edge, score):
    if edge >= 0.15 and score >= 85:
        return "Elite Bet"
    if edge >= 0.08 and score >= 75:
        return "Strong Bet"
    if edge >= 0.03 and score >= 70:
        return "Small Value"
    return "No Bet"

def build_predictions():
    players = read_table("player_stats")

    if players.empty:
        return pd.DataFrame()

    if "player_id" not in players.columns:
        players["player_id"] = players.apply(
            lambda r: generate_player_id(r.get("player", ""), r.get("team", "")),
            axis=1,
        )

    players = apply_milestone_modifier(players)
    players = apply_origin_player_modifier(players, read_table("origin_players"))
    players = apply_narrative_context(players, read_table("narrative_context"))
    players = apply_middle_forward_modifier(players, read_table("middle_forward_context"))
    players = apply_team_dna_boost(players, read_table("channel_matchups"))

    odds = read_table("odds")
    injuries = read_table("injuries")

    for col in ["tries", "games", "last5_tries", "avg_minutes"]:
        if col not in players.columns:
            players[col] = 0
        players[col] = pd.to_numeric(players[col], errors="coerce").fillna(0)

    players["try_rate"] = np.where(players["games"] > 0, players["tries"] / players["games"], 0)
    players["last5_rate"] = players["last5_tries"] / 5
    players["minutes_factor"] = (players["avg_minutes"] / 80).clip(0, 1.15)

    if "goal_line_role" in players.columns:
        role_boost = players["goal_line_role"].astype(str).str.lower().map({
            "high": 1.12,
            "medium": 1.00,
            "low": 0.88,
        }).fillna(1.0)
    else:
        role_boost = 1.0

    players["model_score"] = (
        players["try_rate"].clip(0, 1) * 40
        + players["last5_rate"].clip(0, 1) * 30
        + players["minutes_factor"] * 20
        + role_boost * 10
    ).clip(0, 100)

    for boost_col in [
        "milestone_boost",
        "origin_boost",
        "narrative_boost",
        "middle_forward_boost",
    ]:
        if boost_col in players.columns:
            players[boost_col] = pd.to_numeric(players[boost_col], errors="coerce").fillna(0)
            players["model_score"] = (players["model_score"] + players[boost_col]).clip(0, 100)

    if not injuries.empty and "player" in injuries.columns:
        keep_cols = [c for c in ["player", "status", "minutes_adjustment"] if c in injuries.columns]
        if keep_cols:
            players = players.merge(injuries[keep_cols], on="player", how="left")
        if "minutes_adjustment" in players.columns:
            players["minutes_adjustment"] = pd.to_numeric(players["minutes_adjustment"], errors="coerce").fillna(0)
            players["model_score"] = (players["model_score"] + players["minutes_adjustment"]).clip(0, 100)
        if "status" in players.columns:
            players.loc[players["status"].astype(str).str.lower().eq("out"), "model_score"] = 0

    players["model_probability"] = (players["model_score"] / 100 * 0.72).clip(0.01, 0.85)
    players["fair_odds"] = (1 / players["model_probability"]).round(2)

    best_odds = read_table("best_odds")
    if not best_odds.empty and "player" in best_odds.columns:
        merge_cols = ["player"]
        if "team" in players.columns and "team" in best_odds.columns:
            merge_cols = ["player", "team"]
        keep = [c for c in ["player", "team", "best_odds", "best_bookmaker"] if c in best_odds.columns]
        players = players.merge(best_odds[keep], on=merge_cols, how="left")
        players = players.rename(columns={"best_odds": "bookmaker_odds"})
    elif not odds.empty and "player" in odds.columns:
        odds_any = odds.copy()
        if "market" in odds_any.columns:
            odds_any = odds_any[odds_any["market"].astype(str).str.lower().str.contains("anytime", na=False)]
        odds_any["odds"] = pd.to_numeric(odds_any["odds"], errors="coerce")
        odds_any = odds_any.sort_values("odds", ascending=False).drop_duplicates("player")
        players = players.merge(odds_any[["player", "odds"]], on="player", how="left")
        players = players.rename(columns={"odds": "bookmaker_odds"})
    else:
        players["bookmaker_odds"] = np.nan

    players["edge_pct"] = ((players["bookmaker_odds"] / players["fair_odds"]) - 1).fillna(0).round(4)
    players["confidence_band"] = players["model_score"].apply(confidence_band)
    players["bet_recommendation"] = players.apply(
        lambda r: recommendation(r["edge_pct"], r["model_score"]),
        axis=1,
    )

    cols = [
        "player_id",
        "player",
        "team",
        "position",
        "model_score",
        "model_probability",
        "fair_odds",
        "bookmaker_odds",
        "best_bookmaker",
        "edge_pct",
        "confidence_band",
        "bet_recommendation",
        "milestone_flag",
        "milestone_boost",
        "milestone_note",
        "origin_status",
        "origin_boost",
        "origin_note",
        "narrative_boost",
        "narrative_flags",
        "narrative_note",
        "team_dna_channel", "team_dna_boost", "team_dna_verdict", "team_dna_summary",
        "middle_forward_flag",
        "middle_forward_boost",
        "middle_forward_note",
        "last5_sequence", "last5_avg", "last5_rating",
        "vs_opponent_sequence", "vs_opponent_avg", "vs_opponent_rating",
    ]

    existing_cols = [c for c in cols if c in players.columns]
    pred_output = players[existing_cols].sort_values("model_score", ascending=False)

    player_seq = build_player_sequence_report(read_table("player_game_history"))
    opp_seq = build_opponent_matchup_sequence(read_table("player_vs_opponent_history"))
    pred_output = merge_sequence_into_predictions(pred_output, player_seq, opp_seq)

    return pred_output

only_weekly = st.checkbox("Only show players named in this week's team lists", value=True)

if st.button("Run prediction engine"):
    predictions = build_predictions()

    if only_weekly:
        predictions = filter_predictions_to_week(predictions, read_table("team_lists"))

    if predictions.empty:
        st.warning("No predictions found. Check player_stats and weekly team lists.")
    else:
        replace_table("predictions", predictions)
        st.success(f"Saved {len(predictions)} predictions.")
        st.info("Next: open Why AI Likes This to see the reasoning behind each pick.")
        st.dataframe(predictions, use_container_width=True)

st.subheader("Saved Predictions")
saved = read_table("predictions")

if saved.empty:
    st.info("No saved predictions yet.")
else:
    if "model_score" in saved.columns:
        saved["model_score"] = pd.to_numeric(saved["model_score"], errors="coerce").fillna(0)
        saved = saved.sort_values("model_score", ascending=False)

    st.dataframe(saved, use_container_width=True)

    csv = saved.to_csv(index=False).encode("utf-8")
    st.download_button("Download predictions CSV", csv, "predictions.csv", "text/csv")
