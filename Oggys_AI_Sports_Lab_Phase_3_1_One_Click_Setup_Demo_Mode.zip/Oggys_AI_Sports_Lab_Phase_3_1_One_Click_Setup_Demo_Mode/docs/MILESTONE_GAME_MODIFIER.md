# V6.5 Milestone Game Modifier

This stage adds a milestone-game factor to the NRL Predictor.

## Why it exists

Some teams lift emotionally for a player milestone:
- 50th game
- 100th game
- 150th game
- 200th game
- 300th game

This should not dominate the model, but it can be a small positive modifier.

## How it works

Add `career_games` to player_stats.

The model assumes career_games means games played BEFORE the upcoming match.

Example:
- Player has 99 career games
- Upcoming match is their 100th
- Milestone flag = 100th game
- Model score boost = +3

## Boost levels

- 50th game: +2
- 100th game: +3
- 150th game: +3
- 200th game: +4
- 300th game: +5

## Important

This is an emotional/context modifier only. It should sit behind player try rate, role, position, minutes, team attack, opposition weakness, weather, and injuries.