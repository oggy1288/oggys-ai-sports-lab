# Phase 1.2 — Data Validation & Dataset Versioning

This stage strengthens the Historical Data Warehouse.

## Added

- Dataset version tracking
- Import log
- Relationship quality report
- Primary key duplicate checks
- Blank ID checks
- Numeric validation
- Allowed-value validation
- Relationship checks between core tables
- Data health score

## Why this matters

Before the AI uses the warehouse, the data needs to be safe:
- players must link to player records
- team lists must link to matches
- tries must link to matches and players
- duplicate IDs must be caught
- each dataset version must be recorded

## Next Phase 1 sprint

Phase 1.3 should add automated source adapters:
- fixtures/results importer
- player stats importer
- try events importer
- weather importer
- odds importer
