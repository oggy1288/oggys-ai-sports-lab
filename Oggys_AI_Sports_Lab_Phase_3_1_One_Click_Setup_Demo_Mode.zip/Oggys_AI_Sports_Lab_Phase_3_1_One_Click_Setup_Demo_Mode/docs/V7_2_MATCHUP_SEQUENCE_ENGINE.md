# V7.2 Matchup Sequence Engine

This stage adds quick visual try-scoring sequences.

## What it shows

### Player Last 5
Example:
2️⃣ 0️⃣ 2️⃣ 0️⃣ 2️⃣

This shows the player's tries in each of their last five games.

### Team Last 5
Shows team tries scored and tries conceded in the same visual format.

Example:
Team scored: 2️⃣ 3️⃣ 🔟+ 3️⃣ 5️⃣
Team conceded: 4️⃣ 3️⃣ 0️⃣ 3️⃣ 1️⃣

### Player vs Opponent
Shows whether the player has a strong record against the team they are facing.

Example:
Vs South Sydney: 2️⃣ 1️⃣ 0️⃣ 2️⃣ 1️⃣

## Why this matters

It gives Nathan a very quick way to see:
- who is hot
- who scores against this opponent
- whether the team is scoring tries
- whether the opponent is leaking tries
- whether the player is a strong matchup pick
