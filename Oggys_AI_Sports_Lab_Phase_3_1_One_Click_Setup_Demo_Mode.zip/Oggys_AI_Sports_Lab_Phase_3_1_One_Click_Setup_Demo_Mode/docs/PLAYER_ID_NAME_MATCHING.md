# V6.8 Player ID & Name Matching System

This stage reduces missing-player errors by creating stable player IDs and aliases.

## Problem solved

The old model can miss a player if different tables use different names:

- Herbie Farnworth
- H. Farnworth
- H Farnworth
- Herbie F.

The model may treat those as different players.

## New system

- player_id is generated from team + player name
- alias table is generated from the master player database
- initials are supported
- fuzzy matching is supported
- match reports show exact, initials, fuzzy, and no-match records

## What to use it for

Check these tables against the master player list:

- team_lists
- odds
- injuries
- origin_players
- narrative_context

## Next improvement

V6.9 should add a weekly setup wizard:
1. Pick round
2. Add fixtures
3. Add team lists
4. Run name checker
5. Run integrity checker
6. Run predictor
7. Review mobile dashboard