# V8.2 Team DNA Engine

This stage adds channel-based attack and defence intelligence.

## Channels

- Left Edge
- Middle
- Right Edge
- Kick / Other

## What it calculates

### Team Attack DNA
Where a team scores its tries.

Example:
- Right Edge: 46%
- Left Edge: 29%
- Middle: 18%
- Kick / Other: 7%

### Team Defence DNA
Where a team concedes tries.

Example:
- Left Edge conceded: 43%
- Middle conceded: 24%
- Right Edge conceded: 33%

### Channel Matchups
The app compares attacking strength against opponent weakness.

Example:
Panthers Right Edge attack vs Rabbitohs Left Edge defence.

## Prediction impact

Players receive small boosts when:
- their team attacks strongly through their channel
- the opponent concedes heavily through that channel
- the channel matchup is strong or elite

## Why this matters

It gives the model a better answer to:
"Why is this player likely to score against this opponent?"
