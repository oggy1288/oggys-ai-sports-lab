# V8.1 Try Markets Intelligence Engine

This stage expands the app from Anytime Try Scorer into multiple try-scoring markets.

## Markets added

- Anytime Try
- First Try
- 2+ Tries
- 3+ Tries

## Inputs used

- existing model probability
- historical first try rate
- player early scoring profile
- team early scoring profile
- opponent early concession profile
- historical 2+ and 3+ try counts
- best bookmaker odds where available

## Outputs

For each player and market:
- probability
- fair odds
- best market odds
- best bookmaker
- edge %
- EV %
- market value flag

## Important

This is the first complete Try Markets Engine. Future stages should improve it with:
- true match simulation
- team expected tries
- edge/channel-specific try share
- market movement tracking
