# V8.1.1 Historical Try Intelligence Database

This stage creates the data foundation for First Try, 2+ Tries and 3+ Tries markets.

## New data captured

Each try can now be stored with:
- player
- team
- opponent
- round
- venue
- minute
- try number
- whether it was the first try
- result
- scoring channel
- position

## Reports added

- Player Try Timing Profile
- Team Try Timeline
- Team Conceded Timeline
- Try Market Seed Report

## Timing windows

- 0–20 minutes
- 20–40 minutes
- 40–60 minutes
- 60–80 minutes

## Player labels

- Early Threat
- Second Half Specialist
- Late Finisher
- Balanced Scorer

## Next stage

V8.1 should build the full Try Markets Engine:
- First Try Scorer
- 2+ Tries
- 3+ Tries
- odds comparison for each market
