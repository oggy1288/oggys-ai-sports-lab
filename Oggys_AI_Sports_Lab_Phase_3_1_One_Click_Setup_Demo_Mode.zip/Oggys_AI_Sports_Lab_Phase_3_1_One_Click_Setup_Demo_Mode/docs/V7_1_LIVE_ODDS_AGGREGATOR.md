# V7.1 Live Odds Aggregator

This stage adds bookmaker price comparison.

## Supported bookmakers

- Sportsbet
- Ladbrokes
- TAB
- Neds
- PointsBet
- Bet365
- Unibet
- Bet Right
- Other

## What it does

- Imports odds from CSV
- Normalises bookmaker odds
- Finds best available odds per player
- Stores a Best Price Board
- Compares model fair odds to market odds
- Calculates market edge %
- Calculates EV %
- Flags Elite Price / Strong Value / Small Edge / No Value

## Why no direct scraping?

Bookmaker sites are fragile and may restrict scraping through their terms. This build is API-ready and CSV-ready. The recommended approach is to use official APIs, a licensed odds feed, or manual CSV import.

## Next step

V7.2 should add a Bankroll & Staking Engine using:
- flat staking
- fractional Kelly
- max stake caps
- daily/weekly exposure limits
