# Phase 1.3 — Source Adapter Framework

This stage adds structured import adapters.

## Added adapters

- fixtures_results
- player_stats
- try_events
- weather
- odds

## Why this matters

Historical data will come from different files and formats. Source adapters clean and map those files into the OASL warehouse schema.

## Adapter examples

- `home` → `home_team`
- `away` → `away_team`
- `date` → `match_date`
- `player` → `scorer_name` for try events
- `odds` → `decimal_odds`

## Next Phase 1 sprint

Phase 1.4 should add source-specific connectors and scrapers/importers where allowed:
- official fixture/results source
- player stats source
- weather archive source
- odds feed import
