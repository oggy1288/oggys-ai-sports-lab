# Phase 1 — OASL Historical Data Warehouse

This phase creates the source of truth for Oggy's AI Sports Lab.

## Added
- Historical warehouse schema
- Master data dictionary
- Warehouse SQLite database support
- Import templates
- Data quality checker
- Phase 1 Streamlit page
- Sample CSV files

## Core warehouse tables
- matches
- teams_master
- players_master
- team_lists_history
- player_match_stats
- try_events
- weather_history
- venues_master
- referees_history
- odds_history
- injuries_suspensions_history
- milestones_history
- data_quality_log

## Next sprint
Phase 1.2 should add stronger validation rules, duplicate detection across all IDs, relationship checks, dataset versioning, and import status logs.
