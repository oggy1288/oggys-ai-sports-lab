# V6.6 Origin Impact Engine

This stage adds State of Origin context to the NRL Predictor.

## Why this matters

Teams often play differently around State of Origin because:
- star players are unavailable
- combinations change
- young players get bigger roles
- Origin players may back up tired
- teams can lose spine control, middle power, or edge defence

## Player-level effects

Supported player statuses:
- Selected
- Backup
- Unlucky Miss
- Rested
- Backing Up
- Backing Up Heavy Minutes
- Not In Origin Frame

## Team-level effects

Supported team impacts:
- Key Spine Out
- Key Middle Out
- Key Edge Out
- Multiple Stars Out
- Origin Stars Backing Up
- Origin Players Available
- No Major Impact

## Important

Origin context should not overpower the base model. It should adjust:
- player model score
- team attack
- team defence
- opportunity for replacement players
- fatigue risk