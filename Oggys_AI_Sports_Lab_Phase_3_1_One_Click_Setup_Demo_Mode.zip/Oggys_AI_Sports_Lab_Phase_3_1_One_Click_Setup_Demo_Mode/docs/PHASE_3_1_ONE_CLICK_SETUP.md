# Phase 3.1 — One-Click Setup & Demo Mode

This stage makes Oggy's AI Sports Lab easier to test.

## Added

- Setup Wizard page
- One-click demo data loader
- One-click AI pipeline runner
- Setup status checker
- Demo results screen
- App health screen

## How to use

1. Open `25_Phase_3_1_Setup_Wizard_Demo_Mode.py`.
2. Click **Load demo data**.
3. Click **Run AI pipeline**.
4. Review Match Winner, Try Market and Player DNA outputs.

## Why this matters

Before adding more advanced features, Nathan needs an easy way to confirm the app is working from his phone or a simple hosted app setup.
