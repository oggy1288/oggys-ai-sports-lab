# V6.4 Player Integrity Checker

This stage fixes a key problem: players can disappear from try-scorer pages when the weekly team list and the player database do not match.

## Important logic

The weekly predictor should only show players who are in the current week's team lists.

That means:
- If a player is not playing this week, they should not show.
- If a player is named this week but missing from player_stats, they will be flagged.
- If a player name is spelt differently, they will be flagged as missing.
- If a selected player has no odds, they can still be rated but value betting will not work.

## Checks added

- Missing from player database
- Not selected this week
- Duplicate names
- Missing position/team/stats
- Missing odds
- Missing injury status

## Next improvement

Add a proper player ID system so name spelling issues stop breaking lookups.