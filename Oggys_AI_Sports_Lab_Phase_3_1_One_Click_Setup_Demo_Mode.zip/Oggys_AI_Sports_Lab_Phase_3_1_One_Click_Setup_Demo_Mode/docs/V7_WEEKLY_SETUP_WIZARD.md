# V7.0 Weekly Setup Wizard

This stage adds a guided weekly workflow for Nathan to use from a phone.

## Workflow

1. Select round
2. Add fixtures
3. Add team lists
4. Add player stats, odds and injuries
5. Add context:
   - Origin
   - milestones
   - narrative
   - middle-forward scoring chances
6. Run name matching
7. Run integrity checker
8. Run predictions
9. Review mobile dashboard

## Why this matters

Before this wizard, each feature existed on its own page. The wizard brings everything into one ordered flow so the app is easier to use each week.
