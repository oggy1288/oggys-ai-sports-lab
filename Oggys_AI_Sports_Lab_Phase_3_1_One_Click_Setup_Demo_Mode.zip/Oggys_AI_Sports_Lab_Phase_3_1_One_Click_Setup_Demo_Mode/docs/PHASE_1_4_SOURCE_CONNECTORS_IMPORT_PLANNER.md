# Phase 1.4 — Source Connectors & Import Planner

This stage adds a structured source registry and connector planning system.

## Added

- Source registry
- Import planner
- Connector health report
- Field coverage report
- CSV-first source import workflow
- API-ready connector placeholders

## Sources registered

- Official Fixtures / Results
- Player Match Stats
- Try Events
- Weather Archive
- Odds Feed / Manual Odds CSV
- Injuries / Suspensions / Late Mail

## Important

This build does not scrape bookmaker websites. Use official APIs, licensed feeds, verified exports or manual CSV files.

## Next Phase 1 sprint

Phase 1.5 should add:
- historical season backfill tracker
- season-by-season import checklist
- missing season/games report
- data completeness score by season
