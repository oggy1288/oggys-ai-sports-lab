# V7.3 Why AI Likes This Explanation Engine

This stage adds a plain-English explanation layer.

## What it does

For each player it explains:
- recent form
- last 5 try sequence
- record vs opponent
- market value
- milestone
- Origin impact
- narrative factors
- middle-forward try path
- risk flags

## Visual breakdown

Each player receives:
- OASL score
- AI summary
- positive reasons
- risk checks
- traffic-light factor scores
- confidence bars
- final verdict

## Why this matters

Nathan wanted a quick way to understand why the AI likes a player rather than only seeing a score.
