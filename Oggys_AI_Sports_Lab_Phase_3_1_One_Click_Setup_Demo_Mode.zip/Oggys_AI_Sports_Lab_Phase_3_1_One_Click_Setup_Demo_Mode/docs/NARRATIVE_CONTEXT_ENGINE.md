# V6.7 Narrative Context Engine

This stage adds a capped human-context layer.

## Supported contexts

- NRL Debut
- Club Debut
- Home Debut
- Playing Former Club
- Captain First Game
- Final Home Game
- Retirement Game
- Rivalry Game
- Finals Intensity
- Grand Final
- First Game Back From Injury
- Returning From Suspension
- New Contract Signed
- Contract Year Motivation
- Dropped Last Week / Recalled
- Birthday Game
- Indigenous Round
- ANZAC Round
- Magic Round

## Model rule

Narrative should be a small adjustment only.

The total narrative boost is capped at +6 and floored at -4.

## Milestone update

400th game is now recognised with a +6 modifier.