# NRL Predictor Pro V6.3 — Mobile Deployment Guide

This version is deploy-ready so Nathan can open the app from a phone using a private web link.

## Best beginner option

Use Streamlit Community Cloud.

You will need:
1. A GitHub account
2. A Streamlit Community Cloud account
3. This app uploaded to a GitHub repository

## Steps

### 1. Create GitHub account
Go to GitHub and create a free account.

### 2. Create a new repository
Name it:

`nrl-predictor-pro`

Keep it private if you do not want others seeing the code.

### 3. Upload this app
Upload all files from this ZIP into the GitHub repository.

### 4. Open Streamlit Community Cloud
Create a new app and connect it to your GitHub repository.

Settings:
- Main file path: `app.py`
- Python version: 3.11

### 5. Add app password
In Streamlit app settings, add this secret:

```toml
APP_PASSWORD = "choose-your-password"
```

### 6. Launch
Streamlit will give you a link.

Example:

`https://nrl-predictor-pro.streamlit.app`

Open that link on your phone.

## Important note

Streamlit Community Cloud can reset the local SQLite database when the app restarts.
For personal testing, that is okay.
For a serious app, upgrade later to a cloud database such as Supabase or Neon Postgres.

## Next stage

V6.4 should add cloud database support so your data is safely stored online.