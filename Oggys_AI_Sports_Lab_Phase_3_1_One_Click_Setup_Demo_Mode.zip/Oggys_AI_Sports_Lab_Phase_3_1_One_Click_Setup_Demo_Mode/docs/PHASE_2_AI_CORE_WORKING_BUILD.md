# Phase 2 — AI Core Working Build

This build implements the next major OASL AI stages as working modules.

## Included stages

- 2.1 Master Feature Library
- 2.2 Player DNA Engine
- 2.3 Team DNA 2.0
- 2.4 Match-up Intelligence
- 2.5 AI Match Simulation
- 2.6 Ensemble AI / Self-Learning
- 2.7 Real-Time Intelligence

## Main page

Open:

`24_Phase_2_AI_Core_Working_Build.py`

Then click **Run Phase 2 AI pipeline**.

## Inputs

The pipeline reads from the Phase 1 warehouse tables:

- matches
- player_match_stats
- try_events

## Outputs

The pipeline writes:

- phase2_master_features
- phase2_player_dna
- phase2_team_dna_2
- phase2_matchup_intelligence
- phase2_match_simulation
- phase2_try_market_simulation
- phase2_ensemble_predictions
- phase2_learning_summary

## Notes

This is a working first version. It is intentionally simple and explainable so it can be validated before adding more advanced machine learning.
