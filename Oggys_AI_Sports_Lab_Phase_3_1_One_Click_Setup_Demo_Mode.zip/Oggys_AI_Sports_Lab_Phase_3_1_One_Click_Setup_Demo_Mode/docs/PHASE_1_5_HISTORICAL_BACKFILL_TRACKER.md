# Phase 1.5 — Historical Season Backfill Tracker

This stage adds season-by-season tracking for the historical warehouse.

## Added

- season_backfill_plan table
- missing_data_report table
- season_completeness_report table
- default backfill plan generator
- completeness score by season
- missing data reports by area
- season import checklist

## Recommended backfill order

1. 2023–2026
2. 2020–2022
3. 2015–2019
4. 2010–2014
5. Earlier seasons where data quality is reliable

## Core readiness target

A season is model-ready when:
- fixtures/results are near complete
- team lists are near complete
- player match stats are near complete
- try events are near complete
- weather and odds are sufficiently covered
