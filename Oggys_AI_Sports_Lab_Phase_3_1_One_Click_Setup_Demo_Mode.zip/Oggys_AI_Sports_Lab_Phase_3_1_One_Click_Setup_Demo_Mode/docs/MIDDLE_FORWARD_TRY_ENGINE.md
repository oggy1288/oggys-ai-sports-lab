# V6.9 Middle Forward Try Scorer Engine

This stage adds a proper way for forwards to appear in try-scorer predictions.

## Why this matters

Try scorers are not only wingers and centres. In many games, a forward scores through the middle from:

- crash ball near the line
- short pass from a half or hooker
- dummy-half sneak
- tired middle defence
- wet weather / grind-style match
- bench impact against fatigued middles

## Inputs added

- middle_try_role
- opponent_middle_weakness
- team_red_zone_middle_attack
- weather_impact

## Supported roles

- Crash Ball
- Short Ball Runner
- Dummy Half Sneak
- Bench Impact Middle
- Decoy / Low Usage
- No Middle Role

## Model rule

The boost is capped at +10 so forwards can be recognised without overpowering elite outside backs.